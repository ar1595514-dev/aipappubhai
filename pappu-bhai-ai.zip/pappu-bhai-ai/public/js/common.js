// Shared helpers: API calls, auth, formatting, toasts
const Auth = {
  get token() { return localStorage.getItem('pb_token'); },
  get user() { try { return JSON.parse(localStorage.getItem('pb_user')); } catch { return null; } },
  save(token, user) { localStorage.setItem('pb_token', token); localStorage.setItem('pb_user', JSON.stringify(user)); },
  logout() { localStorage.removeItem('pb_token'); localStorage.removeItem('pb_user'); location.href = '/login.html'; },
  require(role) {
    if (!this.token) { location.href = '/login.html'; return false; }
    if (role && this.user?.role !== role) { location.href = '/'; return false; }
    return true;
  },
};

async function api(path, { method = 'GET', body } = {}) {
  const res = await fetch(`/api${path}`, {
    method,
    headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${Auth.token}` },
    body: body ? JSON.stringify(body) : undefined,
  });
  if (res.status === 401) { Auth.logout(); throw new Error('Session expire'); }
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(data.error || 'Request fail');
  return data;
}

const fmt = {
  inr: (n) => (n == null ? '-' : '₹' + Number(n).toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 })),
  num: (n, d = 2) => (n == null ? '-' : Number(n).toLocaleString('en-IN', { minimumFractionDigits: d, maximumFractionDigits: d })),
  pct: (n) => (n == null ? '-' : `${n >= 0 ? '+' : ''}${Number(n).toFixed(2)}%`),
  signed: (n) => (n == null ? '-' : `${n >= 0 ? '+' : '-'}₹${Math.abs(n).toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`),
  time: (t) => new Date(t).toLocaleTimeString('en-IN', { hour12: false }),
  dateTime: (t) => new Date(t).toLocaleString('en-IN', { hour12: false }),
  cls: (n) => (n > 0 ? 'up' : n < 0 ? 'down' : ''),
};

function esc(s) {
  return String(s ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
}

function toast(msg, type = '') {
  let box = document.getElementById('toasts');
  if (!box) { box = document.createElement('div'); box.id = 'toasts'; document.body.appendChild(box); }
  const el = document.createElement('div');
  el.className = `toast ${type}`;
  el.innerHTML = msg;
  box.prepend(el);
  setTimeout(() => el.remove(), 5000);
}

/**
 * Popup form. fields: [{ name, label, type?, value?, placeholder?, help? }]
 * Promise: submit par { name: value } object, cancel par null
 */
function openModal({ title, message = '', fields = [], submitText = 'Save', danger = false }) {
  return new Promise((resolve) => {
    const wrap = document.createElement('div');
    wrap.className = 'modal-backdrop';
    wrap.innerHTML = `
      <form class="modal card" autocomplete="off">
        <div class="card-head"><h3>${title}</h3><button type="button" class="btn btn-sm" data-x>✖</button></div>
        ${message ? `<div class="modal-msg">${message}</div>` : ''}
        ${fields.map((f) => `<div class="field" style="margin-bottom:12px"><label>${esc(f.label)}</label>
          <input class="input" name="${f.name}" type="${f.type || 'text'}" value="${esc(f.value ?? '')}" placeholder="${esc(f.placeholder || '')}" ${f.required ? 'required' : ''} />
          ${f.help ? `<small class="muted" style="font-size:11.5px;display:block;margin-top:5px">${f.help}</small>` : ''}</div>`).join('')}
        <div style="display:flex;gap:10px;justify-content:flex-end;margin-top:6px">
          <button type="button" class="btn" data-x>Cancel</button>
          <button class="btn ${danger ? 'btn-red' : 'btn-primary'}">${submitText}</button>
        </div>
      </form>`;
    const close = (val) => { wrap.remove(); document.removeEventListener('keydown', onKey); resolve(val); };
    const onKey = (e) => { if (e.key === 'Escape') close(null); };
    wrap.addEventListener('click', (e) => { if (e.target === wrap || e.target.closest('[data-x]')) close(null); });
    wrap.querySelector('form').addEventListener('submit', (e) => {
      e.preventDefault();
      close(Object.fromEntries(new FormData(e.target)));
    });
    document.addEventListener('keydown', onKey);
    document.body.appendChild(wrap);
    wrap.querySelector('input')?.focus();
  });
}

function setupShell() {
  const user = Auth.user;
  const $ = (id) => document.getElementById(id);
  if ($('userName')) $('userName').textContent = user?.name || '';
  if ($('userRole')) $('userRole').textContent = user?.role || '';
  if ($('userAvatar')) $('userAvatar').textContent = (user?.name || 'P')[0].toUpperCase();
  document.querySelectorAll('[data-admin-only]').forEach((el) => { if (user?.role !== 'admin') el.style.display = 'none'; });
  $('logoutBtn')?.addEventListener('click', () => Auth.logout());
  const sidebar = document.querySelector('.sidebar');
  $('menuBtn')?.addEventListener('click', () => sidebar.classList.toggle('open'));
  document.querySelector('.overlay')?.addEventListener('click', () => sidebar.classList.remove('open'));
}
