/* ================= Pappu Bhai AI - Admin Panel ================= */
if (!Auth.require('admin')) throw new Error('auth');
setupShell();

const $ = (id) => document.getElementById(id);
let current = 'overview';
let pnlChart = null, pnlSeries = null;

const titles = {
  overview: 'Overview', agents: 'Agents', astro: 'Jyotish Guru', brokers: 'Brokers', apikeys: 'API Keys',
  symbols: 'Tokens (Shares)', trades: 'Trades', users: 'Users', settings: 'Settings', logs: 'Logs',
};
const loaders = {
  overview: loadOverview, agents: loadAgents, astro: loadAstro, brokers: loadBrokers, apikeys: loadApiKeys,
  symbols: loadSymbols, trades: loadTrades,
  users: loadUsers, settings: loadSettings, logs: loadLogs,
};

function show(sec) {
  current = sec;
  document.querySelectorAll('#adminNav button').forEach((b) => b.classList.toggle('active', b.dataset.sec === sec));
  document.querySelectorAll('.admin-section').forEach((s) => s.classList.toggle('active', s.id === `sec-${sec}`));
  $('secTitle').textContent = titles[sec];
  document.querySelector('.sidebar').classList.remove('open');
  loaders[sec]().catch((e) => toast(e.message, 'err'));
}

document.querySelectorAll('#adminNav button').forEach((b) => b.addEventListener('click', () => show(b.dataset.sec)));
$('refreshBtn').addEventListener('click', () => show(current));

const table = (head, rows, empty = 'Koi data nahi') =>
  rows.length
    ? `<table><thead><tr>${head.map((h) => `<th>${h}</th>`).join('')}</tr></thead><tbody>${rows.join('')}</tbody></table>`
    : `<div class="empty">${empty}</div>`;

// ---------------- Overview ----------------
async function loadOverview() {
  const o = await api('/admin/overview');
  const pnl = o.realizedPnl + o.unrealizedPnl;
  const stat = (label, value, sub = '', cls = '') =>
    `<div class="card stat"><div class="label">${label}</div><div class="value mono ${cls}">${value}</div><div class="sub">${sub}</div></div>`;
  $('ovStats').innerHTML = [
    stat('Equity', fmt.inr(o.equity), `Available ${fmt.inr(o.available)} · Capital ${fmt.inr(o.initialCapital)}`),
    stat('Total P&L', fmt.signed(pnl), `Win rate ${o.winRate}% · ${o.totalTrades} trades`, fmt.cls(pnl)),
    stat('AI Decisions', o.decisions.toLocaleString('en-IN'), `${o.signals.toLocaleString('en-IN')} agent signals`),
    stat('Auto Trading', o.autoTrading ? 'ON' : 'OFF', `${o.users} users · ${o.symbols} symbols · ${o.broker}`, o.autoTrading ? 'up' : 'down'),
  ].join('');

  // P&L curve
  if (!pnlChart) {
    const el = $('pnlChart');
    pnlChart = LightweightCharts.createChart(el, {
      layout: { background: { type: 'solid', color: 'transparent' }, textColor: '#8b95b8' },
      grid: { vertLines: { visible: false }, horzLines: { color: 'rgba(120,140,200,0.06)' } },
      timeScale: { timeVisible: true, secondsVisible: true, borderColor: 'rgba(120,140,200,0.15)' },
      rightPriceScale: { borderColor: 'rgba(120,140,200,0.15)' },
    });
    pnlSeries = pnlChart.addAreaSeries({ lineColor: '#7c5cff', topColor: 'rgba(124,92,255,0.4)', bottomColor: 'rgba(124,92,255,0)', lineWidth: 2 });
    new ResizeObserver(() => pnlChart.applyOptions({ width: el.clientWidth, height: el.clientHeight })).observe(el);
  }
  let cum = 0, lastT = 0;
  const data = o.pnlCurve.map((p) => {
    let t = Math.floor(p.t / 1000);
    if (t <= lastT) t = lastT + 1; // time unique hona chahiye
    lastT = t;
    cum += p.pnl;
    return { time: t, value: Math.round(cum * 100) / 100 };
  });
  pnlSeries.setData(data);
  pnlChart.timeScale().fitContent();

  const agents = await api('/agents');
  const nameOf = Object.fromEntries(agents.map((a) => [a.key, `${a.icon} ${a.name}`]));
  $('agreeBars').innerHTML = o.agentAccuracy.filter((a) => a.agent_key !== 'risk').map((a) => {
    const pct = a.total ? Math.round((a.agreed / a.total) * 100) : 0;
    return `<div class="bar-row"><span style="width:150px">${esc(nameOf[a.agent_key] || a.agent_key)}</span><div class="bar"><span style="width:${pct}%"></span></div><b class="mono" style="width:40px;text-align:right">${pct}%</b></div>`;
  }).join('') || '<div class="empty">Abhi data nahi</div>';

  const total = o.decisionMix.reduce((a, d) => a + d.c, 0) || 1;
  const color = { BUY: 'var(--green)', SELL: 'var(--red)', HOLD: 'var(--yellow)' };
  $('mixBars').innerHTML = o.decisionMix.map((d) =>
    `<div class="bar-row"><span style="width:150px"><span class="badge ${d.action}">${d.action}</span></span><div class="bar"><span style="width:${(d.c / total) * 100}%;background:${color[d.action]}"></span></div><b class="mono" style="width:40px;text-align:right">${d.c}</b></div>`
  ).join('') || '<div class="empty">Abhi data nahi</div>';
}

// ---------------- Agents ----------------
// ---------------- 🤖 Agents ----------------
let indTypes = null; // indicator schema (server se) - form ke params yahin se aate hain

const indLabel = (k) => (indTypes?.[k]?.label || k);

// Indicator ke hisaab se params ke input fields banao
function renderParamFields(values) {
  const meta = indTypes[$('agIndicator').value];
  if (!meta) return;
  $('agIndDesc').textContent = meta.desc;
  $('agParams').innerHTML = meta.params.map((p) => `
    <div class="field"><label>${esc(p.label)}</label>
      <input class="input" type="number" data-param="${p.key}" value="${values?.[p.key] ?? p.def}"
        min="${p.min}" max="${p.max}" step="${p.step}" /></div>`).join('')
    || '<div class="muted" style="font-size:12.5px">Is indicator ke liye koi parameter nahi chahiye</div>';
}

function resetAgentForm() {
  const f = $('agentForm');
  f.reset();
  delete f.dataset.editing;
  $('agIndicator').value = 'ema';
  f.elements.weight.value = '1';
  renderParamFields();
  $('agentFormTitle').textContent = '➕ Naya technical agent banao';
  $('agentSave').textContent = '💾 Agent save karo';
  $('agentCancel').style.display = 'none';
}

function startEditAgent(a) {
  const f = $('agentForm');
  f.dataset.editing = a.key;
  f.elements.name.value = a.name;
  f.elements.icon.value = a.icon;
  f.elements.weight.value = a.weight;
  f.elements.indicator.value = a.indicator;
  renderParamFields(JSON.parse(a.params || '{}'));
  $('agentFormTitle').textContent = `✏️ Edit: ${a.name}`;
  $('agentSave').textContent = '💾 Changes save karo';
  $('agentCancel').style.display = '';
  $('agentFormCard').scrollIntoView({ behavior: 'smooth' });
}

async function saveAgent(e) {
  e.preventDefault();
  const f = e.target;
  const params = {};
  document.querySelectorAll('[data-param]').forEach((i) => { params[i.dataset.param] = Number(i.value); });
  const body = {
    name: f.elements.name.value,
    icon: f.elements.icon.value,
    indicator: f.elements.indicator.value,
    weight: Number(f.elements.weight.value),
    params,
  };
  try {
    if (f.dataset.editing) {
      await api(`/admin/agents/${f.dataset.editing}`, { method: 'PUT', body });
      toast('Agent update ho gaya ✅', 'ok');
    } else {
      await api('/admin/agents', { method: 'POST', body });
      toast('Naya agent team me aa gaya ✅', 'ok');
    }
    resetAgentForm();
    loadAgents();
  } catch (err) {
    toast(err.message, 'err');
  }
}

async function loadAgents() {
  if (!indTypes) {
    indTypes = await api('/admin/agent-indicators');
    $('agIndicator').innerHTML = Object.entries(indTypes)
      .map(([k, t]) => `<option value="${k}">${t.emoji} ${esc(t.label)}</option>`).join('');
    $('agIndicator').addEventListener('change', () => renderParamFields());
    $('agentForm').addEventListener('submit', saveAgent);
    $('agentCancel').addEventListener('click', resetAgentForm);
    renderParamFields();
  }
  const agents = await api('/agents');
  $('agentList').innerHTML = agents.map((a) => `
    <div class="agent-admin">
      <div style="display:flex;gap:12px;align-items:center;min-width:0">
        <div class="agent-icon">${a.icon}</div>
        <div style="min-width:0">
          <b>${esc(a.name)}</b> <small class="muted">(${a.key})</small>
          ${a.indicator
            ? `<span class="badge HOLD" title="Indicator: ${esc(indLabel(a.indicator))}">${esc(indLabel(a.indicator))}</span>`
            : '<span class="badge trader">SYSTEM</span>'}
          <br><small class="muted">${esc(a.description)}</small>
        </div>
      </div>
      <div>
        ${a.key === 'risk'
          ? '<small class="muted">Voting nahi karta · sirf VETO + SL/Target</small>'
          : `<label class="muted" style="font-size:11px">Weight: <b id="w-${a.key}">${a.weight}</b></label>
             <input type="range" min="0" max="3" step="0.1" value="${a.weight}" data-weight="${a.key}" />`}
      </div>
      <label class="switch" style="padding:6px 8px;justify-content:center">
        <input type="checkbox" data-enable="${a.key}" ${a.enabled ? 'checked' : ''} /><span class="track"></span>
      </label>
      <div class="agent-actions">
        ${a.indicator ? `<button class="btn btn-sm" data-aedit="${a.key}" title="Edit karo">⚙️</button>` : ''}
        ${a.key === 'risk' || a.key === 'astro'
          ? '<small class="muted" title="System agent - delete nahi hoga" style="font-size:15px">🔒</small>'
          : `<button class="btn btn-sm btn-red" data-adel="${a.key}" title="Delete karo">🗑</button>`}
      </div>
    </div>`).join('') || '<div class="empty">Koi agent nahi</div>';

  document.querySelectorAll('[data-weight]').forEach((el) => {
    el.addEventListener('input', () => ($(`w-${el.dataset.weight}`).textContent = el.value));
    el.addEventListener('change', async () => {
      await api(`/admin/agents/${el.dataset.weight}`, { method: 'PUT', body: { weight: Number(el.value) } });
      toast(`Weight update ho gaya ✅`, 'ok');
    });
  });
  document.querySelectorAll('[data-enable]').forEach((el) => el.addEventListener('change', async () => {
    await api(`/admin/agents/${el.dataset.enable}`, { method: 'PUT', body: { enabled: el.checked } });
    toast(`Agent ${el.checked ? 'ON' : 'OFF'} ✅`, 'ok');
  }));
  document.querySelectorAll('[data-aedit]').forEach((el) => el.addEventListener('click', () => {
    const a = agents.find((x) => x.key === el.dataset.aedit);
    if (a) startEditAgent(a);
  }));
  document.querySelectorAll('[data-adel]').forEach((el) => el.addEventListener('click', async () => {
    const a = agents.find((x) => x.key === el.dataset.adel);
    if (!a) return;
    if (!confirm(`Agent "${a.name}" ko team se hata dein?\n\n(Purane signals reports me dikhte rahenge)`)) return;
    try {
      await api(`/admin/agents/${a.key}`, { method: 'DELETE' });
      toast('Agent delete ho gaya 🗑', 'ok');
      loadAgents();
    } catch (e) { toast(e.message, 'err'); }
  }));
}

// ---------------- 🔮 Jyotish Guru ----------------
const PLANET_HI = {
  Sun: 'Surya ☀️', Moon: 'Chandra 🌙', Mars: 'Mangal 🔴', Mercury: 'Budh 💚', Jupiter: 'Guru 🟡',
  Venus: 'Shukra 🤍', Saturn: 'Shani 🪐', Rahu: 'Rahu 🐍', Ketu: 'Ketu ☄️',
};
const ph = (p) => PLANET_HI[p] || p || '-';
let astroEnabled = false;

async function loadAstro() {
  const { enabled, pick, history } = await api('/astro');
  astroEnabled = enabled;
  $('astroToggle').textContent = enabled ? '⏸️ Astro mode OFF karo' : '▶️ Astro mode ON karo';
  $('astroToggle').className = `btn btn-sm ${enabled ? 'btn-red' : 'btn-green'}`;
  if (pick) {
    const p = pick.panchang;
    $('aSymbol').textContent = pick.symbol;
    $('aPlanet').textContent = `${ph(pick.planet)} · Score ${pick.score} · ${enabled ? 'Team isi par analysis kar rahi hai' : 'Astro mode OFF'}`;
    $('aMsg').textContent = pick.message;
    const cell = (l, v, w) => `<div class="${w ? 'warn' : ''}"><small>${l}</small><b title="${esc(v)}">${esc(v)}</b></div>`;
    $('aPanchang').innerHTML = [
      cell('Date (IST)', p.dateIST), cell('Samay', p.timeIST), cell('Vaar', `${p.vaar} (${ph(p.dayLord)})`),
      cell('Hora', `${ph(p.horaLord)} ${p.horaWindow}`), cell('Tithi', p.tithi), cell('Nakshatra', `${p.nakshatra} (${ph(p.nakshatraLord)})`),
      cell('Chandra Rashi', `${p.moonRashi} (${ph(p.moonRashiLord)})`), cell('Rahu Kaal', `${p.rahuKaal ? '⚠️ ABHI · ' : ''}${p.rahuKaalWindow}`, p.rahuKaal),
    ].join('');
    $('aRank').innerHTML = table(['#', 'Token', 'Grah', 'Ank', 'Score', 'Kyun'], pick.ranking.map((r, i) => `
      <tr><td>${i === 0 ? '👑' : i + 1}</td><td><b>${esc(r.symbol)}</b></td><td>${ph(r.planet)}</td><td class="mono">${r.number}</td>
      <td class="mono"><b>${r.score.toFixed(2)}</b></td><td class="muted" style="white-space:normal;min-width:200px">${esc(r.why.join(', ') || 'koi khaas yog nahi')}</td></tr>`));
  }
  $('aHistory').innerHTML = table(['Time', 'Token', 'Grah', 'Vaar', 'Hora', 'Tithi', 'Nakshatra', 'Rahu Kaal', 'Score', 'Kaaran'], history.map((h) => `
    <tr><td class="muted">${fmt.dateTime(h.created_at)}</td><td><b>${esc(h.symbol)}</b></td><td>${ph(h.planet)}</td>
    <td>${esc(h.vaar)}</td><td>${ph(h.hora_lord)}</td><td>${esc(h.tithi)}</td><td>${esc(h.nakshatra)}</td>
    <td>${h.rahu_kaal ? '<span class="badge SELL">HAAN</span>' : '<span class="badge BUY">NAHI</span>'}</td>
    <td class="mono">${h.score.toFixed(2)}</td><td class="muted" style="white-space:normal;min-width:220px">${esc(h.reason)}</td></tr>`), 'Abhi koi pick nahi');
}

$('astroNow').addEventListener('click', async () => {
  await api('/astro/refresh', { method: 'POST' });
  toast('🔮 Panchang dobara dekha gaya', 'ok');
  loadAstro();
});
$('astroToggle').addEventListener('click', async () => {
  await api('/admin/settings', { method: 'PUT', body: { astro_mode: String(!astroEnabled) } });
  toast(`🔮 Astro mode ${astroEnabled ? 'OFF' : 'ON'}`, 'ok');
  loadAstro();
});

// ---------------- 🏦 Brokers ----------------
const BROKER_STYLE = {
  paper: ['P', '#7c5cff'], zerodha: ['Z', '#387ed1'], upstox: ['U', '#5a2d82'],
  angel: ['A', '#f26b21'], dhan: ['D', '#00a876'], fyers: ['F', '#1c4fd8'], delta: ['Δ', '#00b4d8'],
};
let brokerTypes = null;
let editingBroker = null;
let brokerList = [];   // saved brokers (card search ke liye)

const statusBadge = (s) => (s === 'ok' ? '<span class="badge BUY">✓ CONNECTED</span>'
  : s === 'error' ? '<span class="badge SELL">✗ ERROR</span>' : '<span class="badge HOLD">UNTESTED</span>');

// 🔍 Searchable broker picker - type karke filter, click karke select
function renderBrokerPicker(filter = '') {
  const q = String(filter || '').trim().toLowerCase();
  const entries = Object.entries(brokerTypes || {}).filter(([k, t]) => !q || k.includes(q) || t.label.toLowerCase().includes(q));
  const cur = $('bType').value;
  $('bPicker').innerHTML = entries.map(([k, t]) => {
    const [letter, color] = BROKER_STYLE[k] || ['?', '#555'];
    return `<button type="button" class="b-opt ${k === cur ? 'sel' : ''}" data-bpick="${k}">
      <span class="broker-logo bsm" style="background:${color}">${letter}</span>
      <span class="b-opt-txt"><b>${esc(t.label)}</b>
        <small>${t.live ? '<span class="badge live">LIVE 💰</span>' : '<span class="badge trader">DEMO</span>'}${t.needsToken ? ' · product_id chahiye' : ''}</small></span>
    </button>`;
  }).join('') || '<div class="muted" style="font-size:12.5px;padding:6px 0">Koi broker nahi mila - dusra naam type karein 👆</div>';
  document.querySelectorAll('[data-bpick]').forEach((el) => el.addEventListener('click', () => selectBrokerType(el.dataset.bpick)));
}

function selectBrokerType(k) {
  if (!brokerTypes[k]) return;
  $('bType').value = k;
  $('bSearch').value = brokerTypes[k].label;
  renderBrokerPicker('');
  renderBrokerFields();
}

function onBrokerTypeSearch(e) {
  renderBrokerPicker(e.target.value);
  // Search box ka text selected broker se alag hai to selection hata do (galat type par save na ho)
  const typed = e.target.value.trim().toLowerCase();
  const sel = brokerTypes[$('bType').value];
  if (!typed || !sel || typed !== sel.label.toLowerCase()) {
    if ($('bType').value) $('bType').value = '';
    renderBrokerFields();
  }
}

// Saved broker cards (naam/type se filter)
function renderBrokerCards() {
  const q = ($('bCardSearch')?.value || '').trim().toLowerCase();
  const shown = brokerList.filter((b) => !q
    || b.name.toLowerCase().includes(q)
    || (b.typeLabel || '').toLowerCase().includes(q)
    || b.type.includes(q));
  const byId = Object.fromEntries(brokerList.map((b) => [b.id, b]));
  $('brokerList').innerHTML = shown.map((b) => {
    const [letter, color] = BROKER_STYLE[b.type] || ['?', '#555'];
    const t = brokerTypes[b.type];
    const metaRows = [
      b.client_id && ['Client ID', esc(b.client_id)],
      b.api_key && ['API Key', esc(b.api_key)],
      b.has_api_secret && ['API Secret', '••••••••'],
      t?.fields.some((f) => f.key === 'access_token') && ['Access Token', b.has_access_token ? esc(b.access_token) : '<span class="down">missing</span>'],
      b.type !== 'paper' && ['Product', b.product],
      b.last_tested_at && ['Last test', fmt.dateTime(b.last_tested_at)],
    ].filter(Boolean);
    return `<div class="broker-card ${b.is_active ? 'active' : ''}">
      <div class="top">
        <div class="broker-logo" style="background:${color}">${letter}</div>
        <div style="min-width:0;flex:1"><b>${esc(b.name)}</b><br><small class="muted">${esc(b.typeLabel)}</small></div>
        ${b.is_active ? '<span class="badge BUY">ACTIVE</span>' : ''}
      </div>
      <div style="display:flex;gap:6px;flex-wrap:wrap">${b.live ? '<span class="badge live">LIVE 💰</span>' : '<span class="badge trader">PAPER</span>'} ${statusBadge(b.status)}</div>
      ${metaRows.length ? `<div class="meta">${metaRows.map(([k, v]) => `<span>${k}</span><b>${v}</b>`).join('')}</div>` : ''}
      ${b.status_msg ? `<div class="status ${b.status === 'error' ? 'down' : ''}">${esc(b.status_msg)}</div>` : ''}
      <div class="actions">
        <button class="btn btn-sm" data-btest="${b.id}">🔌 Test</button>
        ${b.is_active ? '' : `<button class="btn btn-sm btn-green" data-bact="${b.id}" data-live="${b.live}">✅ Activate</button>`}
        ${b.needs_access_token ? `<button class="btn btn-sm" data-tadd="${b.id}">🔑 ${b.has_access_token ? 'Token badlo' : 'Token add karo'}</button>` : ''}
        ${b.type !== 'paper' ? `<button class="btn btn-sm" data-bedit="${b.id}">✏️ Edit</button>` : ''}
        ${b.type === 'paper' && b.is_active ? '' : `<button class="btn btn-sm btn-red" data-bdel="${b.id}">🗑 Remove</button>`}
      </div>
    </div>`;
  }).join('') || `<div class="empty">${q ? `"${esc(q)}" se koi broker nahi mila` : 'Koi broker nahi'}</div>`;

  document.querySelectorAll('[data-tadd]').forEach((el) => el.addEventListener('click', () => addToken(byId[el.dataset.tadd])));
  document.querySelectorAll('[data-tdel]').forEach((el) => el.addEventListener('click', () => removeToken(byId[el.dataset.tdel])));
  document.querySelectorAll('[data-btest]').forEach((el) => el.addEventListener('click', async () => {
    el.disabled = true; el.textContent = '⏳ Testing…';
    try {
      const r = await api(`/admin/brokers/${el.dataset.btest}/test`, { method: 'POST' });
      toast(r.status === 'ok' ? `✅ ${esc(r.status_msg)}` : `❌ ${esc(r.status_msg)}`, r.status === 'ok' ? 'ok' : 'err');
    } catch (e) { toast(e.message, 'err'); }
    loadBrokers();
  }));
  document.querySelectorAll('[data-bact]').forEach((el) => el.addEventListener('click', async () => {
    const live = el.dataset.live === 'true';
    let confirmText = null;
    if (live) {
      confirmText = prompt('⚠️ LIVE broker = ASLI PAISA.\nAbhi market data simulated hai. Orders asli broker par jayenge.\n\nConfirm karne ke liye LIVE likhein:');
      if (confirmText === null) return;
    } else if (!confirm('Is broker ko active karein?')) return;
    try {
      await api(`/admin/brokers/${el.dataset.bact}/activate`, { method: 'POST', body: { confirm: confirmText } });
      toast('Broker active ho gaya ✅', 'ok');
    } catch (e) { toast(e.message, 'err'); }
    loadBrokers();
  }));
  document.querySelectorAll('[data-bedit]').forEach((el) => el.addEventListener('click', () => startEditBroker(byId[el.dataset.bedit])));
  document.querySelectorAll('[data-bdel]').forEach((el) => el.addEventListener('click', () => removeBroker(byId[el.dataset.bdel])));
}

async function loadBrokers() {
  if (!brokerTypes) {
    brokerTypes = await api('/admin/broker-types');
    renderBrokerPicker('');
    selectBrokerType('zerodha');
    $('bSearch').addEventListener('input', onBrokerTypeSearch);
    $('bSearch').addEventListener('focus', (e) => { e.target.select(); renderBrokerPicker(''); });
    $('bCardSearch').addEventListener('input', renderBrokerCards);
  }
  const [list, s] = await Promise.all([api('/admin/brokers'), api('/admin/settings')]);
  $('liveForm').elements.allow_live_ai.value = s.allow_live_ai;
  $('liveForm').elements.live_max_order_value.value = s.live_max_order_value;

  const active = list.find((b) => b.is_active);
  $('activeBrokerBadge').className = `badge ${active?.live ? 'live' : 'BUY'}`;
  $('activeBrokerBadge').textContent = active ? `ACTIVE: ${active.name}${active.live ? ' · LIVE 🔴' : ' · PAPER'}` : '—';

  brokerList = list;
  renderBrokerCards();
  renderTokenTable(list);
}

// Token kitna purana hai (tokens roz expire hote hain)
function tokenAge(b) {
  if (!b.has_access_token) return '<span class="token-age none">❌ Token nahi hai</span>';
  if (!b.token_updated_at) return '<span class="token-age old">⚠️ Date pata nahi</span>';
  const today = new Date().toDateString() === new Date(b.token_updated_at).toDateString();
  return today ? '<span class="token-age fresh">✅ Aaj ka</span>' : '<span class="token-age old">⚠️ Purana - naya daalein</span>';
}

function renderTokenTable(list) {
  const rows = list.filter((b) => b.needs_access_token);
  $('tokenTable').innerHTML = table(['Broker', 'Token', 'Kab daala', 'Haalat', 'Connection', ''], rows.map((b) => `
    <tr><td><b>${esc(b.name)}</b><br><small class="muted">${esc(b.typeLabel)}</small>${b.is_active ? ' <span class="badge BUY">ACTIVE</span>' : ''}</td>
    <td class="mono">${b.has_access_token ? esc(b.access_token) : '-'}</td>
    <td class="muted">${b.token_updated_at ? fmt.dateTime(b.token_updated_at) : '-'}</td>
    <td>${tokenAge(b)}</td>
    <td>${statusBadge(b.status)}</td>
    <td style="display:flex;gap:6px;flex-wrap:wrap">
      <button class="btn btn-sm btn-green" data-tadd="${b.id}">🔑 ${b.has_access_token ? 'Badlo' : 'Add karo'}</button>
      ${b.has_access_token ? `<button class="btn btn-sm btn-red" data-tdel="${b.id}">🧹 Hatao</button>` : ''}
    </td></tr>`), 'Abhi koi LIVE broker nahi jisko token chahiye. Upar "➕ Broker add karo" dabayein.');
}

async function addToken(b) {
  const v = await openModal({
    title: `🔑 ${b.has_access_token ? 'Naya access token' : 'Access token add karo'} · ${esc(b.name)}`,
    message: `${esc(b.typeLabel)} ka aaj ka access token paste karein. Save hote hi connection test hoga.`
      + (b.has_access_token ? `<br>Abhi wala token: <span class="mono">${esc(b.access_token)}</span>` : ''),
    fields: [{ name: 'access_token', label: 'Access Token', type: 'password', required: true, placeholder: 'yahan paste karein' }],
    submitText: '💾 Save + Test',
  });
  if (!v) return;
  try {
    const r = await api(`/admin/brokers/${b.id}/token`, { method: 'PUT', body: v });
    toast(r.status === 'ok' ? `✅ Token save + connected: ${esc(r.status_msg)}` : `⚠️ Token save hua lekin test fail: ${esc(r.status_msg)}`, r.status === 'ok' ? 'ok' : 'err');
  } catch (e) { toast(e.message, 'err'); }
  loadBrokers();
}

async function removeToken(b) {
  const ok = await openModal({
    title: `🧹 Token hatao · ${esc(b.name)}`,
    message: `Is broker ka access token delete ho jayega (account aur API key bani rahegi).`
      + (b.is_active && b.live ? '<br><b class="down">⚠️ Ye ACTIVE LIVE broker hai - naya token daalne tak orders fail honge.</b>' : ''),
    submitText: '🧹 Haan, token hatao',
    danger: true,
  });
  if (!ok) return;
  try {
    const r = await api(`/admin/brokers/${b.id}/token`, { method: 'DELETE' });
    toast(r.warning ? `Token hata diya · ⚠️ ${esc(r.warning)}` : 'Token hata diya ✅', r.warning ? 'err' : 'ok');
  } catch (e) { toast(e.message, 'err'); }
  loadBrokers();
}

async function removeBroker(b) {
  const ok = await openModal({
    title: `🗑 Broker remove · ${esc(b.name)}`,
    message: `"${esc(b.name)}" aur uski saari saved keys/tokens hamesha ke liye delete ho jayengi.`
      + (b.is_active ? '<br><b>Ye ACTIVE broker hai</b> - remove karne par system apne aap <b>Paper Trading</b> par aa jayega.' : ''),
    submitText: '🗑 Haan, remove karo',
    danger: true,
  });
  if (!ok) return;
  try {
    const r = await api(`/admin/brokers/${b.id}`, { method: 'DELETE' });
    toast(r.switchedTo ? `Broker remove ✅ · Ab active: ${esc(r.switchedTo)}` : 'Broker remove ho gaya ✅', 'ok');
    if (editingBroker?.id === b.id) resetBrokerForm();
  } catch (e) { toast(e.message, 'err'); }
  loadBrokers();
}

$('addBrokerBtn').addEventListener('click', () => {
  resetBrokerForm();
  $('brokerFormCard').scrollIntoView({ behavior: 'smooth' });
  setTimeout(() => $('brokerForm').elements.name.focus(), 400);
});

function renderBrokerFields() {
  const t = brokerTypes[$('bType').value];
  if (!t) {
    $('bFields').innerHTML = '<div class="muted" style="font-size:12.5px">👆 Upar search karke broker chunein - uske credentials yahan aayenge.</div>';
    $('bHelp').innerHTML = '';
    return;
  }
  const editing = !!editingBroker;
  const secretKeys = ['api_secret', 'access_token'];
  $('bFields').innerHTML = t.fields.map((f) => {
    const isSecret = secretKeys.includes(f.key) || f.key === 'api_key';
    const value = editing && f.key === 'client_id' ? esc(editingBroker.client_id) : '';
    const ph = editing && isSecret ? 'Khali chhodein = purana rakhein' : '';
    return `<div class="field"><label>${esc(f.label)}</label>
      <input class="input" name="${f.key}" type="${isSecret ? 'password' : 'text'}" autocomplete="off" value="${value}" placeholder="${ph}" /></div>`;
  }).join('') || '<div class="muted" style="font-size:12px">Is broker ke liye koi credentials nahi chahiye.</div>';
  $('bHelp').innerHTML = `${t.live ? '🔴 <b>LIVE broker</b> - asli orders lagenge. ' : '🟢 '}${esc(t.help)}`
    + (t.needsToken ? `<br>📌 Har symbol ke liye <b>${esc(t.tokenLabel)}</b> Admin → Symbols me "Broker token" me daalna zaroori hai.` : '')
    + (t.tokenLabel && !t.needsToken ? `<br>📌 Optional: Symbols me ${esc(t.tokenLabel)}.` : '')
    + (t.docs ? `<br>📖 Docs: <a href="${t.docs}" target="_blank" rel="noopener">${t.docs}</a>` : '');
}

function startEditBroker(b) {
  editingBroker = b;
  const f = $('brokerForm');
  f.elements.type.value = b.type;
  f.elements.type.disabled = true;
  $('bSearch').value = brokerTypes[b.type]?.label || b.type;
  renderBrokerPicker('');
  f.elements.name.value = b.name;
  f.elements.product.value = b.product;
  renderBrokerFields();
  $('brokerFormTitle').textContent = `✏️ Edit: ${b.name}`;
  $('brokerCancel').style.display = '';
  $('brokerFormCard').scrollIntoView({ behavior: 'smooth' });
}

function resetBrokerForm() {
  editingBroker = null;
  const f = $('brokerForm');
  f.reset();
  f.elements.type.disabled = false;
  selectBrokerType('zerodha');
  $('brokerFormTitle').textContent = '➕ Naya Broker jodo';
  $('brokerCancel').style.display = 'none';
}

$('bType').addEventListener('change', renderBrokerFields);
$('brokerCancel').addEventListener('click', resetBrokerForm);
$('brokerForm').addEventListener('submit', async (e) => {
  e.preventDefault();
  const body = Object.fromEntries(new FormData(e.target));
  if (!editingBroker && !body.type) {
    toast('👆 Pehle broker search karke chunna padega', 'err');
    $('bSearch').focus();
    return;
  }
  try {
    if (editingBroker) await api(`/admin/brokers/${editingBroker.id}`, { method: 'PUT', body });
    else await api('/admin/brokers', { method: 'POST', body });
    toast(editingBroker ? 'Broker update ho gaya ✅ (ab Test karein)' : 'Broker add ho gaya ✅ - ab 🔌 Test dabayein', 'ok');
    resetBrokerForm();
    loadBrokers();
  } catch (err) { toast(err.message, 'err'); }
});
$('liveForm').addEventListener('submit', async (e) => {
  e.preventDefault();
  try {
    await api('/admin/settings', { method: 'PUT', body: Object.fromEntries(new FormData(e.target)) });
    toast('Safety settings save ✅', 'ok');
  } catch (err) { toast(err.message, 'err'); }
});

// ---------------- 🔑 API Keys ----------------
let providers = null;
const KEY_FIELD = {
  key: ['API Key', 'password'], base_url: ['Base URL', 'text'], model: ['Model', 'text'],
};

async function loadApiKeys() {
  if (!providers) {
    providers = await api('/admin/api-providers');
    $('kProvider').innerHTML = Object.entries(providers).map(([k, p]) => `<option value="${k}">${esc(p.label)}</option>`).join('');
    renderKeyFields();
  }
  const list = await api('/admin/api-keys');
  $('keyTable').innerHTML = table(['Provider', 'Naam', 'Key', 'Model / URL', 'Status', 'ON', ''], list.map((k) => `
    <tr><td><b>${esc(k.providerLabel)}</b></td><td>${esc(k.name)}</td><td class="mono">${esc(k.key) || '-'}</td>
    <td class="muted">${esc(k.model || k.base_url || '-')}</td>
    <td>${statusBadge(k.status)}${k.status_msg ? `<br><small class="${k.status === 'error' ? 'down' : 'muted'}" style="white-space:normal">${esc(k.status_msg)}</small>` : ''}</td>
    <td><label class="switch" style="padding:4px 6px;border:0;background:none"><input type="checkbox" data-kon="${k.id}" ${k.enabled ? 'checked' : ''} /><span class="track"></span></label></td>
    <td style="display:flex;gap:6px"><button class="btn btn-sm" data-ktest="${k.id}">🔌 Test</button>
      <button class="btn btn-sm btn-red" data-kdel="${k.id}">🗑</button></td></tr>`), 'Abhi koi API key nahi. Neeche se jodein 👇');

  document.querySelectorAll('[data-ktest]').forEach((el) => el.addEventListener('click', async () => {
    el.disabled = true; el.textContent = '⏳';
    try {
      const r = await api(`/admin/api-keys/${el.dataset.ktest}/test`, { method: 'POST' });
      toast(r.status === 'ok' ? `✅ ${esc(r.status_msg)}` : `❌ ${esc(r.status_msg)}`, r.status === 'ok' ? 'ok' : 'err');
    } catch (e) { toast(e.message, 'err'); }
    loadApiKeys();
  }));
  document.querySelectorAll('[data-kon]').forEach((el) => el.addEventListener('change', async () => {
    try { await api(`/admin/api-keys/${el.dataset.kon}`, { method: 'PUT', body: { enabled: el.checked } }); toast(`Key ${el.checked ? 'ON' : 'OFF'}`, 'ok'); } catch (e) { toast(e.message, 'err'); }
  }));
  document.querySelectorAll('[data-kdel]').forEach((el) => el.addEventListener('click', async () => {
    if (!confirm('Ye API key delete karein?')) return;
    await api(`/admin/api-keys/${el.dataset.kdel}`, { method: 'DELETE' });
    loadApiKeys();
  }));
}

function renderKeyFields() {
  const p = providers[$('kProvider').value];
  $('kFields').innerHTML = p.fields.map((f) => `<div class="field"><label>${KEY_FIELD[f][0]}</label>
    <input class="input" name="${f}" type="${KEY_FIELD[f][1]}" autocomplete="off" placeholder="${esc(p.defaults[f] || '')}" /></div>`).join('');
  $('kHelp').innerHTML = `💡 ${esc(p.usedBy)}`
    + (p.docs ? `<br>🔗 Key yahan se milegi: <a href="${p.docs}" target="_blank" rel="noopener">${p.docs}</a>` : '')
    + ($('kProvider').value === 'newsapi' ? '<br>📰 NewsAPI + (OpenAI ya Gemini) dono jodne par news sentiment pipeline live headlines par chalegi.' : '');
}

$('kProvider').addEventListener('change', renderKeyFields);
$('keyForm').addEventListener('submit', async (e) => {
  e.preventDefault();
  try {
    const r = await api('/admin/api-keys', { method: 'POST', body: Object.fromEntries(new FormData(e.target)) });
    e.target.reset();
    renderKeyFields();
    toast('API key save ✅ - test ho raha hai…', 'ok');
    const t = await api(`/admin/api-keys/${r.id}/test`, { method: 'POST' });
    toast(t.status === 'ok' ? `✅ ${esc(t.status_msg)}` : `❌ ${esc(t.status_msg)}`, t.status === 'ok' ? 'ok' : 'err');
    loadApiKeys();
  } catch (err) { toast(err.message, 'err'); }
});

// ---------------- Symbols ----------------
async function loadSymbols() {
  const list = await api('/symbols');
  $('symCount').textContent = `${list.length} tokens live`;
  const bySym = Object.fromEntries(list.map((s) => [s.symbol, s]));
  $('symTable').innerHTML = table(['Token', 'Name', 'Exchange', '🔮 Grah', '🏦 Broker ID', 'LTP', 'Change', ''], list.map((s) => `
    <tr><td><b>${esc(s.symbol)}</b></td><td>${esc(s.name)}</td><td>${esc(s.exchange)}</td>
    <td>${s.planet ? ph(s.planet) : '<span class="muted">Auto (ank)</span>'}</td>
    <td>${s.broker_token ? `<span class="mono">${esc(s.broker_token)}</span>` : '<span class="muted">-</span>'}</td>
    <td class="mono">${fmt.num(s.quote?.price)}</td>
    <td class="mono ${fmt.cls(s.quote?.change)}">${fmt.pct(s.quote?.changePct)}</td>
    <td style="display:flex;gap:6px;flex-wrap:wrap">
      <button class="btn btn-sm" data-tok="${esc(s.symbol)}">🏦 ${s.broker_token ? 'ID badlo' : 'ID add'}</button>
      ${s.broker_token ? `<button class="btn btn-sm" data-tokdel="${esc(s.symbol)}" title="Broker ID hatao">🧹 ID hatao</button>` : ''}
      <button class="btn btn-sm btn-red" data-del-sym="${esc(s.symbol)}">🗑 Remove</button>
    </td></tr>`), 'Koi token nahi. Upar se add karein 👆');

  document.querySelectorAll('[data-tok]').forEach((b) => b.addEventListener('click', async () => {
    const s = bySym[b.dataset.tok];
    const v = await openModal({
      title: `🏦 Broker ID · ${esc(s.symbol)}`,
      message: 'Har broker is share ko apne ID se pehchanta hai:',
      fields: [{
        name: 'broker_token', label: 'Broker instrument ID', value: s.broker_token || '', required: true,
        placeholder: 'jaise NSE_EQ|INE009A01021 ya 1594',
        help: 'Upstox: instrument_key (NSE_EQ|INE...) · Dhan: securityId · Angel: symboltoken · Zerodha/Fyers: zaroori nahi',
      }],
      submitText: '💾 Save',
    });
    if (!v) return;
    try {
      await api(`/admin/symbols/${encodeURIComponent(s.symbol)}`, { method: 'PUT', body: v });
      toast(`${esc(s.symbol)} ka broker ID save ✅`, 'ok');
      loadSymbols();
    } catch (e) { toast(e.message, 'err'); }
  }));
  document.querySelectorAll('[data-tokdel]').forEach((b) => b.addEventListener('click', async () => {
    try {
      await api(`/admin/symbols/${encodeURIComponent(b.dataset.tokdel)}`, { method: 'PUT', body: { broker_token: '' } });
      toast(`${esc(b.dataset.tokdel)} ka broker ID hata diya`, 'ok');
      loadSymbols();
    } catch (e) { toast(e.message, 'err'); }
  }));
  document.querySelectorAll('[data-del-sym]').forEach((b) => b.addEventListener('click', async () => {
    const sym = b.dataset.delSym;
    const ok = await openModal({
      title: `🗑 Token remove · ${esc(sym)}`,
      message: `<b>${esc(sym)}</b> watchlist, live chart aur AI analysis se hat jayega.<br>Agar iski koi position open hai to wo market price par close ho jayegi.`,
      submitText: '🗑 Haan, remove karo',
      danger: true,
    });
    if (!ok) return;
    try {
      await api(`/admin/symbols/${encodeURIComponent(sym)}`, { method: 'DELETE' });
      toast(`${esc(sym)} remove ho gaya ✅`, 'ok');
      loadSymbols();
    } catch (e) { toast(e.message, 'err'); }
  }));
}

$('symForm').addEventListener('submit', async (e) => {
  e.preventDefault();
  try {
    await api('/admin/symbols', { method: 'POST', body: Object.fromEntries(new FormData(e.target)) });
    e.target.reset();
    toast('Token add ho gaya ✅ (live chart + AI analysis shuru)', 'ok');
    loadSymbols();
  } catch (err) { toast(err.message, 'err'); }
});

// ---------------- Trades ----------------
async function loadTrades() {
  const trades = await api('/trades?limit=500');
  $('tradesTable').innerHTML = table(['#', 'Opened', 'Symbol', 'Side', 'Qty', 'Entry', 'Exit', 'SL / TGT', 'P&L', 'Status', 'Source', 'Reason'], trades.map((t) => `
    <tr><td class="muted">${t.id}</td><td class="muted">${fmt.dateTime(t.opened_at)}</td><td><b>${esc(t.symbol)}</b></td>
    <td><span class="badge ${t.side}">${t.side}</span></td><td class="mono">${t.qty}</td>
    <td class="mono">${fmt.num(t.entry_price)}</td><td class="mono">${fmt.num(t.exit_price)}</td>
    <td class="mono">${fmt.num(t.stop_loss)} / ${fmt.num(t.target)}</td>
    <td class="mono ${fmt.cls(t.pnl)}">${t.pnl == null ? '-' : fmt.signed(t.pnl)}</td>
    <td><span class="badge ${t.status === 'OPEN' ? 'info' : 'trade'}">${t.status}</span></td>
    <td>${esc(t.source)}</td><td class="muted">${esc(t.exit_reason || '')}</td></tr>`), 'Abhi koi trade nahi');
}

// ---------------- Users ----------------
async function loadUsers() {
  const users = await api('/admin/users');
  $('userTable').innerHTML = table(['#', 'Name', 'Email', 'Role', 'Created', ''], users.map((u) => `
    <tr><td class="muted">${u.id}</td><td><b>${esc(u.name)}</b></td><td>${esc(u.email)}</td>
    <td><span class="badge ${u.role}">${u.role}</span></td><td class="muted">${fmt.dateTime(u.created_at)}</td>
    <td>${u.id === Auth.user.id ? '<small class="muted">you</small>' : `<button class="btn btn-sm btn-red" data-del-user="${u.id}">Delete</button>`}</td></tr>`));
  document.querySelectorAll('[data-del-user]').forEach((b) => b.addEventListener('click', async () => {
    if (!confirm('User delete karein?')) return;
    await api(`/admin/users/${b.dataset.delUser}`, { method: 'DELETE' });
    loadUsers();
  }));
}

$('userForm').addEventListener('submit', async (e) => {
  e.preventDefault();
  try {
    await api('/admin/users', { method: 'POST', body: Object.fromEntries(new FormData(e.target)) });
    e.target.reset();
    toast('User ban gaya ✅', 'ok');
    loadUsers();
  } catch (err) { toast(err.message, 'err'); }
});

// ---------------- Settings ----------------
async function loadSettings() {
  const s = await api('/admin/settings');
  const form = $('settingsForm');
  for (const [k, v] of Object.entries(s)) if (form.elements[k]) form.elements[k].value = v;
}

$('settingsForm').addEventListener('submit', async (e) => {
  e.preventDefault();
  try {
    await api('/admin/settings', { method: 'PUT', body: Object.fromEntries(new FormData(e.target)) });
    toast('Settings save ho gayi ✅', 'ok');
  } catch (err) { toast(err.message, 'err'); }
});

// ---------------- Logs ----------------
async function loadLogs() {
  const logs = await api('/admin/logs');
  $('logTable').innerHTML = table(['Time', 'Level', 'Message'], logs.map((l) => `
    <tr><td class="muted">${fmt.dateTime(l.created_at)}</td>
    <td><span class="badge ${l.level === 'error' ? 'error' : l.level === 'trade' ? 'trade' : 'info'}">${l.level}</span></td>
    <td style="white-space:normal">${esc(l.message)}</td></tr>`));
}

show('overview');
