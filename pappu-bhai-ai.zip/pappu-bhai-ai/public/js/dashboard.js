/* ================= Pappu Bhai AI - Dashboard ================= */
if (!Auth.require()) throw new Error('auth');
setupShell();

const $ = (id) => document.getElementById(id);

// ---------------- Time frames (chart) ----------------
const TIMEFRAMES = [
  { key: '5s', sec: 5 }, { key: '15s', sec: 15 }, { key: '1m', sec: 60 },
  { key: '5m', sec: 300 }, { key: '15m', sec: 900 }, { key: '1h', sec: 3600 },
];
const savedTf = localStorage.getItem('pb_tf');

const state = {
  symbols: {},          // symbol -> {symbol, name, quote}
  selected: null,
  rawCandles: [],       // server ki base (5s) candles
  candles: [],          // abhi selected time frame ki aggregated candles
  agents: [],           // agent config
  signals: {},          // symbol -> { agentKey: signal }
  decisions: {},        // symbol -> decision
  positions: [],
  trades: [],
  tab: 'positions',
  tf: TIMEFRAMES.some((t) => t.key === savedTf) ? savedTf : '1m',
  wallet: null,         // 💰 balance + transactions
  walletSig: '',
  astro: null,          // Jyotish Guru ka current pick
};

const tfSec = () => TIMEFRAMES.find((t) => t.key === state.tf)?.sec || 60;

const PLANET_HI = {
  Sun: 'Surya ☀️', Moon: 'Chandra 🌙', Mars: 'Mangal 🔴', Mercury: 'Budh 💚', Jupiter: 'Guru 🟡',
  Venus: 'Shukra 🤍', Saturn: 'Shani 🪐', Rahu: 'Rahu 🐍', Ketu: 'Ketu ☄️',
};

// ---------------- Chart ----------------
const chartEl = $('chart');
const chart = LightweightCharts.createChart(chartEl, {
  layout: { background: { type: 'solid', color: 'transparent' }, textColor: '#8b95b8', fontFamily: 'Inter, system-ui' },
  grid: { vertLines: { color: 'rgba(120,140,200,0.06)' }, horzLines: { color: 'rgba(120,140,200,0.06)' } },
  rightPriceScale: { borderColor: 'rgba(120,140,200,0.15)' },
  timeScale: { borderColor: 'rgba(120,140,200,0.15)', timeVisible: true, secondsVisible: tfSec() < 60 },
  crosshair: { mode: LightweightCharts.CrosshairMode.Normal },
  localization: { priceFormatter: (p) => '₹' + p.toFixed(2) },
});
const candleSeries = chart.addCandlestickSeries({
  upColor: '#16c784', downColor: '#f0435a', borderVisible: false, wickUpColor: '#16c784', wickDownColor: '#f0435a',
});
const volSeries = chart.addHistogramSeries({ priceFormat: { type: 'volume' }, priceScaleId: 'vol', lastValueVisible: false, priceLineVisible: false });
chart.priceScale('vol').applyOptions({ scaleMargins: { top: 0.82, bottom: 0 } });
const ema9S = chart.addLineSeries({ color: '#f5b301', lineWidth: 1.5, priceLineVisible: false, lastValueVisible: false });
const ema21S = chart.addLineSeries({ color: '#00d4ff', lineWidth: 1.5, priceLineVisible: false, lastValueVisible: false });
const ema50S = chart.addLineSeries({ color: '#b4a3ff', lineWidth: 1.5, priceLineVisible: false, lastValueVisible: false });
let slLine = null, tgtLine = null, entryLine = null;

new ResizeObserver(() => chart.applyOptions({ width: chartEl.clientWidth, height: chartEl.clientHeight })).observe(chartEl);

function ema(values, p) {
  const k = 2 / (p + 1), out = [];
  let prev = null;
  values.forEach((v, i) => {
    if (i < p - 1) return out.push(null);
    if (prev === null) prev = values.slice(0, p).reduce((a, b) => a + b, 0) / p;
    else prev = v * k + prev * (1 - k);
    out.push(prev);
  });
  return out;
}

const volBar = (c) => ({ time: c.time, value: c.volume, color: c.close >= c.open ? 'rgba(22,199,132,0.35)' : 'rgba(240,67,90,0.35)' });

function emaData(period) {
  const vals = ema(state.candles.map((c) => c.close), period);
  return state.candles.map((c, i) => (vals[i] == null ? null : { time: c.time, value: vals[i] })).filter(Boolean);
}

/** Base (5s) candles ko selected time frame ki candles me merge karo */
function aggregateCandles(raw, sec) {
  const out = [];
  for (const c of raw) {
    const bucket = Math.floor(c.time / sec) * sec;
    const last = out[out.length - 1];
    if (last && last.time === bucket) {
      last.high = Math.max(last.high, c.high);
      last.low = Math.min(last.low, c.low);
      last.close = c.close;
      last.volume += c.volume;
    } else {
      out.push({ time: bucket, open: c.open, high: c.high, low: c.low, close: c.close, volume: c.volume });
    }
  }
  return out;
}

// chart par aakhri kis bucket tak data gaya hai (update() hamesha isi se aage chahiye)
let lastDrawnTime = null;

function drawChart() {
  candleSeries.setData(state.candles);
  volSeries.setData(state.candles.map(volBar));
  ema9S.setData(emaData(9));
  ema21S.setData(emaData(21));
  ema50S.setData(emaData(50));
  lastDrawnTime = state.candles.length ? state.candles[state.candles.length - 1].time : null;
  drawTradeOverlay();
}

function updateChartCandle(c) {
  const raw = state.rawCandles;
  const last = raw[raw.length - 1];
  if (last && last.time === c.time) raw[raw.length - 1] = c;
  else if (!last || c.time > last.time) raw.push(c);
  else return;
  if (raw.length > 7000) raw.shift();

  const arr = aggregateCandles(raw, tfSec());
  state.candles = arr;
  if (!arr.length) return;

  // sirf wo bucket update karo jo nayi hai / badli hai (ascending order me)
  arr.forEach((b) => {
    if (lastDrawnTime != null && b.time < lastDrawnTime) return;
    candleSeries.update(b);
    volSeries.update(volBar(b));
    lastDrawnTime = b.time;
  });
  [[ema9S, 9], [ema21S, 21], [ema50S, 50]].forEach(([s, p]) => {
    const d = emaData(p);
    if (d.length) s.update(d[d.length - 1]);
  });
}

/** Time frame badlo (buttons chart ke upar) */
function setTimeframe(tf) {
  if (!TIMEFRAMES.some((t) => t.key === tf) || tf === state.tf) return;
  state.tf = tf;
  localStorage.setItem('pb_tf', tf);
  renderTfButtons();
  chart.applyOptions({ timeScale: { timeVisible: true, secondsVisible: tfSec() < 60 } });
  state.candles = aggregateCandles(state.rawCandles, tfSec());
  drawChart();
  chart.timeScale().scrollToRealTime();
}

function renderTfButtons() {
  document.querySelectorAll('.tf-btn').forEach((b) => b.classList.toggle('active', b.dataset.tf === state.tf));
}

function drawTradeOverlay() {
  const sym = state.selected;
  const sec = tfSec();
  const snap = (ms) => Math.floor(ms / 1000 / sec) * sec;
  const first = state.candles[0]?.time || 0;
  const byTime = new Map(); // ek time par ek hi marker (bade time frame me do trade ek bucket me)
  state.trades.filter((t) => t.symbol === sym).forEach((t) => {
    const long = t.side === 'LONG';
    if (snap(t.opened_at) >= first) byTime.set(snap(t.opened_at), {
      time: snap(t.opened_at), position: long ? 'belowBar' : 'aboveBar', color: long ? '#16c784' : '#f0435a',
      shape: long ? 'arrowUp' : 'arrowDown', text: `${long ? 'BUY' : 'SHORT'} ${t.qty}`,
    });
    if (t.closed_at && snap(t.closed_at) >= first) byTime.set(snap(t.closed_at), {
      time: snap(t.closed_at), position: long ? 'aboveBar' : 'belowBar', color: t.pnl >= 0 ? '#16c784' : '#f0435a',
      shape: 'circle', text: `EXIT ${t.pnl >= 0 ? '+' : ''}${Math.round(t.pnl)}`,
    });
  });
  const markers = [...byTime.values()].sort((a, b) => a.time - b.time);
  candleSeries.setMarkers(markers);

  [slLine, tgtLine, entryLine].forEach((l) => l && candleSeries.removePriceLine(l));
  slLine = tgtLine = entryLine = null;
  const pos = state.positions.find((p) => p.symbol === sym);
  if (pos) {
    entryLine = candleSeries.createPriceLine({ price: pos.entry_price, color: '#8b95b8', lineStyle: 2, title: `ENTRY ${pos.side}` });
    slLine = candleSeries.createPriceLine({ price: pos.stop_loss, color: '#f0435a', lineStyle: 2, title: 'SL' });
    tgtLine = candleSeries.createPriceLine({ price: pos.target, color: '#16c784', lineStyle: 2, title: 'TARGET' });
  }
}

// ---------------- Watchlist ----------------
function renderWatchlist() {
  $('watchlist').innerHTML = Object.values(state.symbols).map((s) => {
    const q = s.quote || {};
    const astroTag = state.astro?.symbol === s.symbol ? '<span class="astro-tag" title="Jyotish Guru ka pick">🔮</span>' : '';
    return `<div class="watch-item ${s.symbol === state.selected ? 'active' : ''}" data-sym="${esc(s.symbol)}">
      <div><b>${esc(s.symbol)}${astroTag}</b><small>${esc(s.name)}</small></div>
      <div class="px mono"><b id="wp-${esc(s.symbol)}">${fmt.num(q.price)}</b>
      <small id="wc-${esc(s.symbol)}" class="${fmt.cls(q.change)}">${fmt.pct(q.changePct)}</small></div></div>`;
  }).join('');
  $('watchlist').querySelectorAll('.watch-item').forEach((el) => el.addEventListener('click', () => {
    selectSymbol(el.dataset.sym);
    document.querySelector('.sidebar').classList.remove('open');
  }));
}

function renderHeader() {
  const s = state.symbols[state.selected];
  if (!s) return;
  const q = s.quote || {};
  $('symName').textContent = `${s.symbol} · ${s.name}`;
  $('symPrice').textContent = fmt.inr(q.price);
  $('symChange').className = `mono ${fmt.cls(q.change)}`;
  $('symChange').textContent = `${q.change >= 0 ? '+' : ''}${fmt.num(q.change)} (${fmt.pct(q.changePct)})`;
  document.title = `${s.symbol} ${fmt.num(q.price)} · Pappu Bhai AI`;
}

// ---------------- Agents ----------------
function renderAgents() {
  const sigs = state.signals[state.selected] || {};
  $('agents').innerHTML = state.agents.map((a) => {
    const s = sigs[a.key];
    const action = s?.action || '—';
    const isRisk = a.key === 'risk';
    const badge = isRisk ? (s ? (s.veto || s.data?.veto ? '<span class="badge SELL">VETO</span>' : '<span class="badge BUY">SAFE</span>') : '')
      : (s ? `<span class="badge ${action}">${action}</span>` : '');
    return `<div class="card agent ${a.enabled ? '' : 'disabled'}" id="agent-${a.key}">
      <div class="agent-top">
        <div class="agent-icon">${a.icon}</div>
        <div><div class="agent-name">${esc(a.name)}</div>
        <div class="agent-weight">${isRisk ? 'Veto power' : `Weight ×${a.weight}`}${a.enabled ? '' : ' · OFF'}</div></div>
        <span id="agent-badge-${a.key}">${badge}</span>
      </div>
      <div class="agent-reason" id="agent-reason-${a.key}">${s ? esc(s.reason) : esc(a.description)}</div>
      <div class="conf-bar"><span id="agent-conf-${a.key}" style="width:${s ? Math.round(s.confidence * 100) : 0}%"></span></div>
      <div class="agent-foot"><span id="agent-pct-${a.key}">Confidence ${s ? Math.round(s.confidence * 100) + '%' : '—'}</span>
      <span id="agent-time-${a.key}">${s?.tookMs ? s.tookMs + 'ms' : ''}</span></div>
    </div>`;
  }).join('');
}

function setAgentWorking(keys) {
  keys.forEach((k) => {
    const el = $(`agent-${k}`);
    if (!el) return;
    el.classList.add('working');
    $(`agent-reason-${k}`).innerHTML = '<span class="muted">Analysis chal raha hai… 🔍</span>';
  });
}

// ---------------- Pappu Bhai ----------------
function renderDecision(d) {
  if (!d) return;
  $('decSym').textContent = d.symbol;
  $('decAction').className = `decision-action ${d.action}`;
  $('decAction').textContent = d.action;
  $('decMeta').textContent = `Score ${Number(d.score).toFixed(2)} · Confidence ${Math.round(d.confidence * 100)}% · @ ${fmt.inr(d.price)} · ${fmt.time(d.time || d.created_at)}`;
  $('needle').style.left = `${50 + Math.max(-1, Math.min(1, d.score)) * 50}%`;
  $('decSummary').textContent = d.summary;
  const v = d.votes || {};
  $('vBuy').textContent = v.BUY ?? '-';
  $('vHold').textContent = v.HOLD ?? '-';
  $('vSell').textContent = v.SELL ?? '-';
  $('pappuAvatar').textContent = { BUY: '🤑', SELL: '😤', HOLD: '😎' }[d.action];
}

// ---------------- 🔮 Jyotish Guru ----------------
function renderAstro(pick) {
  if (!pick) return;
  const prev = state.astro?.symbol;
  state.astro = pick;
  const p = pick.panchang;

  $('astroMode').className = `badge ${pick.enabled ? 'BUY' : 'HOLD'}`;
  $('astroMode').textContent = pick.enabled ? 'ASTRO MODE ON · team isi token par' : 'ASTRO MODE OFF · sab tokens';
  $('astroSymbol').textContent = pick.symbol;
  if (prev && prev !== pick.symbol) {
    $('astroSymbol').classList.remove('changed'); void $('astroSymbol').offsetWidth; $('astroSymbol').classList.add('changed');
  }
  $('astroPlanet').textContent = `Swami grah: ${PLANET_HI[pick.planet] || pick.planet} · Score ${pick.score}`;
  $('astroMsg').textContent = pick.reason;

  const cell = (label, value, warn = false) => `<div class="${warn ? 'warn' : ''}"><small>${label}</small><b title="${esc(value)}">${esc(value)}</b></div>`;
  $('panchang').innerHTML = [
    cell('Date (IST)', p.dateIST),
    cell('Samay', p.timeIST),
    cell('Vaar', `${p.vaar}`),
    cell('Hora', `${PLANET_HI[p.horaLord]} ${p.horaWindow}`),
    cell('Tithi', p.tithi),
    cell('Nakshatra', `${p.nakshatra} (${PLANET_HI[p.nakshatraLord]})`),
    cell('Chandra Rashi', p.moonRashi),
    cell('Rahu Kaal', `${p.rahuKaal ? '⚠️ ABHI · ' : ''}${p.rahuKaalWindow}`, p.rahuKaal),
  ].join('');

  const max = Math.max(...pick.ranking.map((r) => r.score), 1);
  $('astroRank').innerHTML = pick.ranking.map((r, i) => `
    <div class="rank-row ${i === 0 ? 'top' : ''}" title="${esc(r.why.join(', ') || 'koi khaas yog nahi')}">
      <span class="nm">${i === 0 ? '👑 ' : ''}${esc(r.symbol)}</span>
      <div class="bar"><span style="width:${Math.max(4, (Math.max(r.score, 0) / max) * 100)}%"></span></div>
      <span class="mono muted" style="width:36px;text-align:right">${r.score.toFixed(1)}</span>
    </div>`).join('');

  renderWatchlist();
  // Follow ON ho to chart apne aap astro pick par chala jaye
  if ($('astroFollow').checked && pick.enabled && pick.symbol !== state.selected && state.symbols[pick.symbol] && (prev !== pick.symbol || !prev)) {
    selectSymbol(pick.symbol);
    if (prev) toast(`🔮 Jyotish Guru ne naya token chuna: <b>${esc(pick.symbol)}</b>`, 'ok');
  }
}

// ---------------- Stats / tables ----------------
function renderStats(s) {
  const pnl = s.realizedPnl + s.unrealizedPnl;
  $('stEquity').textContent = fmt.inr(s.equity);
  $('stCapital').textContent = `Capital ${fmt.inr(s.initialCapital)}`;
  $('stPnl').textContent = fmt.signed(pnl);
  $('stPnl').className = `value mono ${fmt.cls(pnl)}`;
  $('stPnlSub').innerHTML = `Realized <span class="${fmt.cls(s.realizedPnl)}">${fmt.signed(s.realizedPnl)}</span> · Open <span class="${fmt.cls(s.unrealizedPnl)}">${fmt.signed(s.unrealizedPnl)}</span>`;
  $('stWin').textContent = `${s.winRate}%`;
  $('stTrades').textContent = `${s.totalTrades} closed trades`;
  $('stOpen').textContent = s.openPositions;
  $('stBroker').innerHTML = `🏦 ${esc(s.broker)} ${s.brokerLive ? '<span class="badge live">LIVE 💰</span>' : '<span class="badge trader">PAPER</span>'}`;
  setBot(s.autoTrading);
}

function setBot(on) {
  $('botToggle').checked = on;
  $('botLabel').textContent = on ? 'ON · Pappu Bhai trade le raha hai' : 'OFF · sirf signals';
  $('botLabel').className = on ? 'up' : 'muted';
}

// ---------------- 💰 Wallet (Add Funds / Withdraw) ----------------
const walletSig = (w) => [w.available, w.blocked, w.deposited, w.withdrawn, w.equity].map((n) => Math.round(n * 100)).join('|');

function renderWallet(w) {
  state.wallet = w;
  $('wAvailable').textContent = fmt.inr(w.available);
  $('wBlocked').textContent = fmt.inr(w.blocked);
  $('wDeposited').textContent = fmt.inr(w.deposited);
  $('wWithdrawn').textContent = fmt.inr(w.withdrawn);
  $('wCapital').textContent = `Base capital ${fmt.inr(w.initialCapital)}`;
  $('wOpenCount').textContent = `${w.openPositions} open · Equity ${fmt.inr(w.equity)}`;
  $('walletTx').innerHTML = (w.tx && w.tx.length)
    ? w.tx.map((t) => {
      const dep = t.type === 'DEPOSIT';
      return `<div class="row">
        <span class="badge ${dep ? 'BUY' : 'SELL'}">${dep ? '➕ ADD' : '⬆ WITHDRAW'}</span>
        <span class="muted mono" style="font-size:12px">${fmt.dateTime(t.created_at)}</span>
        <span class="note">${esc(t.note || t.user_email || '')}</span>
        <span class="amt mono ${dep ? 'up' : 'down'}">${dep ? '+' : '-'}${fmt.inr(t.amount)}</span>
        <small class="muted mono" style="font-size:11px">bal ${fmt.inr(t.balance_after)}</small>
      </div>`;
    }).join('')
    : '<div class="empty">Abhi koi transaction nahi - upar <b>Add Funds</b> dabayein 👆</div>';
}

async function loadWallet() {
  const w = await api('/wallet');
  state.walletSig = walletSig(w);
  renderWallet(w);
}

async function addFunds() {
  const avail = state.wallet?.available ?? 0;
  const v = await openModal({
    title: '➕ Add Funds (Wallet)',
    message: `Wallet me paisa add karein - usi ka <b>${state.wallet?.initialCapital ? 'base capital + ' : ''}hisaab</b> se AI ke trades ka budget badhega.<br>Abhi available: <b>${fmt.inr(avail)}</b>`
      + (engineIsLive() ? '<br><b class="down">⚠️ LIVE broker active hai - yahan ka wallet paper hai, asli paisa broker app me hai.</b>' : ''),
    fields: [
      { name: 'amount', label: 'Amount (₹)', type: 'number', required: true, placeholder: 'jaise 5000' },
      { name: 'note', label: 'Note (optional)', placeholder: 'UPI / bank / cash ...' },
    ],
    submitText: '➕ Paisa add karo',
  });
  if (!v) return;
  try {
    const r = await api('/wallet/deposit', { method: 'POST', body: { amount: Number(v.amount), note: v.note } });
    state.walletSig = walletSig(r);
    renderWallet(r);
    renderStats(r);
    toast(`✅ ${fmt.inr(r.tx[0].amount)} add ho gaya · Available ${fmt.inr(r.available)}`, 'ok');
  } catch (e) { toast(e.message, 'err'); }
}

async function withdrawFunds() {
  const avail = state.wallet?.available ?? 0;
  const v = await openModal({
    title: '⬆ Withdraw (Wallet se paisa nikalo)',
    message: `Available: <b>${fmt.inr(avail)}</b>${state.wallet?.blocked > 0 ? ` · open positions me laga <b>${fmt.inr(state.wallet.blocked)}</b> (wo nahi nikal sakte)` : ''}`
      + (engineIsLive() ? '<br><b class="down">⚠️ LIVE broker - asli withdrawal sirf broker app se hota hai. Ye wallet sirf yahan ka hisaab hai.</b>' : ''),
    fields: [
      { name: 'amount', label: 'Amount (₹)', type: 'number', required: true, placeholder: `max ${Math.floor(avail)}` },
      { name: 'note', label: 'Note (optional)', placeholder: 'bank me transfer ...' },
    ],
    submitText: '⬆ Withdraw karo',
  });
  if (!v) return;
  try {
    const r = await api('/wallet/withdraw', { method: 'POST', body: { amount: Number(v.amount), note: v.note } });
    state.walletSig = walletSig(r);
    renderWallet(r);
    renderStats(r);
    toast(`✅ ${fmt.inr(r.tx[0].amount)} nikal liye · Available ${fmt.inr(r.available)}`, 'ok');
  } catch (e) { toast(e.message, 'err'); }
}

const engineIsLive = () => !!state.wallet?.brokerLive;

function renderTradeTable() {
  const el = $('tradeTable');
  if (state.tab === 'positions') {
    if (!state.positions.length) return (el.innerHTML = '<div class="empty">Koi open position nahi 💤</div>');
    el.innerHTML = `<table><thead><tr><th>Symbol</th><th>Side</th><th>Qty</th><th>Entry</th><th>LTP</th><th>SL / Target</th><th>P&L</th><th></th></tr></thead><tbody>
      ${state.positions.map((p) => {
        const ltp = state.symbols[p.symbol]?.quote?.price ?? p.ltp;
        const pnl = (ltp - p.entry_price) * p.qty * (p.side === 'LONG' ? 1 : -1);
        return `<tr><td><b>${esc(p.symbol)}</b><br><small class="muted">${esc(p.source)}</small></td>
        <td><span class="badge ${p.side}">${p.side}</span></td><td class="mono">${p.qty}</td>
        <td class="mono">${fmt.num(p.entry_price)}</td><td class="mono">${fmt.num(ltp)}</td>
        <td class="mono"><span class="down">${fmt.num(p.stop_loss)}</span> / <span class="up">${fmt.num(p.target)}</span></td>
        <td class="mono ${fmt.cls(pnl)}">${fmt.signed(pnl)}</td>
        <td><button class="btn btn-sm btn-red" data-close="${esc(p.symbol)}">Exit</button></td></tr>`;
      }).join('')}</tbody></table>`;
    el.querySelectorAll('[data-close]').forEach((b) => b.addEventListener('click', () => closePos(b.dataset.close)));
  } else {
    const closed = state.trades.filter((t) => t.status === 'CLOSED');
    if (!closed.length) return (el.innerHTML = '<div class="empty">Abhi tak koi trade close nahi hua</div>');
    el.innerHTML = `<table><thead><tr><th>Time</th><th>Symbol</th><th>Side</th><th>Qty</th><th>Entry → Exit</th><th>P&L</th><th>Reason</th></tr></thead><tbody>
      ${closed.map((t) => `<tr><td class="muted">${fmt.time(t.closed_at)}</td><td><b>${esc(t.symbol)}</b></td>
        <td><span class="badge ${t.side}">${t.side}</span></td><td class="mono">${t.qty}</td>
        <td class="mono">${fmt.num(t.entry_price)} → ${fmt.num(t.exit_price)}</td>
        <td class="mono ${fmt.cls(t.pnl)}">${fmt.signed(t.pnl)}</td><td class="muted">${esc(t.exit_reason || '')}</td></tr>`).join('')}</tbody></table>`;
  }
}

function addFeed(icon, html, time = Date.now()) {
  const el = document.createElement('div');
  el.className = 'feed-item';
  el.innerHTML = `<div class="ico">${icon}</div><div>${html}<time>${fmt.time(time)}</time></div>`;
  $('feed').prepend(el);
  while ($('feed').children.length > 60) $('feed').lastChild.remove();
}

// ---------------- Data loading ----------------
async function loadTrades() {
  const [positions, trades] = await Promise.all([api('/positions'), api('/trades?limit=100')]);
  state.positions = positions;
  state.trades = trades;
  renderTradeTable();
  drawTradeOverlay();
}

async function selectSymbol(sym) {
  state.selected = sym;
  localStorage.setItem('pb_symbol', sym);
  renderWatchlist();
  renderHeader();
  state.rawCandles = await api(`/candles/${encodeURIComponent(sym)}?limit=6000`);
  state.candles = aggregateCandles(state.rawCandles, tfSec());
  drawChart();
  chart.timeScale().scrollToRealTime();

  if (!state.decisions[sym]) {
    const { decision, signals } = await api(`/signals/latest/${encodeURIComponent(sym)}`);
    if (decision) {
      state.decisions[sym] = { ...decision, time: decision.created_at };
      state.signals[sym] = Object.fromEntries(signals.map((s) => [s.agent_key, { ...s, agent: s.agent_key }]));
    }
  }
  renderAgents();
  if (state.decisions[sym]) renderDecision(state.decisions[sym]);
  else { $('decAction').textContent = 'WAIT'; $('decAction').className = 'decision-action HOLD'; $('decSym').textContent = sym; }
}

async function loadSymbols() {
  const list = await api('/symbols');
  state.symbols = Object.fromEntries(list.map((s) => [s.symbol, s]));
  renderWatchlist();
  return list;
}

async function init() {
  const [list, agents, stats, decisions] = await Promise.all([loadSymbols(), api('/agents'), api('/stats'), api('/decisions?limit=15')]);
  state.agents = agents;
  renderStats(stats);
  loadWallet().catch((e) => toast(e.message, 'err'));
  decisions.reverse().forEach((d) => addFeed('🧠', `<b>${esc(d.symbol)}</b> <span class="badge ${d.action}">${d.action}</span> ${esc(d.summary)}`, d.created_at));
  await loadTrades();
  const astro = await api('/astro');
  state.astro = astro.pick;
  const saved = localStorage.getItem('pb_symbol');
  const first = astro.enabled && astro.pick && $('astroFollow').checked ? astro.pick.symbol
    : state.symbols[saved] ? saved : list[0]?.symbol;
  await selectSymbol(first);
  renderAstro(astro.pick);
  connectSocket();
}

// ---------------- Live (Socket.IO) ----------------
function connectSocket() {
  const socket = io({ auth: { token: Auth.token } });
  socket.on('connect_error', (e) => { if (e.message === 'unauthorized') Auth.logout(); });

  socket.on('tick', (t) => {
    const s = state.symbols[t.symbol];
    if (!s) return;
    s.quote = { symbol: t.symbol, price: t.price, change: t.change, changePct: t.changePct };
    const wp = $(`wp-${t.symbol}`), wc = $(`wc-${t.symbol}`);
    if (wp) { wp.textContent = fmt.num(t.price); }
    if (wc) { wc.textContent = fmt.pct(t.changePct); wc.className = fmt.cls(t.change); }
    if (t.symbol === state.selected) { renderHeader(); updateChartCandle(t.candle); }
  });

  socket.on('stats', (s) => {
    renderStats(s);
    if (state.tab === 'positions' && state.positions.length) renderTradeTable();
    // paisa add hua ya withdrawal hua to wallet card bhi update
    if (walletSig(s) !== state.walletSig) loadWallet().catch(() => {});
  });
  socket.on('bot', ({ autoTrading }) => setBot(autoTrading));
  socket.on('symbols', async () => {
    const list = await loadSymbols();
    // khula hua token admin ne remove kar diya -> pehle token par jao
    if (!state.symbols[state.selected] && list.length) {
      toast(`${esc(state.selected)} remove ho gaya, ${esc(list[0].symbol)} khol rahe hain`);
      selectSymbol(list[0].symbol);
    }
  });
  socket.on('notice', (n) => {
    toast(`⚠️ ${esc(n.message)}`, 'err');
    addFeed('⚠️', esc(n.message), n.time);
  });
  socket.on('astro:pick', (pick) => {
    const changed = state.astro?.symbol !== pick.symbol;
    renderAstro(pick);
    if (changed) addFeed('🔮', esc(pick.message), pick.time);
  });

  socket.on('analysis:start', (e) => {
    if (e.symbol !== state.selected) return;
    $('pappuAvatar').classList.add('thinking');
    $('pappuStatus').textContent = `${e.agents.length} agents ko kaam diya · ${e.symbol} analyse ho raha hai…`;
    $('analysisInfo').textContent = `Analysis #${e.analysisId.slice(0, 6)} · ${fmt.time(e.time)}`;
    setAgentWorking(e.agents);
  });

  socket.on('agent:signal', (s) => {
    (state.signals[s.symbol] ||= {})[s.agent] = s;
    if (s.symbol !== state.selected) return;
    const el = $(`agent-${s.agent}`);
    if (!el) return;
    el.classList.remove('working');
    el.classList.remove('flash'); void el.offsetWidth; el.classList.add('flash');
    $(`agent-badge-${s.agent}`).innerHTML = s.agent === 'risk'
      ? (s.veto ? '<span class="badge SELL">VETO</span>' : '<span class="badge BUY">SAFE</span>')
      : `<span class="badge ${s.action}">${s.action}</span>`;
    $(`agent-reason-${s.agent}`).textContent = s.reason;
    $(`agent-conf-${s.agent}`).style.width = `${Math.round(s.confidence * 100)}%`;
    $(`agent-pct-${s.agent}`).textContent = `Confidence ${Math.round(s.confidence * 100)}%`;
    $(`agent-time-${s.agent}`).textContent = `${s.tookMs}ms`;
    $('pappuStatus').textContent = `${s.icon} ${s.name} ne report di: ${s.action}`;
  });

  socket.on('pappu:decision', (d) => {
    state.decisions[d.symbol] = d;
    if (d.action !== 'HOLD' || d.vetoed) {
      addFeed(d.vetoed ? '🛡️' : '🧠', `<b>${esc(d.symbol)}</b> <span class="badge ${d.action}">${d.action}</span> ${esc(d.summary)}`, d.time);
    }
    if (d.symbol !== state.selected) return;
    $('pappuAvatar').classList.remove('thinking');
    $('pappuStatus').textContent = `Main Agent · decision ready (${fmt.time(d.time)})`;
    renderDecision(d);
  });

  socket.on('trade', async ({ type, trade }) => {
    const msg = type === 'OPEN'
      ? `🟢 <b>${trade.side}</b> ${trade.qty} × ${esc(trade.symbol)} @ ${fmt.inr(trade.entry_price)}`
      : `🔴 EXIT ${esc(trade.symbol)} @ ${fmt.inr(trade.exit_price)} · <b class="${fmt.cls(trade.pnl)}">${fmt.signed(trade.pnl)}</b> (${esc(trade.exit_reason)})`;
    toast(msg, type === 'OPEN' ? 'ok' : trade.pnl >= 0 ? 'ok' : 'err');
    addFeed('💰', msg);
    await loadTrades();
  });
}

// ---------------- Actions ----------------
async function closePos(sym) {
  try { await api(`/trade/close/${encodeURIComponent(sym)}`, { method: 'POST' }); } catch (e) { toast(e.message, 'err'); }
}

async function manual(side) {
  const sym = state.selected;
  const pos = state.positions.find((p) => p.symbol === sym);
  try {
    if (pos && ((side === 'LONG' && pos.side === 'SHORT') || (side === 'SHORT' && pos.side === 'LONG'))) return closePos(sym);
    const qty = prompt(`${sym} ${side} - Quantity (khali chhodo = auto size)`, '');
    if (qty === null) return;
    await api('/trade/manual', { method: 'POST', body: { symbol: sym, side, qty: Number(qty) || null } });
  } catch (e) { toast(e.message, 'err'); }
}

$('astroGo').addEventListener('click', () => state.astro && selectSymbol(state.astro.symbol));
$('astroRefresh').addEventListener('click', async () => {
  try { renderAstro(await api('/astro/refresh', { method: 'POST' })); toast('🔮 Panchang dobara dekha gaya', 'ok'); } catch (e) { toast(e.message, 'err'); }
});
$('buyBtn').addEventListener('click', () => manual('LONG'));
$('sellBtn').addEventListener('click', () => manual('SHORT'));
$('analyzeBtn').addEventListener('click', async () => {
  try { await api(`/analyze/${encodeURIComponent(state.selected)}`, { method: 'POST' }); } catch (e) { toast(e.message, 'err'); }
});
$('botToggle').addEventListener('change', async (e) => {
  if (Auth.user?.role !== 'admin') { e.target.checked = !e.target.checked; return toast('Sirf admin auto-trading ON/OFF kar sakta hai', 'err'); }
  try {
    const r = await api('/bot/toggle', { method: 'POST', body: { enabled: e.target.checked } });
    setBot(r.autoTrading);
    toast(r.autoTrading ? '🤖 Pappu Bhai ab khud trade lega (paper)' : '⏸️ Auto trading band', r.autoTrading ? 'ok' : '');
  } catch (err) { toast(err.message, 'err'); }
});
document.querySelectorAll('#tradeTabs button').forEach((b) => b.addEventListener('click', () => {
  document.querySelectorAll('#tradeTabs button').forEach((x) => x.classList.remove('active'));
  b.classList.add('active');
  state.tab = b.dataset.tab;
  renderTradeTable();
}));

// ⏱ Time frame buttons (chart ke upar)
document.querySelectorAll('.tf-btn').forEach((b) => b.addEventListener('click', () => setTimeframe(b.dataset.tf)));
renderTfButtons();

// 💰 Wallet buttons (Add Funds / Withdraw)
$('addFundsBtn').addEventListener('click', addFunds);
$('withdrawBtn').addEventListener('click', withdrawFunds);

init().catch((e) => toast(e.message, 'err'));
