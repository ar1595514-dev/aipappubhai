/**
 * MarketFeed - live price ticks + OHLCV candles.
 * Demo ke liye ye simulated data banata hai (random walk + trend regimes).
 * Real market ke liye isi interface (tick / candle events) ko broker websocket
 * (Zerodha Kite Ticker, Angel SmartAPI, Upstox etc.) se feed karein.
 */
const EventEmitter = require('events');
const config = require('../config');

function gauss() {
  let u = 0, v = 0;
  while (u === 0) u = Math.random();
  while (v === 0) v = Math.random();
  return Math.sqrt(-2 * Math.log(u)) * Math.cos(2 * Math.PI * v);
}

const round = (n) => Math.round(n * 100) / 100;

class MarketFeed extends EventEmitter {
  constructor() {
    super();
    this.books = new Map(); // symbol -> { candles, price, open, trend, sigma, prevClose }
    this.timer = null;
  }

  bucket(tsSec) {
    return Math.floor(tsSec / config.candleSeconds) * config.candleSeconds;
  }

  addSymbol(symbol, basePrice) {
    if (this.books.has(symbol)) return;
    const sigma = 0.0012;
    const candles = [];
    let price = basePrice;
    let trend = 0;
    const nowBucket = this.bucket(Math.floor(Date.now() / 1000));
    const ticksPerCandle = Math.max(1, Math.round((config.candleSeconds * 1000) / config.tickMs));

    for (let i = config.historyCandles; i > 0; i--) {
      const time = nowBucket - i * config.candleSeconds;
      const open = price;
      let high = price, low = price, volume = 0;
      for (let t = 0; t < ticksPerCandle; t++) {
        trend = trend * 0.97 + gauss() * 0.00008;
        price *= 1 + trend + sigma * gauss();
        high = Math.max(high, price);
        low = Math.min(low, price);
        volume += Math.round(500 + Math.random() * 1500 * (1 + Math.abs(trend) * 2000));
      }
      candles.push({ time, open: round(open), high: round(high), low: round(low), close: round(price), volume });
    }

    // history ko scale karo taaki current price = base price ho
    const k = basePrice / price;
    for (const c of candles) {
      c.open = round(c.open * k); c.high = round(c.high * k);
      c.low = round(c.low * k); c.close = round(c.close * k);
    }
    price = basePrice;

    const book = {
      symbol,
      candles,
      price: round(price),
      trend,
      sigma,
      dayOpen: basePrice, // session start price se change % naapte hain
    };
    // current (forming) candle
    book.candles.push({ time: nowBucket, open: book.price, high: book.price, low: book.price, close: book.price, volume: 0 });
    this.books.set(symbol, book);
  }

  removeSymbol(symbol) {
    this.books.delete(symbol);
  }

  symbols() {
    return [...this.books.keys()];
  }

  getPrice(symbol) {
    return this.books.get(symbol)?.price;
  }

  getCandles(symbol, limit = config.historyCandles) {
    const book = this.books.get(symbol);
    if (!book) return [];
    return book.candles.slice(-limit);
  }

  /** Sirf closed candles (analysis ke liye) */
  getClosedCandles(symbol) {
    const book = this.books.get(symbol);
    if (!book) return [];
    return book.candles.slice(0, -1);
  }

  quote(symbol) {
    const b = this.books.get(symbol);
    if (!b) return null;
    const change = b.price - b.dayOpen;
    return {
      symbol,
      price: b.price,
      change: round(change),
      changePct: round((change / b.dayOpen) * 100),
    };
  }

  start() {
    if (this.timer) return;
    this.timer = setInterval(() => this.tick(), config.tickMs);
  }

  stop() {
    clearInterval(this.timer);
    this.timer = null;
  }

  tick() {
    const nowSec = Math.floor(Date.now() / 1000);
    const bucket = this.bucket(nowSec);

    for (const book of this.books.values()) {
      // trend regime slowly badalta hai -> realistic swings
      book.trend = book.trend * 0.97 + gauss() * 0.00008;
      if (Math.random() < 0.005) book.trend += gauss() * 0.0008; // kabhi kabhi news shock
      book.price = round(book.price * (1 + book.trend + book.sigma * gauss()));
      const vol = Math.round(500 + Math.random() * 1500 * (1 + Math.abs(book.trend) * 2000));

      let current = book.candles[book.candles.length - 1];
      if (current.time !== bucket) {
        // purani candle close ho gayi
        const closed = current;
        this.emit('candleClosed', { symbol: book.symbol, candle: closed });
        current = { time: bucket, open: closed.close, high: closed.close, low: closed.close, close: closed.close, volume: 0 };
        book.candles.push(current);
        if (book.candles.length > config.historyCandles + 50) book.candles.shift();
      }

      current.high = Math.max(current.high, book.price);
      current.low = Math.min(current.low, book.price);
      current.close = book.price;
      current.volume += vol;

      this.emit('tick', { ...this.quote(book.symbol), candle: { ...current }, time: Date.now() });
    }
  }
}

module.exports = new MarketFeed();
