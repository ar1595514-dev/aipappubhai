/** Broker REST calls ke liye chhota fetch helper (timeout + readable errors) */
function pickMessage(data) {
  if (!data || typeof data !== 'object') return String(data ?? '');
  const err = data.error;
  if (typeof err === 'string') return err;
  if (err && typeof err === 'object') return err.code || err.message || JSON.stringify(err).slice(0, 200);
  return data.message || data.errorMessage || data.error_description || data.errors?.[0]?.message
    || data.remarks?.error_message || data.raw || JSON.stringify(data).slice(0, 200);
}

async function http(url, { method = 'GET', headers = {}, body, form, timeout = 10000 } = {}) {
  const opts = { method, headers: { Accept: 'application/json', ...headers }, signal: AbortSignal.timeout(timeout) };
  if (form) {
    opts.body = new URLSearchParams(Object.entries(form).map(([k, v]) => [k, String(v)])).toString();
    opts.headers['Content-Type'] = 'application/x-www-form-urlencoded';
  } else if (body) {
    opts.body = JSON.stringify(body);
    opts.headers['Content-Type'] = 'application/json';
  }
  let res;
  try {
    res = await fetch(url, opts);
  } catch (e) {
    throw new Error(e.name === 'TimeoutError' ? 'Broker server ne time par jawab nahi diya' : `Network error: ${e.message}`);
  }
  const text = await res.text();
  let data;
  try { data = JSON.parse(text); } catch { data = { raw: text.slice(0, 300) }; }
  if (!res.ok) throw new Error(`HTTP ${res.status}: ${pickMessage(data)}`);
  return data;
}

module.exports = { http, pickMessage };
