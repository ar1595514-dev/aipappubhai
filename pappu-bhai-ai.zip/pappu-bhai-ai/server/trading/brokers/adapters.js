/**
 * Broker adapters. Sabka interface same hai:
 *   testConnection()                                   -> "OK message" (fail par throw)
 *   placeOrder({ symbol, exchange, side, qty, price, brokerToken }) -> { orderId, fillPrice }
 *
 * side: 'BUY' | 'SELL'. Sab MARKET orders hain. Broker turant fill price nahi deta,
 * isliye fillPrice = order ke waqt ka LTP (approx). Asli fill broker app me check karein.
 *
 * ⚠️ Ye adapters official REST docs ke hisaab se likhe gaye hain, lekin bina asli account
 * ke test nahi ho sakte. Pehle chhoti quantity se test karein.
 */
const crypto = require('crypto');
const { http } = require('./http');

const need = (val, label) => {
  if (!val) throw new Error(`${label} missing hai - Admin → Brokers me daalein`);
  return val;
};

class PaperBroker {
  constructor() { this.live = false; }
  async testConnection() { return 'Paper trading ready (virtual paisa)'; }
  async placeOrder({ price }) {
    const slip = price * 0.0002 * (Math.random() - 0.5); // thoda slippage simulate
    return { orderId: `PAPER-${crypto.randomUUID().slice(0, 8)}`, fillPrice: Math.round((price + slip) * 100) / 100 };
  }
}

// ---------------- Zerodha Kite Connect v3 ----------------
class ZerodhaBroker {
  constructor(c) { this.c = c; this.live = true; this.base = 'https://api.kite.trade'; }
  headers() {
    return {
      'X-Kite-Version': '3',
      Authorization: `token ${need(this.c.api_key, 'API key')}:${need(this.c.access_token, 'Access token')}`,
    };
  }
  async testConnection() {
    const r = await http(`${this.base}/user/profile`, { headers: this.headers() });
    return `Connected: ${r.data?.user_name || r.data?.user_id || 'Zerodha user'}`;
  }
  async placeOrder({ symbol, exchange, side, qty, price, brokerToken }) {
    const r = await http(`${this.base}/orders/regular`, {
      method: 'POST',
      headers: this.headers(),
      form: {
        tradingsymbol: brokerToken || symbol,
        exchange: exchange || 'NSE',
        transaction_type: side,
        order_type: 'MARKET',
        quantity: qty,
        product: this.c.product === 'DELIVERY' ? 'CNC' : 'MIS',
        validity: 'DAY',
      },
    });
    return { orderId: r.data?.order_id, fillPrice: price };
  }
}

// ---------------- Upstox API v2 ----------------
class UpstoxBroker {
  constructor(c) { this.c = c; this.live = true; this.base = 'https://api.upstox.com/v2'; }
  headers() { return { Authorization: `Bearer ${need(this.c.access_token, 'Access token')}` }; }
  async testConnection() {
    const r = await http(`${this.base}/user/profile`, { headers: this.headers() });
    return `Connected: ${r.data?.user_name || r.data?.user_id || 'Upstox user'}`;
  }
  async placeOrder({ symbol, side, qty, price, brokerToken }) {
    const r = await http(`${this.base}/order/place`, {
      method: 'POST',
      headers: this.headers(),
      body: {
        instrument_token: need(brokerToken, `${symbol} ka Upstox instrument_key (jaise NSE_EQ|INE002A01018)`),
        quantity: qty,
        product: this.c.product === 'DELIVERY' ? 'D' : 'I',
        validity: 'DAY',
        price: 0,
        order_type: 'MARKET',
        transaction_type: side,
        disclosed_quantity: 0,
        trigger_price: 0,
        is_amo: false,
        tag: 'pappu-bhai-ai',
      },
    });
    return { orderId: r.data?.order_id, fillPrice: price };
  }
}

// ---------------- Angel One SmartAPI ----------------
class AngelBroker {
  constructor(c) { this.c = c; this.live = true; this.base = 'https://apiconnect.angelone.in/rest/secure/angelbroking'; }
  headers() {
    return {
      Authorization: `Bearer ${need(this.c.access_token, 'JWT token')}`,
      'X-PrivateKey': need(this.c.api_key, 'API key'),
      'X-UserType': 'USER',
      'X-SourceID': 'WEB',
      'X-ClientLocalIP': '127.0.0.1',
      'X-ClientPublicIP': '127.0.0.1',
      'X-MACAddress': '00:00:00:00:00:00',
    };
  }
  check(r) {
    // Angel galat token par bhi HTTP 200 deta hai: { success:false } ya { status:false }
    if (r.status === false || r.success === false || r.status === 'false') {
      throw new Error(`${r.message || 'Angel One error'}${r.errorCode || r.errorcode ? ` (${r.errorCode || r.errorcode})` : ''}`);
    }
    return r;
  }
  async testConnection() {
    const r = this.check(await http(`${this.base}/user/v1/getProfile`, { headers: this.headers() }));
    if (!r.data || typeof r.data !== 'object') throw new Error(r.message || 'Profile nahi mila - token check karein');
    return `Connected: ${r.data.name || r.data.clientcode}`;
  }
  async placeOrder({ symbol, exchange, side, qty, price, brokerToken }) {
    const r = this.check(await http(`${this.base}/order/v1/placeOrder`, {
      method: 'POST',
      headers: this.headers(),
      body: {
        variety: 'NORMAL',
        tradingsymbol: `${symbol}-EQ`,
        symboltoken: need(brokerToken, `${symbol} ka Angel symboltoken (jaise 2885)`),
        transactiontype: side,
        exchange: exchange || 'NSE',
        ordertype: 'MARKET',
        producttype: this.c.product === 'DELIVERY' ? 'DELIVERY' : 'INTRADAY',
        duration: 'DAY',
        price: '0',
        quantity: String(qty),
      },
    }));
    return { orderId: r.data?.orderid, fillPrice: price };
  }
}

// ---------------- Dhan API v2 ----------------
class DhanBroker {
  constructor(c) { this.c = c; this.live = true; this.base = 'https://api.dhan.co/v2'; }
  headers() {
    return { 'access-token': need(this.c.access_token, 'Access token'), 'client-id': need(this.c.client_id, 'Client ID') };
  }
  async testConnection() {
    const r = await http(`${this.base}/fundlimit`, { headers: this.headers() });
    const bal = r.availabelBalance ?? r.availableBalance; // Dhan API me spelling "availabel" hai
    return `Connected${bal != null ? ` · Available ₹${bal}` : ''}`;
  }
  async placeOrder({ symbol, exchange, side, qty, price, brokerToken }) {
    const r = await http(`${this.base}/orders`, {
      method: 'POST',
      headers: this.headers(),
      body: {
        dhanClientId: this.c.client_id,
        transactionType: side,
        exchangeSegment: exchange === 'BSE' ? 'BSE_EQ' : 'NSE_EQ',
        productType: this.c.product === 'DELIVERY' ? 'CNC' : 'INTRADAY',
        orderType: 'MARKET',
        validity: 'DAY',
        securityId: need(brokerToken, `${symbol} ka Dhan securityId (jaise 2885)`),
        quantity: qty,
        price: 0,
      },
    });
    return { orderId: r.orderId, fillPrice: price };
  }
}

// ---------------- Fyers API v3 ----------------
class FyersBroker {
  constructor(c) { this.c = c; this.live = true; this.base = 'https://api-t1.fyers.in/api/v3'; }
  headers() {
    const appId = need(this.c.client_id, 'App ID');
    if (!/-\d{3}$/.test(appId)) throw new Error('Fyers App ID ka format "XXXXXXXX-100" jaisa hona chahiye (Client ID field me)');
    return { Authorization: `${appId}:${need(this.c.access_token, 'Access token')}` };
  }
  check(r) {
    if (r.s && r.s !== 'ok') throw new Error(r.message || 'Fyers error');
    return r;
  }
  async testConnection() {
    const r = this.check(await http(`${this.base}/profile`, { headers: this.headers() }));
    return `Connected: ${r.data?.name || r.data?.fy_id || 'Fyers user'}`;
  }
  async placeOrder({ symbol, exchange, side, qty, price, brokerToken }) {
    const r = this.check(await http(`${this.base}/orders/sync`, {
      method: 'POST',
      headers: this.headers(),
      body: {
        symbol: brokerToken || `${exchange || 'NSE'}:${symbol}-EQ`,
        qty,
        type: 2, // market
        side: side === 'BUY' ? 1 : -1,
        productType: this.c.product === 'DELIVERY' ? 'CNC' : 'INTRADAY',
        limitPrice: 0,
        stopPrice: 0,
        validity: 'DAY',
        disclosedQty: 0,
        offlineOrder: false,
      },
    }));
    return { orderId: r.id, fillPrice: price };
  }
}

// ---------------- Delta Exchange (crypto derivatives, HMAC signed) ----------------
// Docs: https://docs.delta.exchange/  ·  Signature: HMAC-SHA256(method + timestamp + path + query + payload)
class DeltaBroker {
  constructor(c) {
    this.c = c;
    this.live = true;
    // client_id me URL daala ho to wahi base (Delta Global), warna India prod
    this.base = /^https?:\/\//.test(c.client_id || '') ? c.client_id.replace(/\/+$/, '') : 'https://api.india.delta.exchange';
  }
  headers(method, path, query = '', payload = '') {
    const ts = String(Math.floor(Date.now() / 1000));
    const data = method + ts + path + query + payload;
    const signature = crypto.createHmac('sha256', need(this.c.api_secret, 'API secret')).update(data).digest('hex');
    return {
      'api-key': need(this.c.api_key, 'API key'),
      signature,
      timestamp: ts,
      'User-Agent': 'pappu-bhai-ai-rest-client', // Delta CDN bina User-Agent ke 4XX deta hai
      'Content-Type': 'application/json',
    };
  }
  check(r) {
    // Delta error: { success:false, error:{ code } } ya { error:'SignatureExpired', message }
    if (r && r.success === false) {
      const e = r.error;
      const code = typeof e === 'string' ? e : (e && (e.code || e.message)) || null;
      throw new Error(`${code || r.message || 'Delta Exchange error'}${r.message && code !== r.message ? ` · ${r.message}` : ''}`);
    }
    return r;
  }
  async testConnection() {
    const path = '/v2/wallet/balances';
    const r = this.check(await this.req(path, { headers: this.headers('GET', path) }));
    const wallets = Array.isArray(r.result) ? r.result : [];
    const eq = r.meta && r.meta.net_equity;
    return `Connected${eq != null ? ` · Net equity ${eq}` : ''} · ${wallets.length} wallet${wallets.length === 1 ? '' : 's'}`;
  }
  /** http call + Delta ke error codes ko samajh layak message me badal kar throw */
  async req(path, opts) {
    try {
      return await http(`${this.base}${path}`, opts);
    } catch (e) {
      throw new Error(this.hint(e.message));
    }
  }
  hint(m) {
    const map = [
      ['invalid_api_key', 'API key galat ya regenerate ho chuki hai - Delta → API Management se check karein'],
      ['ip_not_whitelisted_for_api_key', 'Is IP address ko API key ke whitelist me daalein (Delta → API Management)'],
      ['UnauthorizedApiAccess', 'API key ko "Trading" permission do (Delta → API Management)'],
      ['Signature Mismatch', 'Signature match nahi hua - API secret sahi hai dekhein aur system time (NTP) sync karein'],
      ['SignatureExpired', 'Signature expire - system ka time ±5 second ke andar hona chahiye'],
      ['Forbidden', 'CDN ne block kiya - User-Agent header check karein / VPN band karein'],
    ];
    for (const [k, v] of map) if (m.includes(k)) return `${k} · ${v}`;
    return m;
  }
  /** brokerToken = Delta product_id (27 = BTCUSD). Na mile to symbol se product dhoondte hain. */
  async productId(symbol, brokerToken) {
    if (brokerToken && /^\d+$/.test(String(brokerToken))) return Number(brokerToken);
    try {
      const r = await http(`${this.base}/v2/products/${encodeURIComponent(symbol)}`);
      if (r && r.success !== false && r.result && r.result.id) return r.result.id;
    } catch { /* neeche wala clear error dikhega */ }
    throw new Error(`${symbol} ka Delta product_id "Broker token" me daalein (jaise 27 = BTCUSD, 3136 = ETHUSD)`);
  }
  async placeOrder({ symbol, side, qty, price, brokerToken }) {
    const body = {
      product_id: await this.productId(symbol, brokerToken),
      size: qty,
      side: side === 'BUY' ? 'buy' : 'sell',
      order_type: 'market_order',
    };
    // Signature payload = wahi JSON string jo request me jayegi (http helper bhi isi ko stringify karega)
    const payload = JSON.stringify(body);
    const r = this.check(await this.req('/v2/orders', {
      method: 'POST',
      headers: this.headers('POST', '/v2/orders', '', payload),
      body,
    }));
    const o = r.result || {};
    return { orderId: o.id, fillPrice: Number(o.average_fill_price) || price };
  }
}

module.exports = { PaperBroker, ZerodhaBroker, UpstoxBroker, AngelBroker, DhanBroker, FyersBroker, DeltaBroker };
