/**
 * Broker manager - DB me saved broker accounts se active broker adapter banata hai.
 * Secrets (api_secret, access_token) DB me AES-256-GCM se encrypted rehte hain.
 */
const { db } = require('../../db/database');
const { decrypt, mask } = require('../../utils/security');
const A = require('./adapters');

// UI ke liye broker types ki jaankari (kaun se fields chahiye, docs link)
const BROKER_TYPES = {
  paper: {
    label: 'Paper Trading (Demo)', adapter: A.PaperBroker, live: false, fields: [],
    help: 'Virtual paisa se trading. Koi API key nahi chahiye.',
  },
  zerodha: {
    label: 'Zerodha (Kite Connect)', adapter: A.ZerodhaBroker, live: true,
    fields: ['api_key', 'api_secret', 'access_token'], tokenLabel: 'Tradingsymbol (optional, default = symbol)',
    docs: 'https://kite.trade/docs/connect/v3/',
    help: 'developers.kite.trade par app banayein. Access token roz subah login flow se naya banta hai.',
  },
  upstox: {
    label: 'Upstox (API v2)', adapter: A.UpstoxBroker, live: true,
    fields: ['api_key', 'api_secret', 'access_token'], needsToken: true, tokenLabel: 'instrument_key (jaise NSE_EQ|INE002A01018)',
    docs: 'https://upstox.com/developer/api-documentation/',
    help: 'Upstox developer console se app + access token. Har symbol ka instrument_key Symbols me daalein.',
  },
  angel: {
    label: 'Angel One (SmartAPI)', adapter: A.AngelBroker, live: true,
    fields: ['client_id', 'api_key', 'access_token'], needsToken: true, tokenLabel: 'symboltoken (jaise 2885)',
    docs: 'https://smartapi.angelbroking.com/docs',
    help: 'Client code, SmartAPI key aur login se mila JWT token daalein. Har symbol ka symboltoken chahiye.',
  },
  dhan: {
    label: 'Dhan (API v2)', adapter: A.DhanBroker, live: true,
    fields: ['client_id', 'access_token'], needsToken: true, tokenLabel: 'securityId (jaise 2885)',
    docs: 'https://dhanhq.co/docs/v2/',
    help: 'web.dhan.co → Profile → DhanHQ Trading APIs se access token banayein. Har symbol ka securityId chahiye.',
  },
  fyers: {
    label: 'Fyers (API v3)', adapter: A.FyersBroker, live: true,
    fields: ['client_id', 'api_secret', 'access_token'], tokenLabel: 'Fyers symbol (optional, jaise NSE:SBIN-EQ)',
    docs: 'https://myapi.fyers.in/docsv3',
    help: 'Client ID me App ID daalein (jaise XXXX-100). Access token login flow se.',
  },
  delta: {
    label: 'Delta Exchange (Crypto)', adapter: A.DeltaBroker, live: true,
    fields: ['client_id', 'api_key', 'api_secret'], fieldLabels: { client_id: 'Base URL (optional)' },
    needsToken: true, tokenLabel: 'Delta product_id (jaise 27 = BTCUSD, 3136 = ETHUSD)',
    docs: 'https://docs.delta.exchange/',
    help: 'delta.exchange → API Management se API key + secret banayein (Trading permission + IP whitelist chahiye).'
      + ' Client ID (Base URL) khali chhodne par India endpoint (api.india.delta.exchange) use hota hai; Delta Global ke liye wahan poora URL daalein.'
      + ' Crypto product ka product_id har symbol ke liye "Broker token" me daalein.',
  },
};

const FIELD_LABELS = {
  client_id: 'Client ID / App ID',
  api_key: 'API Key',
  api_secret: 'API Secret',
  access_token: 'Access Token',
};

function typesForUI() {
  return Object.fromEntries(Object.entries(BROKER_TYPES).map(([k, t]) => [k, {
    label: t.label, live: t.live,
    fields: t.fields.map((f) => ({ key: f, label: (t.fieldLabels && t.fieldLabels[f]) || FIELD_LABELS[f] })),
    needsToken: !!t.needsToken, tokenLabel: t.tokenLabel || null, docs: t.docs || null, help: t.help,
  }]));
}

function configOf(row) {
  return {
    client_id: row.client_id || '',
    api_key: row.api_key || '',
    api_secret: decrypt(row.api_secret_enc),
    access_token: decrypt(row.access_token_enc),
    product: row.product,
  };
}

function createAdapter(row) {
  const t = BROKER_TYPES[row.type] || BROKER_TYPES.paper;
  const adapter = new t.adapter(configOf(row));
  adapter.id = row.id;
  adapter.name = row.name;
  adapter.type = row.type;
  return adapter;
}

/** UI ko bhejne layak row (secrets masked) */
function publicRow(row) {
  const t = BROKER_TYPES[row.type] || BROKER_TYPES.paper;
  const token = decrypt(row.access_token_enc);
  return {
    id: row.id,
    name: row.name,
    type: row.type,
    typeLabel: t.label,
    live: t.live,
    client_id: row.client_id || '',
    api_key: mask(row.api_key),
    has_api_secret: !!row.api_secret_enc,
    access_token: mask(token),
    has_access_token: !!token,
    needs_access_token: t.fields.includes('access_token'),
    token_updated_at: row.token_updated_at || null,
    product: row.product,
    is_active: !!row.is_active,
    status: row.status,
    status_msg: row.status_msg,
    last_tested_at: row.last_tested_at,
    created_at: row.created_at,
  };
}

let cached = null;

function activeRow() {
  return db.prepare('SELECT * FROM brokers WHERE is_active = 1 ORDER BY id LIMIT 1').get()
    || { id: 0, name: 'Paper Trading (fallback)', type: 'paper', product: 'INTRADAY' };
}

module.exports = {
  BROKER_TYPES,
  typesForUI,
  publicRow,
  createAdapter,
  /** Active broker ka adapter (cache) */
  active() {
    if (!cached) cached = createAdapter(activeRow());
    return cached;
  },
  /** Broker settings badalne ke baad call karein */
  reload() { cached = null; },
};
