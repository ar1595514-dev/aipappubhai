/**
 * TradingEngine - Pappu Bhai ke decision ko order me badalta hai,
 * positions manage karta hai, aur har tick par stop-loss / target check karta hai.
 */
const EventEmitter = require('events');
const { db, settings, log } = require('../db/database');
const brokers = require('./brokers');
const wallet = require('./wallet');

const round = (n) => Math.round(n * 100) / 100;

class TradingEngine extends EventEmitter {
  constructor(feed) {
    super();
    this.feed = feed;
    this.closing = new Set();
    this.warned = new Map();   // key -> last warn time
    this.retryAfter = new Map(); // symbol -> time (fail hone par SL/TGT exit dobara turant try na ho)
  }

  /** Active broker adapter (Admin → Brokers se chuna hua) */
  get broker() {
    return brokers.active();
  }

  /**
   * Broker ko order bhejo + LIVE safety checks
   * source: 'AI' | 'MANUAL' | 'EXIT'
   */
  async sendOrder({ symbol, side, qty, price, source }) {
    const b = this.broker;
    if (b.live) {
      if (source === 'AI' && !settings.bool('allow_live_ai')) {
        throw new Error(`LIVE broker (${b.name}) par AI auto-order band hai. Admin → Brokers → "AI ko LIVE order" ON karein.`);
      }
      const maxVal = settings.num('live_max_order_value') || 10000; // galat/khali value par bhi safe default
      const value = qty * price;
      if (source !== 'EXIT' && value > maxVal) {
        throw new Error(`Order value ₹${value.toFixed(0)} LIVE limit ₹${maxVal} se zyada hai (Admin → Brokers me limit badlein)`);
      }
    }
    const sym = db.prepare('SELECT exchange, broker_token FROM symbols WHERE symbol = ?').get(symbol) || {};
    const order = await b.placeOrder({ symbol, exchange: sym.exchange || 'NSE', side, qty, price, brokerToken: sym.broker_token || null });
    log('order', `[${b.name}] ${side} ${qty} x ${symbol} @ ~${price} → order ${order.orderId}`);
    return order;
  }

  /** Same warning baar-baar spam na ho - har key par 5 min me ek baar */
  warnOnce(key, message) {
    const last = this.warned.get(key) || 0;
    if (Date.now() - last < 5 * 60 * 1000) return;
    this.warned.set(key, Date.now());
    log('warn', message);
    this.emit('notice', { level: 'warn', message, time: Date.now() });
  }

  getPosition(symbol) {
    return db.prepare("SELECT * FROM trades WHERE symbol = ? AND status = 'OPEN'").get(symbol) || null;
  }

  openPositions() {
    return db.prepare("SELECT * FROM trades WHERE status = 'OPEN' ORDER BY opened_at DESC").all().map((t) => {
      const ltp = this.feed.getPrice(t.symbol) ?? t.entry_price;
      const dir = t.side === 'LONG' ? 1 : -1;
      return { ...t, ltp, unrealized: round((ltp - t.entry_price) * t.qty * dir) };
    });
  }

  openCount() {
    return db.prepare("SELECT COUNT(*) AS c FROM trades WHERE status = 'OPEN'").get().c;
  }

  stats() {
    const open = this.openPositions();
    const unrealized = round(open.reduce((a, p) => a + p.unrealized, 0));
    const w = wallet.summary({ unrealized });
    const closed = db.prepare(
      "SELECT COUNT(*) AS n, SUM(CASE WHEN pnl > 0 THEN 1 ELSE 0 END) AS wins FROM trades WHERE status = 'CLOSED'"
    ).get();
    return {
      initialCapital: w.initialCapital,
      realizedPnl: w.realizedPnl,
      unrealizedPnl: unrealized,
      equity: w.equity,
      available: w.available,   // 💰 withdraw / naye trade ke liye free paisa
      blocked: w.blocked,       // open positions me laga paisa
      deposited: w.deposited,
      withdrawn: w.withdrawn,
      totalTrades: closed.n,
      winRate: closed.n ? round((closed.wins / closed.n) * 100) : 0,
      openPositions: open.length,
      autoTrading: settings.bool('auto_trading'),
      broker: this.broker.name,
      brokerType: this.broker.type,
      brokerLive: !!this.broker.live,
    };
  }

  /** Pappu Bhai ka decision aaya */
  async onDecision(decision) {
    if (!settings.bool('auto_trading')) return;
    const { symbol, action, price } = decision;
    const pos = this.getPosition(symbol);

    try {
      if (action === 'BUY') {
        if (pos?.side === 'SHORT') await this.close(symbol, price, 'AI reversal signal');
        else if (!pos) await this.open({ symbol, side: 'LONG', price, decision });
      } else if (action === 'SELL') {
        if (pos?.side === 'LONG') await this.close(symbol, price, 'AI sell signal');
        else if (!pos && settings.bool('allow_short')) await this.open({ symbol, side: 'SHORT', price, decision });
      }
    } catch (e) {
      // broker / safety error - har candle par spam na ho
      this.warnOnce(`order-${symbol}-${e.message.slice(0, 40)}`, `${symbol}: order nahi laga - ${e.message}`);
    }
  }

  async open({ symbol, side, price, decision = null, source = 'AI', qty = null }) {
    if (this.getPosition(symbol)) throw new Error(`${symbol} me position already open hai`);
    if (source === 'AI' && this.openCount() >= settings.num('max_open_positions')) return null;

    const capital = this.stats().equity;
    const budget = (capital * settings.num('position_size_pct')) / 100;
    qty = qty || Math.floor(budget / price);
    if (qty < 1) {
      const msg = `${symbol} ka 1 share ₹${price.toFixed(2)} ka hai, lekin har trade ka budget sirf ₹${budget.toFixed(2)} hai `
        + `(equity ₹${capital.toFixed(0)} × ${settings.num('position_size_pct')}%). Admin → Settings me capital ya position size badhayein.`;
      if (source !== 'AI') throw new Error(msg); // manual trade: user ko error dikhao
      this.warnOnce(`qty-${symbol}`, msg);     // AI trade: chupchaap skip, warning throttled
      return null;
    }

    const order = await this.sendOrder({ symbol, side: side === 'LONG' ? 'BUY' : 'SELL', qty, price, source });
    const fill = order.fillPrice;
    const dir = side === 'LONG' ? 1 : -1;
    const stopDist = decision?.risk?.stopDistance || (fill * settings.num('stop_loss_pct')) / 100;
    const tgtDist = decision?.risk?.targetDistance || (fill * settings.num('target_pct')) / 100;
    const sl = round(fill - dir * stopDist);
    const tgt = round(fill + dir * tgtDist);

    const info = db.prepare(
      `INSERT INTO trades (symbol, side, qty, entry_price, stop_loss, target, status, source, decision_id, opened_at)
       VALUES (?, ?, ?, ?, ?, ?, 'OPEN', ?, ?, ?)`
    ).run(symbol, side, qty, fill, sl, tgt, source, decision?.id ?? null, Date.now());

    const trade = db.prepare('SELECT * FROM trades WHERE id = ?').get(info.lastInsertRowid);
    log('trade', `${source} OPEN ${side} ${qty} x ${symbol} @ ${fill} (SL ${sl}, TGT ${tgt}) [${this.broker.name} · ${order.orderId}]`);
    this.emit('trade', { type: 'OPEN', trade });
    return trade;
  }

  async close(symbol, price, reason = 'Manual') {
    const pos = this.getPosition(symbol);
    if (!pos || this.closing.has(symbol)) return null;
    this.closing.add(symbol);
    try {
      // Exit hamesha allowed (risk kam karta hai) - isliye source 'EXIT'
      const order = await this.sendOrder({ symbol, side: pos.side === 'LONG' ? 'SELL' : 'BUY', qty: pos.qty, price, source: 'EXIT' });
      const exit = order.fillPrice;
      const dir = pos.side === 'LONG' ? 1 : -1;
      const pnl = round((exit - pos.entry_price) * pos.qty * dir);
      db.prepare(
        "UPDATE trades SET status = 'CLOSED', exit_price = ?, pnl = ?, exit_reason = ?, closed_at = ? WHERE id = ?"
      ).run(exit, pnl, reason, Date.now(), pos.id);
      const trade = db.prepare('SELECT * FROM trades WHERE id = ?').get(pos.id);
      log('trade', `CLOSE ${pos.side} ${symbol} @ ${exit} | P&L ₹${pnl} | ${reason}`);
      this.emit('trade', { type: 'CLOSE', trade });
      return trade;
    } finally {
      this.closing.delete(symbol);
    }
  }

  /** Har tick par SL / Target check */
  onTick({ symbol, price }) {
    const pos = this.getPosition(symbol);
    if (!pos) return;
    if ((this.retryAfter.get(symbol) || 0) > Date.now()) return; // pichla exit fail hua tha - thoda ruko
    const onFail = (e) => {
      this.retryAfter.set(symbol, Date.now() + 30000);
      this.warnOnce(`exit-${symbol}`, `${symbol} EXIT fail (30s baad dobara try): ${e.message}`);
    };
    const long = pos.side === 'LONG';
    if ((long && price <= pos.stop_loss) || (!long && price >= pos.stop_loss)) {
      this.close(symbol, price, 'Stop-loss hit 🛑').catch(onFail);
    } else if ((long && price >= pos.target) || (!long && price <= pos.target)) {
      this.close(symbol, price, 'Target hit 🎯').catch(onFail);
    }
  }
}

module.exports = TradingEngine;
