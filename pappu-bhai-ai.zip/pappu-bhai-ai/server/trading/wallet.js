/**
 * 💰 Wallet - paisa add (deposit) aur withdrawal.
 *
 * Hisaab:
 *   cash (available) = initial_capital + deposits - withdrawals + realized P&L - blocked(in open positions)
 *   equity          = cash + blocked + unrealized P&L
 *
 * Balance me Admin → Settings ka initial_capital bhi shaamil hai (wo base capital hai).
 * Open positions me laga paisa "blocked" hota hai - withdraw nahi ho sakta.
 */
const { db, settings, log } = require('../db/database');

const round = (n) => Math.round(n * 100) / 100;

function summary({ unrealized = 0 } = {}) {
  const initial = settings.num('initial_capital') || 0;
  const flow = db.prepare(
    `SELECT COALESCE(SUM(CASE WHEN type = 'DEPOSIT'  THEN amount ELSE 0 END), 0) AS deposited,
            COALESCE(SUM(CASE WHEN type = 'WITHDRAW' THEN amount ELSE 0 END), 0) AS withdrawn
       FROM wallet_tx`
  ).get();
  const closed = db.prepare(
    "SELECT COALESCE(SUM(pnl), 0) AS pnl FROM trades WHERE status = 'CLOSED'"
  ).get();
  const open = db.prepare(
    "SELECT COUNT(*) AS n, COALESCE(SUM(qty * entry_price), 0) AS blocked FROM trades WHERE status = 'OPEN'"
  ).get();

  const net = flow.deposited - flow.withdrawn;
  const cash = round(initial + net + closed.pnl - open.blocked);

  return {
    initialCapital: round(initial),
    deposited: round(flow.deposited),
    withdrawn: round(flow.withdrawn),
    realizedPnl: round(closed.pnl),
    blocked: round(open.blocked),
    available: cash,                       // itna paisa withdraw / naye trade me lagane ke liye free hai
    equity: round(cash + open.blocked + unrealized),
    openPositions: open.n,
  };
}

/** Naya deposit / withdrawal. Galat amount par throw karta hai (user ko error dikhta hai). */
function add({ type, amount, note = '', user = '' }) {
  type = String(type || '').toUpperCase();
  if (type !== 'DEPOSIT' && type !== 'WITHDRAW') throw new Error('Type galat hai (DEPOSIT / WITHDRAW)');

  amount = Math.round(Number(amount) * 100) / 100;
  if (!Number.isFinite(amount) || amount <= 0) throw new Error('Amount ₹0 se zyada honi chahiye');
  if (amount > 1e9) throw new Error('Amount bahut zyada hai (max ₹1,00,00,00,000)');

  const before = summary();
  if (type === 'WITHDRAW') {
    if (before.available <= 0) {
      throw new Error(`Available balance ₹${before.available.toFixed(2)} hai - pehle paisa add karein`);
    }
    if (amount > before.available) {
      throw new Error(
        `Sirf ₹${before.available.toFixed(2)} available hai`
        + (before.blocked > 0 ? ` (₹${before.blocked.toFixed(0)} open positions me laga hai)` : '')
      );
    }
  }

  const after = round(before.available + (type === 'DEPOSIT' ? amount : -amount));
  const info = db.prepare(
    'INSERT INTO wallet_tx (type, amount, note, balance_after, user_email, created_at) VALUES (?, ?, ?, ?, ?, ?)'
  ).run(type, amount, String(note).slice(0, 200), after, user, Date.now());

  const label = type === 'DEPOSIT' ? 'Paisa add' : 'Withdrawal';
  log('info', `${label}: ₹${amount.toLocaleString('en-IN')} · balance ₹${after.toLocaleString('en-IN')}${note ? ` · ${note}` : ''} by ${user}`);
  return { id: info.lastInsertRowid, type, amount, balanceAfter: after };
}

function list(limit = 25) {
  return db.prepare('SELECT * FROM wallet_tx ORDER BY id DESC LIMIT ?').all(Math.min(Number(limit) || 25, 200));
}

module.exports = { summary, add, list };
