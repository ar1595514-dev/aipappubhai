const fs = require('fs');
const path = require('path');
const { DatabaseSync } = require('node:sqlite');
const config = require('../config');
const { hashPassword } = require('../utils/security');

fs.mkdirSync(path.dirname(config.dbPath), { recursive: true });

const db = new DatabaseSync(config.dbPath);
db.exec('PRAGMA journal_mode = WAL; PRAGMA foreign_keys = ON;');
// Purane database me naya column (migration) - schema.sql se pehle, kyunki CREATE TABLE IF NOT EXISTS purani table nahi badalta
function addColumnIfMissing(table, column, type) {
  const exists = db.prepare("SELECT name FROM sqlite_master WHERE type='table' AND name=?").get(table);
  if (exists && !db.prepare(`PRAGMA table_info(${table})`).all().some((c) => c.name === column)) {
    db.exec(`ALTER TABLE ${table} ADD COLUMN ${column} ${type}`);
  }
}
addColumnIfMissing('symbols', 'planet', 'TEXT');
addColumnIfMissing('symbols', 'broker_token', 'TEXT');
addColumnIfMissing('brokers', 'token_updated_at', 'INTEGER');
// Agents v2: indicator-based technical agents (admin panel se add/edit hote hain)
addColumnIfMissing('agents', 'indicator', 'TEXT');
addColumnIfMissing('agents', 'params', 'TEXT');
addColumnIfMissing('agents', 'custom', 'INTEGER NOT NULL DEFAULT 0');
db.exec(fs.readFileSync(path.join(__dirname, 'schema.sql'), 'utf8'));

const DEFAULT_SETTINGS = {
  auto_trading: 'false',        // Pappu Bhai ko trade lene ki permission
  allow_short: 'false',         // Short selling allow hai ya nahi
  initial_capital: '1000000',   // Paper trading capital (INR)
  position_size_pct: '10',      // Har trade me capital ka kitna %
  max_open_positions: '3',
  decision_threshold: '0.35',   // Score isse upar = BUY, -isse neeche = SELL
  stop_loss_pct: '1.0',         // Fallback agar ATR na mile
  target_pct: '2.0',
  market_name: 'NSE (Simulated)',
  astro_mode: 'true',           // 🔮 ON = team sirf Jyotish Guru ke chune token par analysis karegi
  astro_refresh_sec: '60',      // Kitni der me panchang dobara check ho (hora badalte hi naya pick)
  allow_live_ai: 'false',       // 🏦 LIVE broker par AI khud order laga sake? (default NAHI - safety)
  live_max_order_value: '10000',// 🏦 LIVE broker par ek order ki max value (₹)
};

// Sector ke hisaab se token ka swami grah
const DEFAULT_PLANETS = {
  RELIANCE: 'Sun',   // Energy / Oil
  TCS: 'Mercury',    // IT
  HDFCBANK: 'Jupiter', // Banking / Finance
  INFY: 'Mercury',   // IT
  NIFTY50: 'Moon',   // Janta ka sentiment
};

const DEFAULT_SYMBOLS = [
  ['RELIANCE', 'Reliance Industries', 'NSE', 2950],
  ['TCS', 'Tata Consultancy Services', 'NSE', 4100],
  ['HDFCBANK', 'HDFC Bank', 'NSE', 1680],
  ['INFY', 'Infosys', 'NSE', 1850],
  ['NIFTY50', 'Nifty 50 Index', 'NSE', 24800],
];

const DEFAULT_AGENTS = [
  ['risk', 'Risk Rakshak', '🛡️', 'Volatility (ATR) check karke stop-loss/target deta hai, zarurat pade to trade VETO karta hai', 0],
  ['astro', 'Jyotish Guru', '🔮', 'Real-time panchang (vaar, hora, tithi, nakshatra, Rahu Kaal) se shubh token chunta hai - team usi par analysis karti hai', 0.5],
];

// 📈 Technical team - har agent ka ek indicator + params hota hai (DB se padha jata hai).
// Inhe admin panel → Agents me edit/ON-OFF/delete kar sakte hain, aur naye bana sakte hain.
const TECH_AGENTS = [
  ['ema20', 'EMA 20', '📈', 'Short-term trend - price EMA 20 ke upar/neeche + slope dekhta hai', 1.2, 'ema', { period: 20 }],
  ['ema50', 'EMA 50', '🧭', 'Medium-term trend - EMA 50 se bade trend ka rukh pakadta hai', 1.2, 'ema', { period: 50 }],
  ['vwap', 'VWAP', '⚖️', 'Intraday trend / average price - VWAP ke upar buyers ka pressure', 1.1, 'vwap', {}],
  ['rsi', 'RSI 14', '🌡️', 'Momentum - oversold (30-) par BUY, overbought (70+) par SELL', 1.1, 'rsi', { period: 14, buy: 30, sell: 70 }],
  ['macd', 'MACD', '📉', 'Trend + momentum confirmation - MACD line vs signal line', 1.2, 'macd', { fast: 12, slow: 26, signal: 9 }],
  ['volume', 'Volume', '🔊', 'Buying/selling activity - volume spike + price direction', 1.0, 'volume', { period: 20, spike: 1.5 }],
  ['supertrend', 'Supertrend', '🌊', 'Trend direction - supertrend line ke upar = uptrend, neeche = downtrend', 1.2, 'supertrend', { period: 10, mult: 3 }],
  ['adx', 'ADX', '💪', 'Trend ki strength - ADX zyada = strong trend, kam = sideways market', 1.0, 'adx', { period: 14, threshold: 20 }],
  ['bollinger', 'Bollinger Bands', '📏', 'Volatility aur price range - band ke upper/lower end par mean reversion', 1.0, 'bollinger', { period: 20, mult: 2 }],
  ['atr', 'ATR', '🛑', 'Volatility aur stop-loss planning - ATR se SL distance, volatility high par caution', 1.0, 'atr', { period: 14, highPct: 2 }],
];

function seed() {
  const now = Date.now();

  const insertSetting = db.prepare('INSERT OR IGNORE INTO settings (key, value) VALUES (?, ?)');
  for (const [k, v] of Object.entries(DEFAULT_SETTINGS)) insertSetting.run(k, v);

  const insertAgent = db.prepare(
    'INSERT OR IGNORE INTO agents (key, name, icon, description, weight) VALUES (?, ?, ?, ?, ?)'
  );
  for (const a of DEFAULT_AGENTS) insertAgent.run(...a);

  // 📈 Agents v2 (sirf ek baar): purane fixed agents (technical/trend/pattern/sentiment)
  //    hata kar indicator-based technical team jodna. Flag `agents_seeded` ke baad
  //    dobara nahi chalta - isliye admin panel se delete kiye gaye agent wapas nahi aate.
  if (!db.prepare('SELECT value FROM settings WHERE key = ?').get('agents_seeded')) {
    db.exec("DELETE FROM agents WHERE key IN ('technical','trend','pattern','sentiment')");
    const upsertTech = db.prepare(
      `INSERT INTO agents (key, name, icon, description, weight, enabled, indicator, params, custom)
       VALUES (?, ?, ?, ?, ?, 1, ?, ?, 0)
       ON CONFLICT(key) DO UPDATE SET name = excluded.name, icon = excluded.icon,
         description = excluded.description, weight = excluded.weight,
         indicator = excluded.indicator, params = excluded.params, custom = 0`
    );
    for (const [key, name, icon, desc, weight, indicator, params] of TECH_AGENTS) {
      upsertTech.run(key, name, icon, desc, weight, indicator, JSON.stringify(params));
    }
    insertSetting.run('agents_seeded', '2');
    console.log('[db] Agents v2: 10 indicator agents jode, purane agent delete kiye');
  }

  const symCount = db.prepare('SELECT COUNT(*) AS c FROM symbols').get().c;
  if (symCount === 0) {
    const insertSym = db.prepare(
      'INSERT INTO symbols (symbol, name, exchange, base_price) VALUES (?, ?, ?, ?)'
    );
    for (const s of DEFAULT_SYMBOLS) insertSym.run(...s);
  }
  const setPlanet = db.prepare('UPDATE symbols SET planet = ? WHERE symbol = ? AND planet IS NULL');
  for (const [sym, planet] of Object.entries(DEFAULT_PLANETS)) setPlanet.run(planet, sym);

  // Default paper broker (hamesha ek broker active rahe)
  if (db.prepare('SELECT COUNT(*) AS c FROM brokers').get().c === 0) {
    db.prepare(
      "INSERT INTO brokers (name, type, is_active, status, status_msg, created_at) VALUES (?, 'paper', 1, 'ok', ?, ?)"
    ).run('Paper Trading (Demo)', 'Virtual paisa - koi asli order nahi', now);
  }

  const userCount = db.prepare('SELECT COUNT(*) AS c FROM users').get().c;
  if (userCount === 0) {
    db.prepare(
      'INSERT INTO users (name, email, password_hash, role, created_at) VALUES (?, ?, ?, ?, ?)'
    ).run('Pappu Admin', config.adminEmail, hashPassword(config.adminPassword), 'admin', now);
    console.log(`[db] Default admin bana: ${config.adminEmail} / ${config.adminPassword}`);
  }
}

seed();

// ---------- Helper functions ----------
const settings = {
  all() {
    const rows = db.prepare('SELECT key, value FROM settings').all();
    return Object.fromEntries(rows.map((r) => [r.key, r.value]));
  },
  get(key) {
    const row = db.prepare('SELECT value FROM settings WHERE key = ?').get(key);
    return row ? row.value : undefined;
  },
  num(key) {
    return Number(settings.get(key));
  },
  bool(key) {
    return settings.get(key) === 'true';
  },
  set(key, value) {
    db.prepare(
      'INSERT INTO settings (key, value) VALUES (?, ?) ON CONFLICT(key) DO UPDATE SET value = excluded.value'
    ).run(key, String(value));
  },
};

function log(level, message) {
  db.prepare('INSERT INTO logs (level, message, created_at) VALUES (?, ?, ?)').run(
    level,
    message,
    Date.now()
  );
  console.log(`[${level}] ${message}`);
}

module.exports = { db, settings, log };
