-- Pappu Bhai AI - Database Schema (SQLite)

CREATE TABLE IF NOT EXISTS users (
  id            INTEGER PRIMARY KEY AUTOINCREMENT,
  name          TEXT NOT NULL,
  email         TEXT NOT NULL UNIQUE,
  password_hash TEXT NOT NULL,
  role          TEXT NOT NULL DEFAULT 'trader' CHECK (role IN ('admin','trader')),
  created_at    INTEGER NOT NULL
);

CREATE TABLE IF NOT EXISTS symbols (
  id         INTEGER PRIMARY KEY AUTOINCREMENT,
  symbol     TEXT NOT NULL UNIQUE,
  name       TEXT NOT NULL,
  exchange   TEXT NOT NULL DEFAULT 'NSE',
  base_price REAL NOT NULL,
  planet     TEXT,              -- Jyotish: token ka swami grah (Sun, Moon, Mars ...)
  broker_token TEXT,            -- Broker instrument ID (Upstox instrument_key / Dhan securityId / Angel symboltoken)
  active     INTEGER NOT NULL DEFAULT 1
);

-- 🔮 Jyotish Guru ke chune hue tokens ka itihaas
CREATE TABLE IF NOT EXISTS astro_picks (
  id         INTEGER PRIMARY KEY AUTOINCREMENT,
  symbol     TEXT NOT NULL,
  planet     TEXT NOT NULL,
  score      REAL NOT NULL,
  vaar       TEXT NOT NULL,
  hora_lord  TEXT NOT NULL,
  tithi      TEXT NOT NULL,
  nakshatra  TEXT NOT NULL,
  rahu_kaal  INTEGER NOT NULL DEFAULT 0,
  reason     TEXT NOT NULL,
  created_at INTEGER NOT NULL
);

CREATE TABLE IF NOT EXISTS agents (
  key         TEXT PRIMARY KEY,
  name        TEXT NOT NULL,
  icon        TEXT NOT NULL,
  description TEXT NOT NULL,
  weight      REAL NOT NULL DEFAULT 1,
  enabled     INTEGER NOT NULL DEFAULT 1,
  indicator   TEXT,             -- technical agent ka indicator (ema, rsi, macd, ...)
  params      TEXT,             -- indicator params (JSON): { period: 20 }
  custom      INTEGER NOT NULL DEFAULT 0  -- 1 = admin panel se banaya gaya agent
);

CREATE TABLE IF NOT EXISTS signals (
  id          INTEGER PRIMARY KEY AUTOINCREMENT,
  analysis_id TEXT NOT NULL,
  symbol      TEXT NOT NULL,
  agent_key   TEXT NOT NULL,
  action      TEXT NOT NULL,
  confidence  REAL NOT NULL,
  reason      TEXT NOT NULL,
  created_at  INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_signals_symbol ON signals(symbol, created_at DESC);

CREATE TABLE IF NOT EXISTS decisions (
  id          INTEGER PRIMARY KEY AUTOINCREMENT,
  analysis_id TEXT NOT NULL,
  symbol      TEXT NOT NULL,
  action      TEXT NOT NULL,
  score       REAL NOT NULL,
  confidence  REAL NOT NULL,
  price       REAL NOT NULL,
  summary     TEXT NOT NULL,
  created_at  INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_decisions_symbol ON decisions(symbol, created_at DESC);

CREATE TABLE IF NOT EXISTS trades (
  id          INTEGER PRIMARY KEY AUTOINCREMENT,
  symbol      TEXT NOT NULL,
  side        TEXT NOT NULL CHECK (side IN ('LONG','SHORT')),
  qty         INTEGER NOT NULL,
  entry_price REAL NOT NULL,
  exit_price  REAL,
  stop_loss   REAL,
  target      REAL,
  pnl         REAL,
  status      TEXT NOT NULL DEFAULT 'OPEN' CHECK (status IN ('OPEN','CLOSED')),
  source      TEXT NOT NULL DEFAULT 'AI',
  exit_reason TEXT,
  decision_id INTEGER,
  opened_at   INTEGER NOT NULL,
  closed_at   INTEGER
);
CREATE INDEX IF NOT EXISTS idx_trades_status ON trades(status);

-- 🏦 Broker accounts (secrets encrypted)
CREATE TABLE IF NOT EXISTS brokers (
  id               INTEGER PRIMARY KEY AUTOINCREMENT,
  name             TEXT NOT NULL,
  type             TEXT NOT NULL,          -- paper | zerodha | upstox | angel | dhan | fyers
  client_id        TEXT,
  api_key          TEXT,
  api_secret_enc   TEXT,
  access_token_enc TEXT,
  token_updated_at INTEGER,                 -- access token kab daala (roz expire hota hai)
  product          TEXT NOT NULL DEFAULT 'INTRADAY', -- INTRADAY | DELIVERY
  is_active        INTEGER NOT NULL DEFAULT 0,
  status           TEXT NOT NULL DEFAULT 'untested', -- untested | ok | error
  status_msg       TEXT,
  last_tested_at   INTEGER,
  created_at       INTEGER NOT NULL
);

-- 🔑 Third-party API keys (News, LLM, custom)
CREATE TABLE IF NOT EXISTS api_keys (
  id             INTEGER PRIMARY KEY AUTOINCREMENT,
  provider       TEXT NOT NULL,            -- newsapi | openai | gemini | custom
  name           TEXT NOT NULL,
  key_enc        TEXT,
  base_url       TEXT,
  model          TEXT,
  enabled        INTEGER NOT NULL DEFAULT 1,
  status         TEXT NOT NULL DEFAULT 'untested',
  status_msg     TEXT,
  last_tested_at INTEGER,
  created_at     INTEGER NOT NULL
);

-- 💰 Wallet: paisa add (deposit) / withdrawal ki poori history
CREATE TABLE IF NOT EXISTS wallet_tx (
  id            INTEGER PRIMARY KEY AUTOINCREMENT,
  type          TEXT NOT NULL,             -- DEPOSIT | WITHDRAW
  amount        REAL NOT NULL,
  note          TEXT,
  balance_after REAL NOT NULL,             -- transaction ke baad available balance
  user_email    TEXT,
  created_at    INTEGER NOT NULL
);

CREATE TABLE IF NOT EXISTS settings (
  key   TEXT PRIMARY KEY,
  value TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS logs (
  id         INTEGER PRIMARY KEY AUTOINCREMENT,
  level      TEXT NOT NULL,
  message    TEXT NOT NULL,
  created_at INTEGER NOT NULL
);
