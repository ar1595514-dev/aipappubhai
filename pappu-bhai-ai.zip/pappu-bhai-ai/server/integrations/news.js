/**
 * Live news + sentiment.
 *  - NewsAPI key ho to asli headlines (10 min cache, taaki free quota bache)
 *  - OpenAI / Gemini key ho to LLM sentiment, warna simple keyword scoring
 */
const { getKey } = require('./apiKeys');
const { http } = require('../trading/brokers/http');

const cache = new Map(); // symbol -> { time, headlines }
const CACHE_MS = 10 * 60 * 1000;

const POSITIVE = ['surge', 'jump', 'rally', 'gain', 'profit', 'beat', 'record', 'upgrade', 'buy', 'strong', 'growth', 'order win', 'rises', 'soar', 'bullish', 'expansion', 'dividend'];
const NEGATIVE = ['fall', 'drop', 'slump', 'loss', 'miss', 'downgrade', 'sell', 'weak', 'probe', 'fraud', 'penalty', 'decline', 'plunge', 'bearish', 'lawsuit', 'raid', 'cut'];

async function fetchHeadlines(symbol, name) {
  const key = getKey('newsapi');
  if (!key) return null;
  const hit = cache.get(symbol);
  if (hit && Date.now() - hit.time < CACHE_MS) return hit.headlines;

  const q = encodeURIComponent(`"${name.replace(/ (Ltd|Limited|Index)$/i, '')}"`);
  const r = await http(
    `https://newsapi.org/v2/everything?q=${q}&language=en&sortBy=publishedAt&pageSize=8&apiKey=${encodeURIComponent(key.key)}`,
    { timeout: 6000 }
  );
  const headlines = (r.articles || []).map((a) => a.title).filter(Boolean);
  cache.set(symbol, { time: Date.now(), headlines });
  return headlines;
}

function keywordScore(headlines) {
  let s = 0;
  for (const h of headlines) {
    const t = h.toLowerCase();
    POSITIVE.forEach((w) => { if (t.includes(w)) s += 1; });
    NEGATIVE.forEach((w) => { if (t.includes(w)) s -= 1; });
  }
  return Math.max(-1, Math.min(1, s / Math.max(3, headlines.length)));
}

const PROMPT = (symbol, headlines) =>
  `You are a stock market news sentiment analyst. For the Indian stock ${symbol}, rate the overall sentiment of these headlines `
  + `from -1 (very bearish) to 1 (very bullish). Reply ONLY with JSON: {"score": number, "reason": "short reason in Hinglish"}\n\n`
  + headlines.map((h, i) => `${i + 1}. ${h}`).join('\n');

function parseLLM(text) {
  const m = String(text).match(/\{[\s\S]*\}/);
  if (!m) throw new Error('LLM ne JSON nahi diya');
  const j = JSON.parse(m[0]);
  return { score: Math.max(-1, Math.min(1, Number(j.score) || 0)), reason: String(j.reason || '').slice(0, 160) };
}

async function llmScore(symbol, headlines) {
  const openai = getKey('openai');
  if (openai) {
    const r = await http(`${openai.base_url.replace(/\/$/, '')}/chat/completions`, {
      method: 'POST',
      timeout: 12000,
      headers: { Authorization: `Bearer ${openai.key}` },
      body: { model: openai.model, temperature: 0, messages: [{ role: 'user', content: PROMPT(symbol, headlines) }] },
    });
    return { ...parseLLM(r.choices?.[0]?.message?.content), via: `OpenAI (${openai.model})` };
  }
  const gemini = getKey('gemini');
  if (gemini) {
    const r = await http(
      `https://generativelanguage.googleapis.com/v1beta/models/${gemini.model}:generateContent?key=${encodeURIComponent(gemini.key)}`,
      { method: 'POST', timeout: 12000, body: { contents: [{ parts: [{ text: PROMPT(symbol, headlines) }] }] } }
    );
    return { ...parseLLM(r.candidates?.[0]?.content?.parts?.[0]?.text), via: `Gemini (${gemini.model})` };
  }
  return null;
}

/** Live sentiment; NewsAPI key na ho to null (agent simulated mode me chalega) */
async function liveSentiment(symbol, name) {
  const headlines = await fetchHeadlines(symbol, name);
  if (!headlines) return null;
  if (!headlines.length) return { score: 0, reason: 'Pichle dino koi news nahi mili', headlines, via: 'NewsAPI' };
  try {
    const llm = await llmScore(symbol, headlines);
    if (llm) return { ...llm, headlines, via: `NewsAPI + ${llm.via}` };
  } catch (e) {
    // LLM fail -> keyword fallback
    return { score: keywordScore(headlines), reason: `"${headlines[0]}" (LLM error: ${e.message.slice(0, 60)})`, headlines, via: 'NewsAPI + keywords' };
  }
  return { score: keywordScore(headlines), reason: `"${headlines[0]}"`, headlines, via: 'NewsAPI + keywords' };
}

module.exports = { liveSentiment };
