/**
 * 🔑 Third-party API keys - Admin panel se add hote hain, DB me encrypted.
 * Agents yahan se key lete hain (news sentiment pipeline → NewsAPI + LLM).
 */
const { db } = require('../db/database');
const { decrypt, mask } = require('../utils/security');
const { http } = require('../trading/brokers/http');

const PROVIDERS = {
  newsapi: {
    label: 'NewsAPI.org (Live news)',
    usedBy: 'News headlines lane ke liye (news sentiment agent ke saath use hoti hai)',
    docs: 'https://newsapi.org/register',
    fields: ['key'],
    async test({ key }) {
      const r = await http(`https://newsapi.org/v2/everything?q=Nifty&pageSize=1&apiKey=${encodeURIComponent(key)}`);
      if (r.status !== 'ok') throw new Error(r.message || 'NewsAPI error');
      return `OK · ${r.totalResults} articles available`;
    },
  },
  openai: {
    label: 'OpenAI / OpenAI-compatible LLM',
    usedBy: 'Headlines ka sentiment AI se samajhne ke liye',
    docs: 'https://platform.openai.com/api-keys',
    fields: ['key', 'base_url', 'model'],
    defaults: { base_url: 'https://api.openai.com/v1', model: 'gpt-4o-mini' },
    async test({ key, base_url }) {
      const r = await http(`${base_url.replace(/\/$/, '')}/models`, { headers: { Authorization: `Bearer ${key}` } });
      return `OK · ${r.data?.length ?? 0} models`;
    },
  },
  gemini: {
    label: 'Google Gemini',
    usedBy: 'Headlines ka sentiment AI se samajhne ke liye',
    docs: 'https://aistudio.google.com/app/apikey',
    fields: ['key', 'model'],
    defaults: { model: 'gemini-1.5-flash' },
    async test({ key }) {
      const r = await http(`https://generativelanguage.googleapis.com/v1beta/models?key=${encodeURIComponent(key)}`);
      return `OK · ${r.models?.length ?? 0} models`;
    },
  },
  custom: {
    label: 'Custom API / Webhook',
    usedBy: 'Apne code me getKey("custom") se use karein',
    docs: null,
    fields: ['key', 'base_url'],
    async test({ key, base_url }) {
      if (!base_url) throw new Error('Base URL daalein');
      const res = await fetch(base_url, { headers: key ? { Authorization: `Bearer ${key}` } : {}, signal: AbortSignal.timeout(8000) });
      if (res.status >= 500) throw new Error(`HTTP ${res.status}`);
      return `Reachable · HTTP ${res.status}`;
    },
  },
};

function providersForUI() {
  return Object.fromEntries(Object.entries(PROVIDERS).map(([k, p]) => [k, {
    label: p.label, usedBy: p.usedBy, docs: p.docs, fields: p.fields, defaults: p.defaults || {},
  }]));
}

function configOf(row) {
  const d = PROVIDERS[row.provider]?.defaults || {};
  return { key: decrypt(row.key_enc), base_url: row.base_url || d.base_url || '', model: row.model || d.model || '' };
}

function publicRow(row) {
  const key = decrypt(row.key_enc);
  return {
    id: row.id,
    provider: row.provider,
    providerLabel: PROVIDERS[row.provider]?.label || row.provider,
    name: row.name,
    key: mask(key),
    has_key: !!key,
    base_url: row.base_url || '',
    model: row.model || '',
    enabled: !!row.enabled,
    status: row.status,
    status_msg: row.status_msg,
    last_tested_at: row.last_tested_at,
    created_at: row.created_at,
  };
}

/** Kisi provider ki pehli enabled key (agents ke liye) */
function getKey(provider) {
  const row = db.prepare('SELECT * FROM api_keys WHERE provider = ? AND enabled = 1 ORDER BY id LIMIT 1').get(provider);
  if (!row) return null;
  const cfg = configOf(row);
  return cfg.key ? cfg : null;
}

async function testRow(row) {
  const p = PROVIDERS[row.provider];
  if (!p) throw new Error('Unknown provider');
  const cfg = configOf(row);
  if (!cfg.key && row.provider !== 'custom') throw new Error('API key missing');
  return p.test(cfg);
}

module.exports = { PROVIDERS, providersForUI, publicRow, getKey, testRow };
