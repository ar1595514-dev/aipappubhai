const crypto = require('crypto');
const config = require('../config');

function hashPassword(password) {
  const salt = crypto.randomBytes(16).toString('hex');
  const hash = crypto.scryptSync(password, salt, 64).toString('hex');
  return `${salt}:${hash}`;
}

function verifyPassword(password, stored) {
  if (!stored || !stored.includes(':')) return false;
  const [salt, hash] = stored.split(':');
  const candidate = crypto.scryptSync(password, salt, 64);
  const expected = Buffer.from(hash, 'hex');
  return expected.length === candidate.length && crypto.timingSafeEqual(candidate, expected);
}

function sign(body) {
  return crypto.createHmac('sha256', config.secret).update(body).digest('base64url');
}

function signToken(payload) {
  const body = Buffer.from(
    JSON.stringify({ ...payload, exp: Date.now() + config.tokenTtlMs })
  ).toString('base64url');
  return `${body}.${sign(body)}`;
}

function verifyToken(token) {
  if (!token || typeof token !== 'string' || !token.includes('.')) return null;
  const [body, sig] = token.split('.');
  const expected = sign(body);
  if (sig.length !== expected.length) return null;
  if (!crypto.timingSafeEqual(Buffer.from(sig), Buffer.from(expected))) return null;
  try {
    const payload = JSON.parse(Buffer.from(body, 'base64url').toString());
    if (payload.exp < Date.now()) return null;
    return payload;
  } catch {
    return null;
  }
}

// ---------- Secrets encryption (broker / API keys) - AES-256-GCM ----------
// Key APP_SECRET se banti hai. APP_SECRET badla to purane saved keys decrypt nahi honge (dobara daalni padegi).
const ENC_KEY = crypto.createHash('sha256').update(`enc:${config.secret}`).digest();

function encrypt(plain) {
  if (plain == null || plain === '') return null;
  const iv = crypto.randomBytes(12);
  const cipher = crypto.createCipheriv('aes-256-gcm', ENC_KEY, iv);
  const data = Buffer.concat([cipher.update(String(plain), 'utf8'), cipher.final()]);
  return `v1:${iv.toString('base64')}:${cipher.getAuthTag().toString('base64')}:${data.toString('base64')}`;
}

function decrypt(blob) {
  if (!blob) return '';
  try {
    const [, iv, tag, data] = blob.split(':');
    const decipher = crypto.createDecipheriv('aes-256-gcm', ENC_KEY, Buffer.from(iv, 'base64'));
    decipher.setAuthTag(Buffer.from(tag, 'base64'));
    return Buffer.concat([decipher.update(Buffer.from(data, 'base64')), decipher.final()]).toString('utf8');
  } catch {
    return ''; // galat APP_SECRET ya corrupt data
  }
}

/** UI me sirf aakhri 4 character dikhao */
function mask(plain) {
  if (!plain) return '';
  return plain.length <= 4 ? '••••' : `••••••${plain.slice(-4)}`;
}

module.exports = { hashPassword, verifyPassword, signToken, verifyToken, encrypt, decrypt, mask };
