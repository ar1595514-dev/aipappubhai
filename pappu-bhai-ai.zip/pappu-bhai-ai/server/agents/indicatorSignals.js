/**
 * 📈 Indicator Signals - data-driven technical agents
 *
 * Har technical agent ka config DB `agents` table me hota hai:
 *      { indicator: 'ema' | 'rsi' | 'macd' | ..., params: { period: 20 } }
 *
 *  - INDICATORS : admin panel ka form schema (fields, defaults, min/max) + validation
 *  - evaluate() : candles se { action, confidence, reason, data } deta hai
 *  - normalizeParams() : user ke params ko schema ke hisaab se saaf karta hai
 *
 * Admin panel → Agents me "➕ Naya technical agent" se aap inhi indicators ka
 * apna agent (jaise EMA 200, RSI 7, Supertrend 7/2) bana sakte ho - code chhune ki zarurat nahi.
 */
const {
  ema, rsi, macd, atr, bollinger, sma, vwap, supertrend, adx, last, clamp,
} = require('./indicators');

// ---------- Indicator schema (admin form + validation dono yahi use karte hain) ----------
const INDICATORS = {
  ema: {
    label: 'EMA (price vs trend line)',
    emoji: '📈',
    desc: 'Price aur EMA ke beech ka gap + EMA ka slope - trend ka direction batata hai.',
    params: [
      { key: 'period', label: 'Period (EMA window)', def: 20, min: 2, max: 400, step: 1 },
    ],
    describe: (p) => `EMA ${p.period} ke upar/neeche + slope`,
  },
  vwap: {
    label: 'VWAP (average price)',
    emoji: '⚖️',
    desc: 'Intraday trend / average price - price VWAP ke upar = buyers ka pressure.',
    params: [],
    describe: () => 'VWAP ke upar/neeche - din ka average price',
  },
  rsi: {
    label: 'RSI (momentum)',
    emoji: '🌡️',
    desc: 'Momentum - oversold neeche se BUY, overbought upar se SELL, beech me 50 ka bias.',
    params: [
      { key: 'period', label: 'Period', def: 14, min: 2, max: 100, step: 1 },
      { key: 'buy', label: 'Oversold level (is se neeche BUY)', def: 30, min: 5, max: 49, step: 1 },
      { key: 'sell', label: 'Overbought level (is se upar SELL)', def: 70, min: 51, max: 95, step: 1 },
    ],
    describe: (p) => `RSI ${p.period} (${p.buy} neeche = BUY / ${p.sell} upar = SELL)`,
  },
  macd: {
    label: 'MACD (trend + momentum)',
    emoji: '📉',
    desc: 'Trend + momentum confirmation - MACD line vs signal line ka crossing.',
    params: [
      { key: 'fast', label: 'Fast EMA', def: 12, min: 2, max: 100, step: 1 },
      { key: 'slow', label: 'Slow EMA', def: 26, min: 5, max: 300, step: 1 },
      { key: 'signal', label: 'Signal EMA', def: 9, min: 2, max: 100, step: 1 },
    ],
    describe: (p) => `MACD ${p.fast}/${p.slow}/${p.signal}`,
  },
  volume: {
    label: 'Volume (buying/selling activity)',
    emoji: '🔊',
    desc: 'Buying/selling activity - average se zyada volume spike + price ka direction.',
    params: [
      { key: 'period', label: 'Average volume period', def: 20, min: 2, max: 200, step: 1 },
      { key: 'spike', label: 'Spike kitna x average?', def: 1.5, min: 1, max: 10, step: 0.1 },
    ],
    describe: (p) => `Volume ${p.spike}× spike (${p.period} period average)`,
  },
  supertrend: {
    label: 'Supertrend (trend direction)',
    emoji: '🌊',
    desc: 'Trend direction - price supertrend line ke upar = up, neeche = down.',
    params: [
      { key: 'period', label: 'ATR period', def: 10, min: 2, max: 100, step: 1 },
      { key: 'mult', label: 'Multiplier', def: 3, min: 1, max: 10, step: 0.1 },
    ],
    describe: (p) => `Supertrend ${p.period}/${p.mult}`,
  },
  adx: {
    label: 'ADX (trend strength)',
    emoji: '💪',
    desc: 'Trend ki strength - ADX threshold se upar = strong trend, +DI/-DI se direction.',
    params: [
      { key: 'period', label: 'Period', def: 14, min: 2, max: 100, step: 1 },
      { key: 'threshold', label: 'Strong trend threshold (ADX)', def: 20, min: 10, max: 50, step: 1 },
    ],
    describe: (p) => `ADX ${p.period} (strong ≥ ${p.threshold})`,
  },
  bollinger: {
    label: 'Bollinger Bands (volatility + range)',
    emoji: '📏',
    desc: 'Volatility aur price range - band ke bahar ja par mean reversion, andar %B se bias.',
    params: [
      { key: 'period', label: 'Period (SMA)', def: 20, min: 5, max: 200, step: 1 },
      { key: 'mult', label: 'Standard deviations', def: 2, min: 1, max: 5, step: 0.1 },
    ],
    describe: (p) => `Bollinger ${p.period} ±${p.mult}σ`,
  },
  atr: {
    label: 'ATR (volatility + stop-loss)',
    emoji: '🛑',
    desc: 'Volatility aur stop-loss planning - ATR se SL distance, volatility bahut high par caution.',
    params: [
      { key: 'period', label: 'Period', def: 14, min: 2, max: 100, step: 1 },
      { key: 'highPct', label: 'Itne % se upar = volatility HIGH', def: 2, min: 0.2, max: 10, step: 0.1 },
    ],
    describe: (p) => `ATR ${p.period} (high ≥ ${p.highPct}%)`,
  },
};

const pct = (a, b) => (b ? ((a - b) / b) * 100 : 0);
const hold = (reason, data = {}) => ({ action: 'HOLD', confidence: 0.3, reason, data });

// ---------- Params validation (server par hamesha yahi guzarta hai) ----------
function normalizeParams(indicator, params) {
  const meta = INDICATORS[indicator];
  if (!meta) throw new Error('Indicator chunein (ema, rsi, macd ...)');
  const out = {};
  for (const p of meta.params) {
    let v = Number(params && params[p.key]);
    if (!Number.isFinite(v)) v = p.def;
    v = Math.min(p.max, Math.max(p.min, v));
    out[p.key] = p.step >= 1 ? Math.round(v) : Math.round(v * 10) / 10;
  }
  return out;
}

/** Agent ka description (admin panel me dikhta hai) */
function describe(indicator, params) {
  const meta = INDICATORS[indicator];
  if (!meta) return String(indicator);
  const p = normalizeParams(indicator, params || {});
  return meta.describe(p);
}

// ---------- Har indicator ka signal logic ----------
function emaSig({ period }, ctx) {
  const closes = ctx.candles.map((c) => c.close);
  const series = ema(closes, period);
  const now = last(series);
  const price = ctx.price ?? last(closes);
  if (now == null) return hold(`EMA ${period} ke liye candles kam hain (${period}+ chahiye)`);
  const back = series[Math.max(0, series.length - 6)];
  const gap = pct(price, now);
  const slope = back ? pct(now, back) : 0;
  const score = gap + slope * 0.6;
  const action = score > 0.1 ? 'BUY' : score < -0.1 ? 'SELL' : 'HOLD';
  return {
    action,
    confidence: +clamp(0.3 + Math.abs(score) * 0.4, 0.3, 0.9).toFixed(3),
    reason: `Price EMA ${period} (₹${now.toFixed(2)}) ke ${gap >= 0 ? 'upar' : 'neeche'} `
      + `(${gap >= 0 ? '+' : ''}${gap.toFixed(2)}%) · EMA ${slope >= 0 ? 'badh' : 'ghat'} raha hai `
      + `(${slope >= 0 ? '+' : ''}${slope.toFixed(2)}% slope)`,
    data: { ema: +now.toFixed(2), price: +price.toFixed(2), gapPct: +gap.toFixed(2), slopePct: +slope.toFixed(2) },
  };
}

function vwapSig(_p, ctx) {
  const series = vwap(ctx.candles);
  const vw = last(series);
  const price = ctx.price ?? last(ctx.candles).close;
  if (vw == null) return hold('VWAP ke liye candle nahi mili');
  const gap = pct(price, vw);
  const action = gap > 0.08 ? 'BUY' : gap < -0.08 ? 'SELL' : 'HOLD';
  return {
    action,
    confidence: +clamp(0.35 + Math.abs(gap) * 0.4, 0.35, 0.88).toFixed(3),
    reason: `Price VWAP (₹${vw.toFixed(2)}) ke ${gap >= 0 ? 'upar' : 'neeche'} `
      + `(${gap >= 0 ? '+' : ''}${gap.toFixed(2)}%) - din ka average ${gap >= 0 ? 'khareedari' : 'bikwast'} pressure`,
    data: { vwap: +vw.toFixed(2), price: +price.toFixed(2), gapPct: +gap.toFixed(2) },
  };
}

function rsiSig({ period, buy, sell }, ctx) {
  const closes = ctx.candles.map((c) => c.close);
  const r = last(rsi(closes, period));
  if (r == null) return hold(`RSI ${period} ke liye candles kam hain`);
  const data = { rsi: +r.toFixed(2) };
  if (r >= sell) {
    return {
      action: 'SELL',
      confidence: +clamp(0.4 + ((r - sell) / Math.max(1, 100 - sell)) * 0.6, 0.4, 0.95).toFixed(3),
      reason: `RSI ${r.toFixed(1)} = overbought (${sell}+) - aage girne ki sambhavna`,
      data,
    };
  }
  if (r <= buy) {
    return {
      action: 'BUY',
      confidence: +clamp(0.4 + ((buy - r) / Math.max(1, buy)) * 0.6, 0.4, 0.95).toFixed(3),
      reason: `RSI ${r.toFixed(1)} = oversold (${buy}-) - bounce ki sambhavna`,
      data,
    };
  }
  const bull = r >= 50;
  return {
    action: bull ? 'BUY' : 'SELL',
    confidence: +clamp(0.32 + (bull ? (r - 50) : (50 - r)) * 0.01, 0.32, 0.7).toFixed(3),
    reason: `RSI ${r.toFixed(1)} = momentum ${bull ? 'bullish (50+)' : 'bearish (50-)'}`,
    data,
  };
}

function macdSig({ fast, slow, signal }, ctx) {
  const closes = ctx.candles.map((c) => c.close);
  const price = ctx.price ?? last(closes);
  const m = macd(closes, fast, slow, signal);
  const line = last(m.line), sig = last(m.signal), hist = last(m.hist);
  if (line == null || sig == null) return hold(`MACD ${fast}/${slow}/${signal} ke liye candles kam hain`);
  const histPct = (hist / price) * 100;
  const bull = line > sig;
  return {
    action: bull ? 'BUY' : 'SELL',
    confidence: +clamp(0.4 + Math.abs(histPct) * 6, 0.4, 0.9).toFixed(3),
    reason: `MACD ${line.toFixed(2)} ${bull ? '>' : '<'} signal ${sig.toFixed(2)} `
      + `(histogram ${histPct >= 0 ? '+' : ''}${histPct.toFixed(3)}% of price) - trend ${bull ? 'upar' : 'neeche'} confirm`,
    data: { macd: +line.toFixed(2), signal: +sig.toFixed(2), histPct: +histPct.toFixed(3) },
  };
}

function volumeSig({ period, spike }, ctx) {
  const cs = ctx.candles;
  const price = ctx.price ?? last(cs).close;
  const avg = last(sma(cs.map((c) => c.volume), period));
  const cur = last(cs).volume;
  if (!avg || avg <= 0) return hold(`Volume average (${period}) ke liye candles kam hain`);
  const ratio = avg > 0 ? cur / avg : 0;
  const ref = cs[Math.max(0, cs.length - 6)].close;
  const chg = pct(price, ref);
  const data = { ratio: +ratio.toFixed(2), avg: Math.round(avg), volume: cur };
  if (ratio < spike) {
    return {
      action: 'HOLD',
      confidence: +clamp(0.3 + ratio * 0.1, 0.3, 0.5).toFixed(3),
      reason: `Volume ${ratio.toFixed(2)}× average (spike ${spike}× se kam) - buying/selling activity feeeki`,
      data,
    };
  }
  const action = chg > 0 ? 'BUY' : chg < 0 ? 'SELL' : 'HOLD';
  return {
    action,
    confidence: +clamp(0.4 + (ratio - spike) * 0.25, 0.4, 0.92).toFixed(3),
    reason: `Volume ${ratio.toFixed(2)}× average (spike 🔊) + price ${chg >= 0 ? 'upar' : 'neeche'} `
      + `(${chg >= 0 ? '+' : ''}${chg.toFixed(2)}%) - ${chg >= 0 ? 'khareedari' : 'bikwasi'} activity tez`,
    data,
  };
}

function supertrendSig({ period, mult }, ctx) {
  const st = supertrend(ctx.candles, period, mult);
  const now = [...st].reverse().find((p) => p.line != null);
  const price = ctx.price ?? last(ctx.candles).close;
  if (!now) return hold(`Supertrend ${period}/${mult} ke liye candles kam hain`);
  const bull = now.dir > 0;
  const dist = Math.abs(pct(price, now.line));
  return {
    action: bull ? 'BUY' : 'SELL',
    confidence: +clamp(0.4 + dist * 0.5, 0.4, 0.9).toFixed(3),
    reason: `Supertrend ${bull ? 'BUY (line neeche, uptrend)' : 'SELL (line upar, downtrend)'} `
      + `· line ₹${now.line.toFixed(2)}, price us se ${bull ? 'upar' : 'neeche'} (${dist.toFixed(2)}%)`,
    data: { line: +now.line.toFixed(2), dir: now.dir, distPct: +dist.toFixed(2) },
  };
}

function adxSig({ period, threshold }, ctx) {
  const d = adx(ctx.candles, period);
  if (d.adx == null) return hold(`ADX ${period} ke liye candles kam hain`);
  const data = { adx: +d.adx.toFixed(1), plusDI: +(d.plusDI || 0).toFixed(1), minusDI: +(d.minusDI || 0).toFixed(1) };
  if (d.adx < threshold) {
    return {
      action: 'HOLD',
      confidence: +clamp(0.3 + (d.adx / threshold) * 0.15, 0.3, 0.45).toFixed(3),
      reason: `ADX ${d.adx.toFixed(1)} < ${threshold} - trend kamzor / sideways, strength nahi hai`,
      data,
    };
  }
  const bull = d.plusDI >= d.minusDI;
  return {
    action: bull ? 'BUY' : 'SELL',
    confidence: +clamp(0.4 + ((d.adx - threshold) / 50) * 0.8, 0.4, 0.92).toFixed(3),
    reason: `ADX ${d.adx.toFixed(1)} ≥ ${threshold} - trend strong 💪 · +DI ${data.plusDI} vs -DI ${data.minusDI} → ${bull ? 'uptrend' : 'downtrend'}`,
    data,
  };
}

function bollingerSig({ period, mult }, ctx) {
  const closes = ctx.candles.map((c) => c.close);
  const price = ctx.price ?? last(closes);
  const b = bollinger(closes, period, mult);
  const up = last(b.upper), lo = last(b.lower), mid = last(b.mid);
  if (up == null || lo == null) return hold(`Bollinger ${period} ke liye candles kam hain`);
  const widthPct = pct(up, lo);
  const bPct = up > lo ? (price - lo) / (up - lo) : 0.5;
  const data = {
    upper: +up.toFixed(2), lower: +lo.toFixed(2), mid: +mid.toFixed(2),
    bPct: +bPct.toFixed(2), widthPct: +widthPct.toFixed(2),
  };
  const range = `· band width ${widthPct.toFixed(2)}% (volatility ${widthPct < 3 ? 'kam / squeeze' : 'normal-zyada'})`;
  if (price <= lo) {
    return {
      action: 'BUY',
      confidence: +clamp(0.45 + (pct(lo, price)) * 0.3, 0.45, 0.85).toFixed(3),
      reason: `Price lower band (₹${lo.toFixed(2)}) ke paar - oversold bounce ki ummeed ${range}`,
      data,
    };
  }
  if (price >= up) {
    return {
      action: 'SELL',
      confidence: +clamp(0.45 + (pct(price, up)) * 0.3, 0.45, 0.85).toFixed(3),
      reason: `Price upper band (₹${up.toFixed(2)}) ke paar - correction ki ummeed ${range}`,
      data,
    };
  }
  const bull = bPct > 0.5;
  return {
    action: bull ? 'BUY' : 'SELL',
    confidence: +clamp(0.34 + Math.abs(bPct - 0.5) * 0.6, 0.34, 0.62).toFixed(3),
    reason: `%B = ${bPct.toFixed(2)} - price band ke ${bull ? 'upper' : 'lower'} aadhe me (range ka ${bull ? 'upar' : 'neeche'} end) ${range}`,
    data,
  };
}

function atrSig({ period, highPct }, ctx) {
  const a = last(atr(ctx.candles, period));
  const price = ctx.price ?? last(ctx.candles).close;
  if (a == null || !price) return hold(`ATR ${period} ke liye candles kam hain`);
  const atrPct = (a / price) * 100;
  const stop = +(price - 2 * a).toFixed(2);
  const data = { atr: +a.toFixed(2), atrPct: +atrPct.toFixed(2), stopLoss: stop };
  if (atrPct >= highPct) {
    return {
      action: 'HOLD',
      confidence: +clamp(0.4 + ((atrPct - highPct) / Math.max(0.1, highPct)) * 0.3, 0.4, 0.75).toFixed(3),
      reason: `ATR ${atrPct.toFixed(2)}% = volatility HIGH (${highPct}%+) - naye trade me sambhalo, `
        + `stop-loss wide rakho (≈ ₹${stop}) 🛑`,
      data,
    };
  }
  const ref = ctx.candles[Math.max(0, ctx.candles.length - 10)].close;
  const moveAtr = (price - ref) / a; // move ko ATR me naapa
  if (Math.abs(moveAtr) < 0.5) {
    return {
      action: 'HOLD',
      confidence: +clamp(0.32 + Math.abs(moveAtr) * 0.2, 0.32, 0.5).toFixed(3),
      reason: `ATR ${atrPct.toFixed(2)}% normal · 10 candle ka move sirf ${moveAtr.toFixed(2)}× ATR - koi direction nahi `
        + `(SL plan ≈ ₹${stop})`,
      data,
    };
  }
  const bull = moveAtr > 0;
  return {
    action: bull ? 'BUY' : 'SELL',
    confidence: +clamp(0.4 + (Math.abs(moveAtr) - 0.5) * 0.2, 0.4, 0.85).toFixed(3),
    reason: `ATR ${atrPct.toFixed(2)}% (volatility normal) · 10 candle ka move ${Math.abs(moveAtr).toFixed(2)}× ATR → `
      + `${bull ? 'upar' : 'neeche'} · stop-loss plan ≈ ₹${stop} (price − 2×ATR) 🛑`,
    data,
  };
}

const FUNCS = {
  ema: emaSig, vwap: vwapSig, rsi: rsiSig, macd: macdSig, volume: volumeSig,
  supertrend: supertrendSig, adx: adxSig, bollinger: bollingerSig, atr: atrSig,
};

/** Indicator agent ka final report: { action, confidence, reason, data } */
function evaluate(indicator, params, ctx) {
  const fn = FUNCS[indicator];
  if (!fn) return { action: 'HOLD', confidence: 0, reason: `Indicator "${indicator}" nahi mila`, data: {} };
  try {
    return fn(normalizeParams(indicator, params || {}), ctx);
  } catch (e) {
    return { action: 'HOLD', confidence: 0, reason: `Indicator error: ${e.message}`, data: {} };
  }
}

module.exports = { INDICATORS, evaluate, normalizeParams, describe };
