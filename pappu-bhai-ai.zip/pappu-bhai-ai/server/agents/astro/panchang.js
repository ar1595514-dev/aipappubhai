/**
 * Panchang calculator - real date/time (IST) se:
 *  vaar, hora (planetary hour), tithi, paksha, nakshatra, Chandra rashi, Rahu Kaal, numerology
 * Sun/Moon positions simplified astronomical formulas se (≈1° accuracy) - trading demo ke liye kaafi.
 * Sunrise ko simplicity ke liye 06:00 IST maana gaya hai.
 */

const WEEK_LORDS = ['Sun', 'Moon', 'Mars', 'Mercury', 'Jupiter', 'Venus', 'Saturn']; // 0 = Sunday
const VAAR = ['Ravivaar', 'Somvaar', 'Mangalvaar', 'Budhvaar', 'Guruvaar', 'Shukravaar', 'Shanivaar'];
const CHALDEAN = ['Saturn', 'Jupiter', 'Mars', 'Sun', 'Venus', 'Mercury', 'Moon'];

const PLANET_HI = {
  Sun: 'Surya ☀️', Moon: 'Chandra 🌙', Mars: 'Mangal 🔴', Mercury: 'Budh 💚',
  Jupiter: 'Guru 🟡', Venus: 'Shukra 🤍', Saturn: 'Shani 🪐', Rahu: 'Rahu 🐍', Ketu: 'Ketu ☄️',
};

const TITHI = ['Pratipada', 'Dwitiya', 'Tritiya', 'Chaturthi', 'Panchami', 'Shashthi', 'Saptami', 'Ashtami',
  'Navami', 'Dashami', 'Ekadashi', 'Dwadashi', 'Trayodashi', 'Chaturdashi'];

const NAKSHATRA = ['Ashwini', 'Bharani', 'Krittika', 'Rohini', 'Mrigashira', 'Ardra', 'Punarvasu', 'Pushya',
  'Ashlesha', 'Magha', 'Purva Phalguni', 'Uttara Phalguni', 'Hasta', 'Chitra', 'Swati', 'Vishakha', 'Anuradha',
  'Jyeshtha', 'Mula', 'Purva Ashadha', 'Uttara Ashadha', 'Shravana', 'Dhanishta', 'Shatabhisha',
  'Purva Bhadrapada', 'Uttara Bhadrapada', 'Revati'];
const NAK_LORDS = ['Ketu', 'Venus', 'Sun', 'Moon', 'Mars', 'Rahu', 'Jupiter', 'Saturn', 'Mercury'];

const RASHI = ['Mesh', 'Vrishabh', 'Mithun', 'Kark', 'Simha', 'Kanya', 'Tula', 'Vrishchik', 'Dhanu', 'Makar', 'Kumbh', 'Meen'];
const RASHI_LORDS = ['Mars', 'Venus', 'Mercury', 'Moon', 'Sun', 'Mercury', 'Venus', 'Mars', 'Jupiter', 'Saturn', 'Saturn', 'Jupiter'];

// Rahu Kaal: din (06:00-18:00) ke 8 hisse (90 min); weekday -> segment index
const RAHU_SEGMENT = [7, 1, 6, 4, 5, 3, 2];

// Naisargik maitri (natural friendship)
const FRIENDS = {
  Sun: ['Moon', 'Mars', 'Jupiter'], Moon: ['Sun', 'Mercury'], Mars: ['Sun', 'Moon', 'Jupiter'],
  Mercury: ['Sun', 'Venus'], Jupiter: ['Sun', 'Moon', 'Mars'], Venus: ['Mercury', 'Saturn'],
  Saturn: ['Mercury', 'Venus'], Rahu: ['Mercury', 'Venus', 'Saturn'], Ketu: ['Mars', 'Jupiter'],
};
const ENEMIES = {
  Sun: ['Venus', 'Saturn'], Moon: [], Mars: ['Mercury'], Mercury: ['Moon'], Jupiter: ['Mercury', 'Venus'],
  Venus: ['Sun', 'Moon'], Saturn: ['Sun', 'Moon', 'Mars'], Rahu: ['Sun', 'Moon'], Ketu: ['Moon'],
};

// Ank jyotish: number -> grah
const NUM_PLANET = { 1: 'Sun', 2: 'Moon', 3: 'Jupiter', 4: 'Rahu', 5: 'Mercury', 6: 'Venus', 7: 'Ketu', 8: 'Saturn', 9: 'Mars' };

const BENEFIC = ['Jupiter', 'Venus', 'Mercury', 'Moon'];

const norm = (deg) => ((deg % 360) + 360) % 360;
const rad = (deg) => (deg * Math.PI) / 180;

function reduceDigits(n) {
  while (n > 9) n = String(n).split('').reduce((a, d) => a + Number(d), 0);
  return n || 9;
}

function nameNumber(text) {
  const sum = String(text).toUpperCase().replace(/[^A-Z0-9]/g, '').split('')
    .reduce((a, c) => a + (/\d/.test(c) ? Number(c) : c.charCodeAt(0) - 64), 0);
  return reduceDigits(sum);
}

function relation(a, b) {
  if (a === b) return 'same';
  if (FRIENDS[a]?.includes(b)) return 'friend';
  if (ENEMIES[a]?.includes(b)) return 'enemy';
  return 'neutral';
}

function sunMoon(date) {
  const d = date.getTime() / 86400000 + 2440587.5 - 2451545.0; // days since J2000
  const g = rad(357.528 + 0.9856003 * d);
  const sun = norm(280.46 + 0.9856474 * d + 1.915 * Math.sin(g) + 0.02 * Math.sin(2 * g));
  const L = 218.316 + 13.176396 * d;
  const M = rad(134.963 + 13.064993 * d);
  const D = rad(297.85 + 12.190749 * d);
  const moon = norm(L + 6.289 * Math.sin(M) + 1.274 * Math.sin(2 * D - M) + 0.658 * Math.sin(2 * D) - 0.186 * Math.sin(g));
  const ayanamsa = 23.853 + (d / 365.25) * 0.013969; // Lahiri (approx)
  return { sun, moon, ayanamsa };
}

function fmtMin(m) {
  const h = Math.floor(m / 60) % 24, mm = m % 60;
  return `${String(h).padStart(2, '0')}:${String(mm).padStart(2, '0')}`;
}

function getPanchang(date = new Date()) {
  const ist = new Date(date.getTime() + 5.5 * 3600 * 1000);
  const minutes = ist.getUTCHours() * 60 + ist.getUTCMinutes();
  const sunrise = 6 * 60;

  // Vedic din sunrise se shuru hota hai
  let wd = ist.getUTCDay();
  if (minutes < sunrise) wd = (wd + 6) % 7;
  const dayLord = WEEK_LORDS[wd];

  const sinceSunrise = (minutes - sunrise + 1440) % 1440;
  const horaIndex = Math.floor(sinceSunrise / 60);
  const horaLord = CHALDEAN[(CHALDEAN.indexOf(dayLord) + horaIndex) % 7];
  const horaStart = sunrise + horaIndex * 60;

  const seg = RAHU_SEGMENT[wd];
  const rahuStart = sunrise + seg * 90, rahuEnd = rahuStart + 90;
  const rahuKaal = minutes >= rahuStart && minutes < rahuEnd;

  const { sun, moon, ayanamsa } = sunMoon(date);
  const elong = norm(moon - sun);
  const tithiIdx = Math.floor(elong / 12); // 0..29
  const shukla = tithiIdx < 15;
  const t = tithiIdx % 15;
  const tithiName = t === 14 ? (shukla ? 'Purnima' : 'Amavasya') : TITHI[t];

  const sidMoon = norm(moon - ayanamsa);
  const nakIdx = Math.floor(sidMoon / (360 / 27));
  const rashiIdx = Math.floor(sidMoon / 30);

  const dd = ist.getUTCDate(), mo = ist.getUTCMonth() + 1, yy = ist.getUTCFullYear();
  const mulank = reduceDigits(dd);
  const bhagyank = reduceDigits(`${dd}${mo}${yy}`.split('').reduce((a, c) => a + Number(c), 0));

  return {
    dateIST: `${String(dd).padStart(2, '0')}-${String(mo).padStart(2, '0')}-${yy}`,
    timeIST: fmtMin(minutes),
    vaar: VAAR[wd],
    dayLord,
    horaLord,
    horaWindow: `${fmtMin(horaStart)}-${fmtMin(horaStart + 60)}`,
    horaKey: `${yy}-${mo}-${dd}-${wd}-${horaIndex}`, // hora badalte hi naya pick
    tithi: `${shukla ? 'Shukla' : 'Krishna'} ${tithiName}`,
    paksha: shukla ? 'Shukla' : 'Krishna',
    nakshatra: NAKSHATRA[nakIdx],
    nakshatraLord: NAK_LORDS[nakIdx % 9],
    moonRashi: RASHI[rashiIdx],
    moonRashiLord: RASHI_LORDS[rashiIdx],
    rahuKaal,
    rahuKaalWindow: `${fmtMin(rahuStart)}-${fmtMin(rahuEnd)}`,
    mulank,
    bhagyank,
  };
}

module.exports = {
  getPanchang, relation, nameNumber, reduceDigits,
  PLANET_HI, NUM_PLANET, BENEFIC, PLANETS: Object.keys(PLANET_HI),
};
