const BaseAgent = require('../baseAgent');
const { evaluate } = require('../indicatorSignals');

/**
 * 📈 IndicatorAgent - data-driven technical agent.
 *
 * Ye class har DB row (`agents` me `indicator` + `params` wale) se banti hai:
 *   { key: 'ema20', indicator: 'ema', params: { period: 20 } }
 *
 * Signal ka poora logic `indicatorSignals.js` me hai - isliye admin panel se naya
 * agent banane par code likhne ki zarurat nahi hoti.
 */
class IndicatorAgent extends BaseAgent {
  constructor(row) {
    super(row.key);
    this.indicator = row.indicator;
    try {
      this.params = row.params ? JSON.parse(row.params) : {};
    } catch {
      this.params = {};
    }
  }

  async analyze(ctx) {
    return evaluate(this.indicator, this.params, ctx);
  }
}

module.exports = IndicatorAgent;
