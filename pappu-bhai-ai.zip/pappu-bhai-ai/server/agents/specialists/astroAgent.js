/**
 * 🔮 JYOTISH GURU - Astrologer AI Agent
 *
 * Do kaam karta hai:
 *  1. selectToken(): real-time panchang (IST) ke hisaab se watchlist ka sabse "shubh" token chunta hai.
 *     Pappu Bhai ki baaki team sirf usi token par analysis karti hai.
 *  2. analyze(): team ke saath ek vote bhi deta hai (hora, paksha, Rahu Kaal ke basis par).
 *
 * ⚠️ Jyotish belief/entertainment par based hai, iska koi scientific market edge nahi hai.
 */
const crypto = require('crypto');
const BaseAgent = require('../baseAgent');
const { clamp } = require('../indicators');
const { getPanchang, relation, nameNumber, PLANET_HI, NUM_PLANET, BENEFIC } = require('../astro/panchang');

const hi = (p) => PLANET_HI[p] || p;

class AstroAgent extends BaseAgent {
  constructor() { super('astro'); }

  /** Symbol ka grah: DB me set ho to wahi, warna naam ke ank se */
  planetOf(sym) {
    return sym.planet || NUM_PLANET[nameNumber(sym.symbol)];
  }

  scoreSymbol(sym, p) {
    const planet = this.planetOf(sym);
    const num = nameNumber(sym.symbol);
    let score = 0;
    const why = [];

    if (planet === p.horaLord) { score += 3; why.push(`${hi(planet)} ki hora chal rahi hai`); }
    else {
      const r = relation(p.horaLord, planet);
      if (r === 'friend') { score += 1; why.push(`hora swami ${hi(p.horaLord)} se maitri`); }
      if (r === 'enemy') { score -= 1; why.push(`hora swami ${hi(p.horaLord)} se shatruta`); }
    }
    if (planet === p.dayLord) { score += 2; why.push(`${p.vaar} ka swami ${hi(planet)}`); }
    if (planet === p.nakshatraLord) { score += 1.5; why.push(`${p.nakshatra} nakshatra ka swami`); }
    else if (relation(p.nakshatraLord, planet) === 'friend') { score += 0.5; why.push(`nakshatra swami se mitrata`); }
    if (planet === p.moonRashiLord) { score += 1; why.push(`Chandra ${p.moonRashi} rashi me (swami same)`); }
    if (num === p.bhagyank) { score += 1.5; why.push(`ank ${num} = aaj ka bhagyank`); }
    else if (num === p.mulank) { score += 1; why.push(`ank ${num} = aaj ka mulank`); }

    // barabar score par deterministic tie-break (har din alag)
    const h = crypto.createHash('md5').update(sym.symbol + p.dateIST + p.horaKey).digest()[0] / 255;
    score += h * 0.05;

    return { symbol: sym.symbol, name: sym.name, planet, planetHi: hi(planet), number: num, score: +score.toFixed(2), why };
  }

  selectToken(symbols, date = new Date()) {
    const p = getPanchang(date);
    const ranking = symbols.map((s) => this.scoreSymbol(s, p)).sort((a, b) => b.score - a.score);
    const top = ranking[0];
    if (!top) return null;
    return {
      symbol: top.symbol,
      planet: top.planet,
      planetHi: top.planetHi,
      score: top.score,
      reason: top.why.length ? top.why.join(', ') : 'Sabse kam dosh wala token',
      message: `🔮 Jyotish Guru: "${p.vaar}, ${hi(p.horaLord)} ki hora, ${p.tithi}, ${p.nakshatra} nakshatra - aaj ${top.symbol} (${top.planetHi}) sabse shubh hai."`
        + (p.rahuKaal ? ' ⚠️ Abhi Rahu Kaal hai, naye trade me savdhaani.' : ''),
      panchang: p,
      ranking,
      time: Date.now(),
    };
  }

  /** Team ke saath vote */
  async analyze({ symbol, astro }) {
    const p = getPanchang();
    if (p.rahuKaal) {
      return {
        action: 'HOLD', confidence: 0.6,
        reason: `Rahu Kaal (${p.rahuKaalWindow}) chal raha hai - naya sauda mat karo 🐍`,
        data: { rahuKaal: true },
      };
    }
    let score = 0;
    const notes = [];
    if (BENEFIC.includes(p.horaLord)) { score += 0.3; notes.push(`${hi(p.horaLord)} hora shubh`); }
    else { score -= 0.2; notes.push(`${hi(p.horaLord)} hora kroor`); }
    if (p.paksha === 'Shukla') { score += 0.2; notes.push('Shukla paksha (badhta Chandra)'); }
    else { score -= 0.15; notes.push('Krishna paksha (ghatta Chandra)'); }
    if (astro?.symbol === symbol) { score += 0.2; notes.push('aaj ka chuna hua token ✨'); }

    const action = score > 0.25 ? 'BUY' : score < -0.25 ? 'SELL' : 'HOLD';
    return {
      action,
      confidence: clamp(Math.abs(score)),
      reason: `${notes.join(', ')} · ${p.nakshatra} nakshatra`,
      data: { horaLord: p.horaLord, paksha: p.paksha, nakshatra: p.nakshatra },
    };
  }
}

module.exports = AstroAgent;
