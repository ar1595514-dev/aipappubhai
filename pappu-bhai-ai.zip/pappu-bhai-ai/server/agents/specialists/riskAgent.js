const BaseAgent = require('../baseAgent');
const { atr, last } = require('../indicators');

/**
 * Risk Rakshak voting me hissa nahi leta (weight 0), lekin:
 *  - ATR based stop-loss / target suggest karta hai
 *  - Bahut zyada volatility ya max positions par VETO laga sakta hai
 */
class RiskAgent extends BaseAgent {
  constructor() { super('risk'); }

  async analyze({ candles, price, openPositions, maxPositions, hasPosition }) {
    const a = last(atr(candles, 14));
    const volPct = (a / price) * 100;
    const notes = [`ATR ${a.toFixed(2)} (${volPct.toFixed(2)}%)`];
    let veto = false;

    if (volPct > 1.5) { veto = true; notes.push('Volatility bahut high - naya trade risky'); }
    if (!hasPosition && openPositions >= maxPositions) {
      veto = true; notes.push(`Max ${maxPositions} positions already open`);
    }
    if (!veto) notes.push('Risk acceptable ✅');

    return {
      action: 'HOLD',
      confidence: veto ? 1 : 0.5,
      reason: notes.join(', '),
      veto,
      data: {
        atr: +a.toFixed(2),
        stopDistance: +(a * 1.5).toFixed(2),
        targetDistance: +(a * 3).toFixed(2),
        veto,
      },
    };
  }
}

module.exports = RiskAgent;
