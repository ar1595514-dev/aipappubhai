/**
 * BaseAgent - har specialist agent isse extend karta hai.
 * analyze(ctx) ko return karna hai: { action: 'BUY'|'SELL'|'HOLD', confidence: 0..1, reason, data? }
 */
class BaseAgent {
  constructor(key) {
    this.key = key;
  }

  // Real system me yahan LLM / external API call ho sakti hai. Demo me thoda delay
  // daalte hain taaki parallel analysis UI me live dikhe.
  async think() {
    const ms = 150 + Math.random() * 900;
    return new Promise((r) => setTimeout(r, ms));
  }

  async run(ctx) {
    const started = Date.now();
    await this.think();
    const result = await this.analyze(ctx);
    return { ...result, tookMs: Date.now() - started };
  }

  // eslint-disable-next-line no-unused-vars
  async analyze(ctx) {
    throw new Error('analyze() implement karein');
  }
}

module.exports = BaseAgent;
