/**
 * 🧠 PAPPU BHAI AI - Main (Orchestrator) Agent
 *
 * Flow:
 *  1. Naya candle close hota hai
 *  2. Pappu Bhai saare enabled agents ko EK SAATH (parallel) kaam deta hai
 *     - Technical agents DB se aate hain (indicator + params) - admin panel se add hote hain
 *     - Risk Rakshak + Jyotish Guru system agents hain
 *  3. Har agent apni report jaise hi ready ho, Pappu Bhai ko bhejta hai (live UI update)
 *  4. Pappu Bhai weighted voting + Risk Rakshak ke veto se final decision leta hai
 *  5. Decision TradingEngine ko jata hai (agar auto-trading ON hai to order lagta hai)
 *
 * 🔮 Astro mode: Jyotish Guru real-time panchang se ek token chunta hai (refreshAstro).
 *    Team sirf usi token (aur jin tokens me position open hai) par analysis karti hai.
 */
const EventEmitter = require('events');
const crypto = require('crypto');
const { db, settings, log } = require('../db/database');

const IndicatorAgent = require('./specialists/indicatorAgent');
const RiskAgent = require('./specialists/riskAgent');
const AstroAgent = require('./specialists/astroAgent');

const DIR = { BUY: 1, SELL: -1, HOLD: 0 };

class PappuBhaiAI extends EventEmitter {
  constructor(feed, engine) {
    super();
    this.feed = feed;
    this.engine = engine;
    this.astro = new AstroAgent();
    this.focus = null; // Jyotish Guru ka current pick
    // System agents (code me likhe gaye hain). Baaki technical agents DB `agents`
    // table se bante hain (indicator + params) - admin panel se add/edit kiye jate hain.
    this.specials = [new RiskAgent(), this.astro];
    this.busy = new Set();
    this.insertPick = db.prepare(
      `INSERT INTO astro_picks (symbol, planet, score, vaar, hora_lord, tithi, nakshatra, rahu_kaal, reason, created_at)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`
    );
    this.insertSignal = db.prepare(
      `INSERT INTO signals (analysis_id, symbol, agent_key, action, confidence, reason, created_at)
       VALUES (?, ?, ?, ?, ?, ?, ?)`
    );
    this.insertDecision = db.prepare(
      `INSERT INTO decisions (analysis_id, symbol, action, score, confidence, price, summary, created_at)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?)`
    );
  }

  agentConfig() {
    const rows = db.prepare('SELECT * FROM agents').all();
    return Object.fromEntries(rows.map((r) => [r.key, r]));
  }

  astroEnabled() {
    return settings.bool('astro_mode') && !!this.agentConfig().astro?.enabled;
  }

  /**
   * 🔮 Jyotish Guru se token chunwao. Naya token (ya hora/Rahu Kaal badla) ho to DB me save + event.
   * force = true -> hamesha event bhejo
   */
  refreshAstro(force = false) {
    const symbols = db.prepare('SELECT symbol, name, planet FROM symbols WHERE active = 1').all()
      .filter((s) => this.feed.getPrice(s.symbol) != null);
    const pick = this.astro.selectToken(symbols);
    if (!pick) return null;
    pick.enabled = this.astroEnabled(); // astro mode ON/OFF (UI ke liye)

    const prev = this.focus;
    const changed = !prev || prev.symbol !== pick.symbol || prev.panchang.horaKey !== pick.panchang.horaKey
      || prev.panchang.rahuKaal !== pick.panchang.rahuKaal;
    this.focus = pick;

    if (changed) {
      const p = pick.panchang;
      this.insertPick.run(pick.symbol, pick.planet, pick.score, p.vaar, p.horaLord, p.tithi, p.nakshatra, p.rahuKaal ? 1 : 0, pick.reason, pick.time);
      if (!prev || prev.symbol !== pick.symbol) log('astro', `Jyotish Guru ne chuna: ${pick.symbol} (${pick.planet}) - ${pick.reason}`);
    }
    if (changed || force) this.emit('astroPick', pick);
    return pick;
  }

  /** Astro mode me kaun se symbols analyse honge */
  shouldAnalyze(symbol) {
    if (!this.astroEnabled()) return true;
    if (!this.focus) this.refreshAstro();
    return this.focus?.symbol === symbol || !!this.engine.getPosition(symbol);
  }

  async analyze(symbol) {
    if (this.busy.has(symbol)) return null; // ek symbol par ek time ek hi analysis
    const all = this.feed.getClosedCandles(symbol);
    if (all.length < 60) return null;
    const candles = all.slice(-600); // indicators ke liye 600 candle kaafi hain - analysis fast rahe
    this.busy.add(symbol);

    try {
      const cfg = this.agentConfig();
      const analysisId = crypto.randomUUID();
      const price = this.feed.getPrice(symbol);
      const position = this.engine.getPosition(symbol);
      const ctx = {
        symbol,
        candles,
        price,
        hasPosition: !!position,
        position,
        openPositions: this.engine.openCount(),
        maxPositions: settings.num('max_open_positions'),
        astro: this.focus,
      };

      // Team: DB ki saari enabled indicator-agents + system agents (Risk, Jyotish)
      const active = [
        ...Object.values(cfg).filter((row) => row.enabled && row.indicator).map((row) => new IndicatorAgent(row)),
        ...this.specials.filter((a) => cfg[a.key]?.enabled),
      ];
      this.emit('analysisStart', { analysisId, symbol, agents: active.map((a) => a.key), time: Date.now() });

      // ⚡ Saare agents PARALLEL me chalte hain
      const results = await Promise.all(
        active.map((agent) =>
          agent
            .run(ctx)
            .catch((e) => ({ action: 'HOLD', confidence: 0, reason: `Error: ${e.message}` }))
            .then((r) => {
              const signal = {
                analysisId,
                symbol,
                agent: agent.key,
                name: cfg[agent.key].name,
                icon: cfg[agent.key].icon,
                weight: cfg[agent.key].weight,
                action: r.action,
                confidence: +r.confidence.toFixed(3),
                reason: r.reason,
                data: r.data || {},
                veto: !!r.veto,
                tookMs: r.tookMs,
                time: Date.now(),
              };
              this.insertSignal.run(analysisId, symbol, agent.key, signal.action, signal.confidence, signal.reason, signal.time);
              this.emit('agentSignal', signal); // agent -> Pappu Bhai report
              return signal;
            })
        )
      );

      const decision = this.decide({ analysisId, symbol, price, results, position });
      const info = this.insertDecision.run(
        analysisId, symbol, decision.action, decision.score, decision.confidence, price, decision.summary, decision.time
      );
      decision.id = Number(info.lastInsertRowid);
      this.emit('decision', decision);

      await this.engine.onDecision(decision);
      return decision;
    } catch (e) {
      log('error', `Pappu Bhai analysis fail (${symbol}): ${e.message}`);
      return null;
    } finally {
      this.busy.delete(symbol);
    }
  }

  decide({ analysisId, symbol, price, results, position }) {
    const threshold = settings.num('decision_threshold');
    let weighted = 0, totalWeight = 0;
    const votes = { BUY: 0, SELL: 0, HOLD: 0 };

    for (const r of results) {
      if (r.agent === 'risk') continue;
      votes[r.action]++;
      weighted += r.weight * DIR[r.action] * r.confidence;
      totalWeight += r.weight;
    }
    const score = totalWeight ? weighted / totalWeight : 0; // -1 .. +1
    const risk = results.find((r) => r.agent === 'risk');

    let action = score >= threshold ? 'BUY' : score <= -threshold ? 'SELL' : 'HOLD';
    let vetoed = false;
    const opensNew = action !== 'HOLD' && !position; // naya trade khulne wala hai
    if (risk?.veto && opensNew) { vetoed = true; action = 'HOLD'; }

    const confidence = Math.min(1, Math.abs(score) / Math.max(threshold * 2, 0.01));
    const lines = {
      BUY: `Bhai, ${symbol} me dum hai! 🚀 Team ka majority bullish hai, khareed lo.`,
      SELL: `${symbol} me kamzori dikh rahi hai 📉 Nikalne ka time hai ya short karo.`,
      HOLD: `${symbol} abhi confuse kar raha hai 🤔 Thoda ruko, jaldi mat karo.`,
    };
    let summary = `${lines[action]} (Score ${score.toFixed(2)}, BUY ${votes.BUY} / SELL ${votes.SELL} / HOLD ${votes.HOLD})`;
    if (vetoed) summary = `Signal tha lekin Risk Rakshak ne VETO laga diya 🛡️ - ${risk.reason}`;
    const astroPick = this.focus?.symbol === symbol;
    if (astroPick) summary = `🔮 Jyotish Guru ka chuna token · ${summary}`;

    return {
      analysisId,
      symbol,
      action,
      score: +score.toFixed(3),
      confidence: +confidence.toFixed(3),
      price,
      votes,
      vetoed,
      astroPick,
      risk: risk?.data || null,
      summary,
      signals: results,
      time: Date.now(),
    };
  }
}

module.exports = PappuBhaiAI;
