// Technical indicators - pure functions (arrays of numbers / candles)

function sma(values, period) {
  const out = new Array(values.length).fill(null);
  let sum = 0;
  for (let i = 0; i < values.length; i++) {
    sum += values[i];
    if (i >= period) sum -= values[i - period];
    if (i >= period - 1) out[i] = sum / period;
  }
  return out;
}

function ema(values, period) {
  const out = new Array(values.length).fill(null);
  if (values.length < period) return out;
  const k = 2 / (period + 1);
  let prev = values.slice(0, period).reduce((a, b) => a + b, 0) / period;
  out[period - 1] = prev;
  for (let i = period; i < values.length; i++) {
    prev = values[i] * k + prev * (1 - k);
    out[i] = prev;
  }
  return out;
}

function rsi(values, period = 14) {
  const out = new Array(values.length).fill(null);
  if (values.length <= period) return out;
  let gain = 0, loss = 0;
  for (let i = 1; i <= period; i++) {
    const d = values[i] - values[i - 1];
    if (d >= 0) gain += d; else loss -= d;
  }
  gain /= period; loss /= period;
  out[period] = loss === 0 ? 100 : 100 - 100 / (1 + gain / loss);
  for (let i = period + 1; i < values.length; i++) {
    const d = values[i] - values[i - 1];
    gain = (gain * (period - 1) + Math.max(d, 0)) / period;
    loss = (loss * (period - 1) + Math.max(-d, 0)) / period;
    out[i] = loss === 0 ? 100 : 100 - 100 / (1 + gain / loss);
  }
  return out;
}

function macd(values, fast = 12, slow = 26, signal = 9) {
  const ef = ema(values, fast);
  const es = ema(values, slow);
  const line = values.map((_, i) => (ef[i] != null && es[i] != null ? ef[i] - es[i] : null));
  const valid = line.filter((v) => v != null);
  const sig = ema(valid, signal);
  const offset = line.length - valid.length;
  const signalLine = line.map((_, i) => (i >= offset ? sig[i - offset] : null));
  const hist = line.map((v, i) => (v != null && signalLine[i] != null ? v - signalLine[i] : null));
  return { line, signal: signalLine, hist };
}

function atr(candles, period = 14) {
  const tr = candles.map((c, i) => {
    if (i === 0) return c.high - c.low;
    const pc = candles[i - 1].close;
    return Math.max(c.high - c.low, Math.abs(c.high - pc), Math.abs(c.low - pc));
  });
  return ema(tr, period);
}

function bollinger(values, period = 20, mult = 2) {
  const mid = sma(values, period);
  const upper = [], lower = [];
  for (let i = 0; i < values.length; i++) {
    if (mid[i] == null) { upper.push(null); lower.push(null); continue; }
    const slice = values.slice(i - period + 1, i + 1);
    const sd = Math.sqrt(slice.reduce((a, v) => a + (v - mid[i]) ** 2, 0) / period);
    upper.push(mid[i] + mult * sd);
    lower.push(mid[i] - mult * sd);
  }
  return { mid, upper, lower };
}

/**
 * VWAP - Volume Weighted Average Price (din ka average price).
 * Typical price (H+L+C)/3 ko volume se weight karke cumulative average.
 * Price VWAP ke upar = buyers ka pressure, neeche = sellers ka.
 */
function vwap(candles) {
  const out = new Array(candles.length).fill(null);
  let pv = 0, vol = 0;
  for (let i = 0; i < candles.length; i++) {
    const tp = (candles[i].high + candles[i].low + candles[i].close) / 3;
    pv += tp * candles[i].volume;
    vol += candles[i].volume;
    out[i] = vol > 0 ? pv / vol : tp;
  }
  return out;
}

/**
 * Supertrend - ATR based trend line. dir = 1 (uptrend, line neeche) / -1 (downtrend, line upar).
 * Returns: [{ line, dir }] - line null jab tak ATR ready na ho.
 */
function supertrend(candles, period = 10, mult = 3) {
  const a = atr(candles, period);
  const out = [];
  let prevUpper = null, prevLower = null, prevClose = null, dir = 1;
  for (let i = 0; i < candles.length; i++) {
    const c = candles[i];
    if (a[i] == null) { out.push({ line: null, dir }); prevClose = c.close; continue; }
    const mid = (c.high + c.low) / 2;
    const rawUpper = mid + mult * a[i];
    const rawLower = mid - mult * a[i];
    const upper = prevUpper == null || rawUpper < prevUpper || prevClose > prevUpper ? rawUpper : prevUpper;
    const lower = prevLower == null || rawLower > prevLower || prevClose < prevLower ? rawLower : prevLower;
    if (prevUpper == null || prevLower == null) dir = c.close >= mid ? 1 : -1; // pehla valid bar
    else if (dir === 1) dir = c.close < lower ? -1 : 1;
    else dir = c.close > upper ? 1 : -1;
    out.push({ line: dir === 1 ? lower : upper, dir });
    prevUpper = upper; prevLower = lower; prevClose = c.close;
  }
  return out;
}

/**
 * ADX - trend ki strength (Wilder smoothing).
 * Returns: { adx, plusDI, minusDI } - ADX >= 25 aam taur par strong trend mana jata hai.
 */
function adx(candles, period = 14) {
  const none = { adx: null, plusDI: null, minusDI: null };
  const n = candles.length;
  if (n < period * 2 + 1) return none;
  const plusDM = [], minusDM = [], tr = [];
  for (let i = 1; i < n; i++) {
    const c = candles[i], p = candles[i - 1];
    const up = c.high - p.high, down = p.low - c.low;
    plusDM.push(up > down && up > 0 ? up : 0);
    minusDM.push(down > up && down > 0 ? down : 0);
    tr.push(Math.max(c.high - c.low, Math.abs(c.high - p.close), Math.abs(c.low - p.close)));
  }
  const wilder = (arr) => { // Wilder ka smoothing (RMA)
    const o = [];
    let sum = 0;
    for (let i = 0; i < arr.length; i++) {
      if (i < period) { sum += arr[i]; o.push(i === period - 1 ? sum : null); }
      else { sum = sum - sum / period + arr[i]; o.push(sum); }
    }
    return o;
  };
  const sTR = wilder(tr), sP = wilder(plusDM), sM = wilder(minusDM);
  const dx = [];
  let plusDI = null, minusDI = null;
  for (let i = 0; i < tr.length; i++) {
    if (sTR[i] == null || sTR[i] <= 0) { dx.push(null); continue; }
    plusDI = (100 * sP[i]) / sTR[i];
    minusDI = (100 * sM[i]) / sTR[i];
    const sum = plusDI + minusDI;
    dx.push(sum > 0 ? (100 * Math.abs(plusDI - minusDI)) / sum : 0);
  }
  const clean = dx.filter((v) => v != null);
  if (clean.length < period) return { adx: null, plusDI, minusDI };
  let val = clean.slice(0, period).reduce((a, b) => a + b, 0) / period;
  for (let i = period; i < clean.length; i++) val = (val * (period - 1) + clean[i]) / period;
  return { adx: val, plusDI, minusDI };
}

function obv(candles) {
  const out = [0];
  for (let i = 1; i < candles.length; i++) {
    const d = candles[i].close - candles[i - 1].close;
    out.push(out[i - 1] + (d > 0 ? candles[i].volume : d < 0 ? -candles[i].volume : 0));
  }
  return out;
}

const last = (arr) => arr[arr.length - 1];
const clamp = (v, min = 0, max = 1) => Math.max(min, Math.min(max, v));

module.exports = { sma, ema, rsi, macd, atr, bollinger, obv, vwap, supertrend, adx, last, clamp };
