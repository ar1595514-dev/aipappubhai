const express = require('express');
const { db, settings, log } = require('../db/database');
const { hashPassword, verifyPassword, signToken, encrypt } = require('../utils/security');
const { requireAuth, requireAdmin } = require('../middleware/auth');
const brokers = require('../trading/brokers');
const apiKeys = require('../integrations/apiKeys');
const indSignals = require('../agents/indicatorSignals');
const config = require('../config');
const wallet = require('../trading/wallet');

const SETTING_KEYS = [
  'auto_trading', 'allow_short', 'initial_capital', 'position_size_pct',
  'max_open_positions', 'decision_threshold', 'stop_loss_pct', 'target_pct', 'market_name',
  'astro_mode', 'astro_refresh_sec', 'allow_live_ai', 'live_max_order_value',
];
const PLANETS = ['Sun', 'Moon', 'Mars', 'Mercury', 'Jupiter', 'Venus', 'Saturn', 'Rahu', 'Ketu'];

// async errors ko pakadne ke liye
const wrap = (fn) => (req, res, next) => Promise.resolve(fn(req, res, next)).catch(next);

// Agent weight 0..3 ke beech (galat value par purani/hi default)
const agentWeight = (v, def) => {
  const n = Number(v);
  return Number.isFinite(n) ? Math.min(3, Math.max(0, n)) : def;
};

module.exports = function apiRouter({ feed, engine, pappu, io }) {
  const r = express.Router();

  // ---------- Auth ----------
  r.post('/auth/login', (req, res) => {
    const { email, password } = req.body || {};
    const user = db.prepare('SELECT * FROM users WHERE email = ?').get(String(email || '').toLowerCase().trim());
    if (!user || !verifyPassword(String(password || ''), user.password_hash)) {
      return res.status(401).json({ error: 'Email ya password galat hai' });
    }
    const payload = { id: user.id, name: user.name, email: user.email, role: user.role };
    log('info', `Login: ${user.email}`);
    res.json({ token: signToken(payload), user: payload });
  });

  r.use(requireAuth);

  r.get('/me', (req, res) => res.json(req.user));

  // ---------- Market ----------
  r.get('/symbols', (req, res) => {
    const rows = db.prepare('SELECT * FROM symbols ORDER BY id').all();
    res.json(rows.map((s) => ({ ...s, quote: feed.quote(s.symbol) })));
  });

  // ?limit= kitni purani candle history chahiye (dashboard time frame aggregation ke liye maangta hai)
  r.get('/candles/:symbol', (req, res) => {
    const limit = Math.min(Number(req.query.limit) || config.historyCandles, 6000);
    res.json(feed.getCandles(req.params.symbol, limit));
  });

  // ---------- AI ----------
  // Technical agents pehle, system agents (risk/astro) aakhir me
  r.get('/agents', (req, res) => {
    res.json(db.prepare(
      'SELECT * FROM agents ORDER BY (indicator IS NOT NULL) DESC, rowid'
    ).all());
  });

  r.get('/decisions', (req, res) => {
    const limit = Math.min(Number(req.query.limit) || 30, 200);
    const sym = req.query.symbol;
    const rows = sym
      ? db.prepare('SELECT * FROM decisions WHERE symbol = ? ORDER BY id DESC LIMIT ?').all(sym, limit)
      : db.prepare('SELECT * FROM decisions ORDER BY id DESC LIMIT ?').all(limit);
    res.json(rows);
  });

  r.get('/signals/latest/:symbol', (req, res) => {
    const d = db.prepare('SELECT * FROM decisions WHERE symbol = ? ORDER BY id DESC LIMIT 1').get(req.params.symbol);
    if (!d) return res.json({ decision: null, signals: [] });
    const signals = db.prepare('SELECT * FROM signals WHERE analysis_id = ?').all(d.analysis_id);
    res.json({ decision: d, signals });
  });

  // ---------- 🔮 Jyotish Guru ----------
  r.get('/astro', (req, res) => {
    const pick = pappu.focus || pappu.refreshAstro();
    res.json({
      enabled: pappu.astroEnabled(),
      pick,
      history: db.prepare('SELECT * FROM astro_picks ORDER BY id DESC LIMIT 30').all(),
    });
  });

  r.post('/astro/refresh', (req, res) => res.json(pappu.refreshAstro(true)));

  r.post('/analyze/:symbol', wrap(async (req, res) => {
    const d = await pappu.analyze(req.params.symbol);
    res.json(d || { message: 'Analysis already chal raha hai' });
  }));

  // ---------- Trading ----------
  r.get('/stats', (req, res) => res.json(engine.stats()));

  // ================= 💰 WALLET (paisa add / withdrawal) =================
  r.get('/wallet', (req, res) => res.json({ ...engine.stats(), tx: wallet.list(25) }));

  r.post('/wallet/:type', (req, res) => {
    const type = req.params.type === 'deposit' ? 'DEPOSIT'
      : req.params.type === 'withdraw' ? 'WITHDRAW' : null;
    if (!type) return res.status(400).json({ error: 'Type galat hai (deposit / withdraw)' });
    try {
      wallet.add({ type, amount: req.body?.amount, note: req.body?.note, user: req.user.email });
    } catch (e) {
      return res.status(400).json({ error: e.message });
    }
    const stats = engine.stats();
    io.emit('stats', stats);          // dashboard par equity/wallet turant update
    res.json({ ...stats, tx: wallet.list(25) });
  });
  r.get('/positions', (req, res) => res.json(engine.openPositions()));
  r.get('/trades', (req, res) => {
    const limit = Math.min(Number(req.query.limit) || 50, 500);
    res.json(db.prepare('SELECT * FROM trades ORDER BY id DESC LIMIT ?').all(limit));
  });

  r.post('/trade/manual', wrap(async (req, res) => {
    const { symbol, side, qty } = req.body || {};
    const price = feed.getPrice(symbol);
    if (!price) return res.status(400).json({ error: 'Symbol nahi mila' });
    if (!['LONG', 'SHORT'].includes(side)) return res.status(400).json({ error: 'side LONG/SHORT hona chahiye' });
    const trade = await engine.open({ symbol, side, price, source: 'MANUAL', qty: Number(qty) || null });
    res.json(trade);
  }));

  r.post('/trade/close/:symbol', wrap(async (req, res) => {
    const price = feed.getPrice(req.params.symbol);
    const t = await engine.close(req.params.symbol, price, `Manual close by ${req.user.name}`);
    if (!t) return res.status(404).json({ error: 'Open position nahi hai' });
    res.json(t);
  }));

  r.post('/bot/toggle', requireAdmin, (req, res) => {
    // explicit value bhejna zaroori hai (idempotent) - galti se flip na ho
    if (typeof req.body?.enabled !== 'boolean') return res.status(400).json({ error: 'enabled: true/false bhejein' });
    const next = req.body.enabled;
    settings.set('auto_trading', next);
    log('info', `Auto trading ${next ? 'ON' : 'OFF'} by ${req.user.email}`);
    io.emit('bot', { autoTrading: next });
    res.json({ autoTrading: next });
  });

  // ================= ADMIN =================
  const admin = express.Router();
  admin.use(requireAdmin);

  admin.get('/settings', (req, res) => res.json(settings.all()));
  admin.put('/settings', (req, res) => {
    for (const k of SETTING_KEYS) {
      const v = req.body[k];
      if (v === undefined || String(v).trim() === '') continue; // khali value se purani setting mat mitao
      if (k === 'live_max_order_value' && !(Number(v) > 0)) {
        return res.status(400).json({ error: 'LIVE max order value 0 se zyada honi chahiye (safety)' });
      }
      settings.set(k, v);
    }
    log('info', `Settings update by ${req.user.email}`);
    pappu.refreshAstro(true);
    io.emit('bot', { autoTrading: settings.bool('auto_trading') });
    res.json(settings.all());
  });

  // 📈 Indicator schema - admin form ko pata chalta hai kaun se params maangne hain
  admin.get('/agent-indicators', (req, res) => res.json(indSignals.INDICATORS));

  // Naya custom technical agent (admin panel → Agents se)
  admin.post('/agents', (req, res) => {
    const b = req.body || {};
    const meta = indSignals.INDICATORS[b.indicator];
    if (!meta) return res.status(400).json({ error: 'Indicator chunein (EMA, RSI, MACD ...)' });
    const name = String(b.name || '').trim().slice(0, 40);
    if (!name) return res.status(400).json({ error: 'Agent ka naam daalein' });
    let params;
    try {
      params = indSignals.normalizeParams(b.indicator, b.params);
    } catch (e) {
      return res.status(400).json({ error: e.message });
    }
    const icon = String(b.icon || '').trim().slice(0, 4) || meta.emoji;
    const weight = agentWeight(b.weight, 1);
    let key = '';
    for (let i = 0; i < 5 && !key; i++) {
      const cand = `c${Date.now().toString(36)}${Math.floor(Math.random() * 900 + 100)}`;
      if (!db.prepare('SELECT key FROM agents WHERE key = ?').get(cand)) key = cand;
    }
    db.prepare(
      `INSERT INTO agents (key, name, icon, description, weight, enabled, indicator, params, custom)
       VALUES (?, ?, ?, ?, ?, 1, ?, ?, 1)`
    ).run(key, name, icon, indSignals.describe(b.indicator, params), weight, b.indicator, JSON.stringify(params));
    log('info', `Custom agent add: ${name} (${b.indicator}) by ${req.user.email}`);
    res.status(201).json(db.prepare('SELECT * FROM agents WHERE key = ?').get(key));
  });

  // Agent delete (Risk / Jyotish Guru system agents hain - inhe nahi hata sakte)
  admin.delete('/agents/:key', (req, res) => {
    const a = db.prepare('SELECT * FROM agents WHERE key = ?').get(req.params.key);
    if (!a) return res.status(404).json({ error: 'Agent nahi mila' });
    if (a.key === 'risk' || a.key === 'astro') {
      return res.status(400).json({ error: 'Risk Rakshak aur Jyotish Guru system agents hain - inhe delete nahi kar sakte (sirf OFF kar sakte hain)' });
    }
    db.prepare('DELETE FROM agents WHERE key = ?').run(a.key);
    log('info', `Agent delete: ${a.name} (${a.key}) by ${req.user.email}`);
    res.json({ ok: true, key: a.key });
  });

  admin.put('/agents/:key', (req, res) => {
    const a = db.prepare('SELECT * FROM agents WHERE key = ?').get(req.params.key);
    if (!a) return res.status(404).json({ error: 'Agent nahi mila' });
    const b = req.body || {};
    const weight = b.weight !== undefined ? agentWeight(b.weight, a.weight) : a.weight;
    const enabled = b.enabled !== undefined ? (b.enabled ? 1 : 0) : a.enabled;
    let name = a.name, icon = a.icon, indicator = a.indicator, params = a.params, description = a.description;
    if (a.indicator) {
      // Technical agent - naam/icon/indicator/params edit ho sakte hain
      if (b.indicator !== undefined && b.indicator !== a.indicator) {
        if (!indSignals.INDICATORS[b.indicator]) return res.status(400).json({ error: 'Indicator chunein' });
        indicator = b.indicator;
      }
      if (b.params !== undefined) {
        try {
          params = JSON.stringify(indSignals.normalizeParams(indicator, b.params));
        } catch (e) {
          return res.status(400).json({ error: e.message });
        }
      }
      if (String(b.name || '').trim()) name = String(b.name).trim().slice(0, 40);
      if (String(b.icon || '').trim()) icon = String(b.icon).trim().slice(0, 4);
      description = indSignals.describe(indicator, JSON.parse(params || '{}'));
    }
    db.prepare(
      'UPDATE agents SET weight = ?, enabled = ?, name = ?, icon = ?, indicator = ?, params = ?, description = ? WHERE key = ?'
    ).run(weight, enabled, name, icon, indicator, params, description, a.key);
    log('info', `Agent ${a.key} updated: weight=${weight}, enabled=${enabled}`);
    if (a.key === 'astro') pappu.refreshAstro(true);
    res.json(db.prepare('SELECT * FROM agents WHERE key = ?').get(a.key));
  });

  admin.post('/symbols', (req, res) => {
    const { symbol, name, exchange = 'NSE', base_price, planet, broker_token } = req.body || {};
    const sym = String(symbol || '').toUpperCase().trim();
    if (!sym || !name || !(Number(base_price) > 0)) return res.status(400).json({ error: 'symbol, name, base_price zaroori' });
    if (!/^[A-Z0-9&_-]{1,20}$/.test(sym)) return res.status(400).json({ error: 'Token naam me sirf A-Z, 0-9, & _ - (max 20)' });
    const pl = PLANETS.includes(planet) ? planet : null; // khali = naam ke ank se auto
    try {
      db.prepare('INSERT INTO symbols (symbol, name, exchange, base_price, planet, broker_token) VALUES (?, ?, ?, ?, ?, ?)')
        .run(sym, name, exchange, Number(base_price), pl, String(broker_token || '').trim() || null);
    } catch {
      return res.status(409).json({ error: 'Symbol already hai' });
    }
    feed.addSymbol(sym, Number(base_price));
    pappu.refreshAstro(true);
    log('info', `Symbol add: ${sym}`);
    io.emit('symbols');
    res.json({ ok: true });
  });

  admin.delete('/symbols/:symbol', wrap(async (req, res) => {
    const sym = req.params.symbol;
    await engine.close(sym, feed.getPrice(sym), 'Symbol removed');
    db.prepare('DELETE FROM symbols WHERE symbol = ?').run(sym);
    feed.removeSymbol(sym);
    log('info', `Symbol remove: ${sym}`);
    pappu.refreshAstro(true);
    io.emit('symbols');
    res.json({ ok: true });
  }));

  // Symbol ka grah / broker token edit
  admin.put('/symbols/:symbol', (req, res) => {
    const s = db.prepare('SELECT * FROM symbols WHERE symbol = ?').get(req.params.symbol);
    if (!s) return res.status(404).json({ error: 'Symbol nahi mila' });
    const planet = req.body.planet !== undefined ? (PLANETS.includes(req.body.planet) ? req.body.planet : null) : s.planet;
    const token = req.body.broker_token !== undefined ? (String(req.body.broker_token).trim() || null) : s.broker_token;
    db.prepare('UPDATE symbols SET planet = ?, broker_token = ? WHERE symbol = ?').run(planet, token, s.symbol);
    pappu.refreshAstro(true);
    res.json(db.prepare('SELECT * FROM symbols WHERE symbol = ?').get(s.symbol));
  });

  // ================= 🏦 BROKERS =================
  const getBroker = (id) => db.prepare('SELECT * FROM brokers WHERE id = ?').get(Number(id));
  const brokerOut = (row) => brokers.publicRow(row);
  const emitStats = () => { io.emit('stats', engine.stats()); };

  admin.get('/broker-types', (req, res) => res.json(brokers.typesForUI()));

  admin.get('/brokers', (req, res) => {
    res.json(db.prepare('SELECT * FROM brokers ORDER BY is_active DESC, id').all().map(brokerOut));
  });

  admin.post('/brokers', (req, res) => {
    const b = req.body || {};
    if (!brokers.BROKER_TYPES[b.type]) return res.status(400).json({ error: 'Broker type chunein' });
    if (!String(b.name || '').trim()) return res.status(400).json({ error: 'Account ka naam daalein' });
    const info = db.prepare(
      `INSERT INTO brokers (name, type, client_id, api_key, api_secret_enc, access_token_enc, token_updated_at, product, created_at)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`
    ).run(
      String(b.name).trim(), b.type, b.client_id?.trim() || null, b.api_key?.trim() || null,
      encrypt(b.api_secret?.trim()), encrypt(b.access_token?.trim()), b.access_token?.trim() ? Date.now() : null,
      b.product === 'DELIVERY' ? 'DELIVERY' : 'INTRADAY', Date.now()
    );
    log('info', `Broker add: ${b.name} (${b.type}) by ${req.user.email}`);
    res.json(brokerOut(getBroker(info.lastInsertRowid)));
  });

  admin.put('/brokers/:id', (req, res) => {
    const row = getBroker(req.params.id);
    if (!row) return res.status(404).json({ error: 'Broker nahi mila' });
    const b = req.body || {};
    // Khali secret field = purana wala rakho (UI kabhi asli secret wapas nahi dikhata)
    db.prepare(
      `UPDATE brokers SET name = ?, client_id = ?, api_key = ?, api_secret_enc = ?, access_token_enc = ?, token_updated_at = ?, product = ?,
       status = 'untested', status_msg = NULL WHERE id = ?`
    ).run(
      String(b.name ?? row.name).trim() || row.name,
      b.client_id !== undefined ? (b.client_id.trim() || null) : row.client_id,
      b.api_key ? b.api_key.trim() : row.api_key,
      b.api_secret ? encrypt(b.api_secret.trim()) : row.api_secret_enc,
      b.access_token ? encrypt(b.access_token.trim()) : row.access_token_enc,
      b.access_token ? Date.now() : row.token_updated_at,
      b.product === 'DELIVERY' ? 'DELIVERY' : b.product === 'INTRADAY' ? 'INTRADAY' : row.product,
      row.id
    );
    brokers.reload();
    log('info', `Broker update: ${row.name} by ${req.user.email}`);
    emitStats();
    res.json(brokerOut(getBroker(row.id)));
  });

  admin.post('/brokers/:id/test', wrap(async (req, res) => {
    const row = getBroker(req.params.id);
    if (!row) return res.status(404).json({ error: 'Broker nahi mila' });
    let status = 'ok', msg;
    try {
      msg = await brokers.createAdapter(row).testConnection();
    } catch (e) {
      status = 'error';
      msg = e.message;
    }
    db.prepare('UPDATE brokers SET status = ?, status_msg = ?, last_tested_at = ? WHERE id = ?').run(status, msg, Date.now(), row.id);
    log(status === 'ok' ? 'info' : 'warn', `Broker test ${row.name}: ${msg}`);
    res.json(brokerOut(getBroker(row.id)));
  }));

  admin.post('/brokers/:id/activate', (req, res) => {
    const row = getBroker(req.params.id);
    if (!row) return res.status(404).json({ error: 'Broker nahi mila' });
    const type = brokers.BROKER_TYPES[row.type];
    if (type.live) {
      if (req.body?.confirm !== 'LIVE') return res.status(400).json({ error: 'LIVE broker ke liye confirm me "LIVE" likhna zaroori hai' });
      if (row.status !== 'ok') return res.status(400).json({ error: 'Pehle "Test" karke connection OK karein' });
    }
    if (engine.openCount() > 0) {
      return res.status(400).json({ error: 'Pehle saari open positions close karein, phir broker badlein' });
    }
    db.exec('UPDATE brokers SET is_active = 0');
    db.prepare('UPDATE brokers SET is_active = 1 WHERE id = ?').run(row.id);
    brokers.reload();
    log('info', `Active broker: ${row.name} (${row.type}${type.live ? ', LIVE' : ''}) by ${req.user.email}`);
    emitStats();
    res.json(brokerOut(getBroker(row.id)));
  });

  /** Broker test karke status save karo (token update ke baad bhi use hota hai) */
  async function testAndSave(row) {
    let status = 'ok', msg;
    try { msg = await brokers.createAdapter(row).testConnection(); } catch (e) { status = 'error'; msg = e.message; }
    db.prepare('UPDATE brokers SET status = ?, status_msg = ?, last_tested_at = ? WHERE id = ?').run(status, msg, Date.now(), row.id);
    return getBroker(row.id);
  }

  // 🔑 Sirf access token add / update (roz subah ka kaam) - save ke baad turant test
  admin.put('/brokers/:id/token', wrap(async (req, res) => {
    const row = getBroker(req.params.id);
    if (!row) return res.status(404).json({ error: 'Broker nahi mila' });
    if (!brokers.BROKER_TYPES[row.type].fields.includes('access_token')) {
      return res.status(400).json({ error: 'Is broker ko access token ki zarurat nahi' });
    }
    const token = String(req.body?.access_token || '').trim();
    if (token.length < 8) return res.status(400).json({ error: 'Sahi access token paste karein' });
    db.prepare("UPDATE brokers SET access_token_enc = ?, token_updated_at = ?, status = 'untested', status_msg = NULL WHERE id = ?")
      .run(encrypt(token), Date.now(), row.id);
    brokers.reload();
    const tested = await testAndSave(getBroker(row.id));
    brokers.reload();
    log('info', `Access token update: ${row.name} (${tested.status}) by ${req.user.email}`);
    emitStats();
    res.json(brokerOut(tested));
  }));

  // 🧹 Access token hatao (account bana rahega)
  admin.delete('/brokers/:id/token', (req, res) => {
    const row = getBroker(req.params.id);
    if (!row) return res.status(404).json({ error: 'Broker nahi mila' });
    db.prepare("UPDATE brokers SET access_token_enc = NULL, token_updated_at = NULL, status = 'error', status_msg = ? WHERE id = ?")
      .run('Access token hata diya gaya - naya token add karein', row.id);
    brokers.reload();
    log('info', `Access token remove: ${row.name} by ${req.user.email}`);
    const warning = row.is_active && brokers.BROKER_TYPES[row.type].live
      ? 'Ye ACTIVE broker hai - naya token add karne tak iske orders fail honge' : null;
    res.json({ ...brokerOut(getBroker(row.id)), warning });
  });

  // 🗑 Broker remove. Active broker hataya to system apne aap Paper Trading par aa jata hai.
  admin.delete('/brokers/:id', (req, res) => {
    const row = getBroker(req.params.id);
    if (!row) return res.status(404).json({ error: 'Broker nahi mila' });
    if (row.type === 'paper' && row.is_active) {
      return res.status(400).json({ error: 'Active Paper broker safety fallback hai - pehle koi doosra broker activate karein' });
    }
    if (row.is_active && engine.openCount() > 0) {
      return res.status(400).json({ error: 'Is broker se positions open hain - pehle unhe close karein, phir remove karein' });
    }

    let switchedTo = null;
    if (row.is_active) {
      let paper = db.prepare("SELECT * FROM brokers WHERE type = 'paper' AND id != ? ORDER BY id LIMIT 1").get(row.id);
      if (!paper) {
        const info = db.prepare(
          "INSERT INTO brokers (name, type, status, status_msg, created_at) VALUES ('Paper Trading (Demo)', 'paper', 'ok', 'Virtual paisa - koi asli order nahi', ?)"
        ).run(Date.now());
        paper = getBroker(info.lastInsertRowid);
      }
      db.exec('UPDATE brokers SET is_active = 0');
      db.prepare('UPDATE brokers SET is_active = 1 WHERE id = ?').run(paper.id);
      switchedTo = paper.name;
    }
    db.prepare('DELETE FROM brokers WHERE id = ?').run(row.id);
    brokers.reload();
    log('info', `Broker remove: ${row.name}${switchedTo ? ` (active tha → ${switchedTo})` : ''} by ${req.user.email}`);
    emitStats();
    res.json({ ok: true, switchedTo });
  });

  // ================= 🔑 API KEYS =================
  const getKeyRow = (id) => db.prepare('SELECT * FROM api_keys WHERE id = ?').get(Number(id));

  admin.get('/api-providers', (req, res) => res.json(apiKeys.providersForUI()));

  admin.get('/api-keys', (req, res) => {
    res.json(db.prepare('SELECT * FROM api_keys ORDER BY id').all().map(apiKeys.publicRow));
  });

  admin.post('/api-keys', (req, res) => {
    const b = req.body || {};
    if (!apiKeys.PROVIDERS[b.provider]) return res.status(400).json({ error: 'Provider chunein' });
    if (!b.key && b.provider !== 'custom') return res.status(400).json({ error: 'API key daalein' });
    const info = db.prepare(
      'INSERT INTO api_keys (provider, name, key_enc, base_url, model, enabled, created_at) VALUES (?, ?, ?, ?, ?, 1, ?)'
    ).run(b.provider, String(b.name || apiKeys.PROVIDERS[b.provider].label).trim(), encrypt(b.key?.trim()),
      b.base_url?.trim() || null, b.model?.trim() || null, Date.now());
    log('info', `API key add: ${b.provider} by ${req.user.email}`);
    res.json(apiKeys.publicRow(getKeyRow(info.lastInsertRowid)));
  });

  admin.put('/api-keys/:id', (req, res) => {
    const row = getKeyRow(req.params.id);
    if (!row) return res.status(404).json({ error: 'Key nahi mili' });
    const b = req.body || {};
    db.prepare('UPDATE api_keys SET name = ?, key_enc = ?, base_url = ?, model = ?, enabled = ?, status = ? WHERE id = ?').run(
      b.name?.trim() || row.name,
      b.key ? encrypt(b.key.trim()) : row.key_enc,
      b.base_url !== undefined ? (b.base_url.trim() || null) : row.base_url,
      b.model !== undefined ? (b.model.trim() || null) : row.model,
      b.enabled !== undefined ? (b.enabled ? 1 : 0) : row.enabled,
      b.key || b.base_url !== undefined ? 'untested' : row.status,
      row.id
    );
    res.json(apiKeys.publicRow(getKeyRow(row.id)));
  });

  admin.post('/api-keys/:id/test', wrap(async (req, res) => {
    const row = getKeyRow(req.params.id);
    if (!row) return res.status(404).json({ error: 'Key nahi mili' });
    let status = 'ok', msg;
    try { msg = await apiKeys.testRow(row); } catch (e) { status = 'error'; msg = e.message; }
    db.prepare('UPDATE api_keys SET status = ?, status_msg = ?, last_tested_at = ? WHERE id = ?').run(status, msg, Date.now(), row.id);
    res.json(apiKeys.publicRow(getKeyRow(row.id)));
  }));

  admin.delete('/api-keys/:id', (req, res) => {
    db.prepare('DELETE FROM api_keys WHERE id = ?').run(Number(req.params.id));
    log('info', `API key delete #${req.params.id} by ${req.user.email}`);
    res.json({ ok: true });
  });

  admin.get('/users', (req, res) =>
    res.json(db.prepare('SELECT id, name, email, role, created_at FROM users ORDER BY id').all())
  );
  admin.post('/users', (req, res) => {
    const { name, email, password, role = 'trader' } = req.body || {};
    if (!name || !email || !password || password.length < 6) return res.status(400).json({ error: 'Name, email aur 6+ char password zaroori' });
    if (!['admin', 'trader'].includes(role)) return res.status(400).json({ error: 'Galat role' });
    try {
      db.prepare('INSERT INTO users (name, email, password_hash, role, created_at) VALUES (?, ?, ?, ?, ?)')
        .run(name, email.toLowerCase().trim(), hashPassword(password), role, Date.now());
    } catch {
      return res.status(409).json({ error: 'Email already registered' });
    }
    log('info', `User create: ${email} (${role})`);
    res.json({ ok: true });
  });
  admin.delete('/users/:id', (req, res) => {
    if (Number(req.params.id) === req.user.id) return res.status(400).json({ error: 'Khud ko delete nahi kar sakte' });
    db.prepare('DELETE FROM users WHERE id = ?').run(Number(req.params.id));
    res.json({ ok: true });
  });

  admin.get('/logs', (req, res) =>
    res.json(db.prepare('SELECT * FROM logs ORDER BY id DESC LIMIT 200').all())
  );

  admin.get('/overview', (req, res) => {
    const count = (sql) => db.prepare(sql).get().c;
    res.json({
      ...engine.stats(),
      users: count('SELECT COUNT(*) AS c FROM users'),
      symbols: count('SELECT COUNT(*) AS c FROM symbols'),
      decisions: count('SELECT COUNT(*) AS c FROM decisions'),
      signals: count('SELECT COUNT(*) AS c FROM signals'),
      decisionMix: db.prepare('SELECT action, COUNT(*) AS c FROM decisions GROUP BY action').all(),
      agentAccuracy: db.prepare(
        `SELECT s.agent_key, COUNT(*) AS total,
                SUM(CASE WHEN s.action = d.action THEN 1 ELSE 0 END) AS agreed
         FROM signals s JOIN decisions d ON d.analysis_id = s.analysis_id
         GROUP BY s.agent_key`
      ).all(),
      pnlCurve: db.prepare("SELECT closed_at AS t, pnl FROM trades WHERE status = 'CLOSED' ORDER BY closed_at").all(),
    });
  });

  r.use('/admin', admin);

  // error handler
  r.use((err, req, res, _next) => {
    log('error', err.message);
    res.status(400).json({ error: err.message });
  });

  return r;
};
